title: MySQL集群搭建
date: '2019-07-16 15:32:44'
updated: '2019-07-16 15:37:44'
tags: [MySQL集群搭建]
permalink: /articles/2019/07/16/1563262364838.html
---
# 一、MySQL集群简介
常见的集群：https://yq.aliyun.com/articles/555937

## 1、什么是MySQL集群
MySQL集群是一个无共享的(shared-nothing)、分布式节点架构的存储方案，其目的是提供容错性和高性能。
数据更新使用读已提交隔离级别（read-committedisolation)来保证所有节点数据的一致性，使用两阶段提交机制（two-phasedcommit)保证所有节点都有相同的数据(如果任何一个写操作失败，则更新失败）。
无共享的对等节点使得某台服务器上的更新操作在其他服务器上立即可见。传播更新使用一种复杂的通信机制，这一机制专用来提供跨网络的高吞吐量。
通过多个[MySQL](http://www.roncoo.com/article/detail/126412)服务器分配负载，从而最大程序地达到高性能，通过在不同位置存储数据保证高可用性和冗余。
## 2、名称概念
[https://blog.csdn.net/itguangit/article/details/79637404](https://blog.csdn.net/itguangit/article/details/79637404)
MySQL集群有如下三层：
应用程序层：负责与MySQL服务器通信的各种应用程序。

Mysql服务器层：处理SQL命令，并与NDB存储引擎通信和Mysql服务器。

NDB集群组件层：NDB集群组件有时也称数据节点，负责处理查询，然后将结果返回给mysql服务器。
其中MySQL数据库集群主要包括如下三部分：
1) SQL节点（SQL node - 下图对应为 mysqld）：分布式数据库。包括自身数据和查询中心结点数据  
SQL节点：这是用来访问 Cluster数据的节点。对于MySQL Cluster，客户端节点是使用NDB Cluster存储引擎的传统MySQL服务器。通常，SQL节点是使用命令“mysqld –ndbcluster”启动的，或将“ndbcluster”添加到“my.cnf”后使用“mysqld”启动。 
配置文件为：my.ini


2) 数据节点（Data node  - ndbd）：集群共享数据（内存中）     
**数据节点：**这类节点用于保存 Cluster的数据。数据节点的数目与副本的数目相关，是片段的倍数。例如，对于两个副本，每个副本有两个片段，那么就有4个数据节点。不过没有必要设置多个副本。数据节点是用命令“ndbd”启动的。 
配置文件为：my.ini

3) 管理服务器（Management Server - ndb_mgmd）：管理集群 SQL node,Data node
管理(MGM)节点：这类节点的作用是管理MySQL Cluster内的其他节点，如提供配置数据、启动并停止节点、运行备份等。由于这类节点负责管理其他节点的配置，应在启动其他节点之前首先启动这类节点。MGM节点是用命令“ndb_mgmd”启动的。 
配置文件为： config.ini

**“MySQL实验室”推荐使用MySQL Cluster 7.x版本。MySQL Cluster 7.x拥有在线增加节点、多线程等新特性。**
工作原理
管理服务器(MGM节点)负责管理 Cluster配置文件和 Cluster日志。 Cluster中的每个节点从管理服务器检索配置数据，并请求确定管理服务器所在位置的方式。当数据节点内出现新的事件时，节点将关于这类事件的信息传输到管理服务器，然后，将这类信息写入 Cluster日志。


拓扑结构图如下所示：

![图片](https://uploader.shimo.im/f/N5mst8gXZL8hvUiO.png!thumbnail)
![图片](https://uploader.shimo.im/f/F0zPrXT72ZcVzalD.png!thumbnail)
# 二、环境说明
## 1、系统环境
| 服务器   | 角色   | 说明   | 
|:----|:----|:----|
| 10.172.49.23   | 管理服务器   | 系统：CentOS-7-x86_64-DVD-1804.iso   | 
| 10.172.49.1   | 数据节点   | 系统：CentOS-7 64位    | 
| 10.172.49.24   | SQL节点   | 系统：CentOS-7 64位   | 
| 10.172.49.37   | 数据节点   | 系统：CentOS-7 64位 | 
| 10.172.49.38 | 数据节点   | 系统：CentOS-7 64位 | 
| 10.172.49.39   | SQL节点   | 系统：CentOS-7 64位 | 

![图片](https://uploader.shimo.im/f/bnYFVQW3TyApAwcz.png!thumbnail)
## 2、软件环境

MySQL集群版本：
依据系统Centos7下载安装文件
[https://dev.mysql.com/downloads/cluster/](https://dev.mysql.com/downloads/cluster/)
![图片](https://uploader.shimo.im/f/TqaexI7vfgsxj5Ff.png!thumbnail)
[https://dev.mysql.com/downloads/file/?id=481401](https://dev.mysql.com/downloads/file/?id=481401)
![图片](https://uploader.shimo.im/f/G0PsLpbPnKYefgaW.png!thumbnail)
```
mysql-cluster-gpl-7.6.8-el7-x86_64.tar.gz
```
官方文档：[https://dev.mysql.com/doc/relnotes/mysql-cluster/7.6/en/mysql-cluster-news-7-6-8.html](https://dev.mysql.com/doc/relnotes/mysql-cluster/7.6/en/mysql-cluster-news-7-6-8.html)


1. PIP源

10.238.0.33
[https://bbs.huaweicloud.com/blogs/b514b31e113511e89fc57ca23e93a89f](https://bbs.huaweicloud.com/blogs/b514b31e113511e89fc57ca23e93a89f)
[https://www.cnblogs.com/mangoVic/p/7444465.html](https://www.cnblogs.com/mangoVic/p/7444465.html)
划分区，装PIP源

# 三、搭建集群（Linux环境）
[https://downloads.mysql.com/tutorials/cluster/mysql_wp_cluster_quickstart.pdf](https://downloads.mysql.com/tutorials/cluster/mysql_wp_cluster_quickstart.pdf)
[https://downloads.mysql.com/docs/mysql-cluster-7.6-relnotes-en.a4.pdf](https://downloads.mysql.com/docs/mysql-cluster-7.6-relnotes-en.a4.pdf)

阅读搭建指导：
[https://fossies.org/linux/misc/mysql-refman/mysql-refman-5.7-en.html-chapter.tar.gz/refman-5.7-en.html-chapter/mysql-cluster.html#mysql-cluster-installer-requirements](https://fossies.org/linux/misc/mysql-refman/mysql-refman-5.7-en.html-chapter.tar.gz/refman-5.7-en.html-chapter/mysql-cluster.html#mysql-cluster-installer-requirements)

## 1、安装集群版本
### a、准备工作
不管是Management Server，还是Data node、SQL node，都需要先安装MySQL集群版本，然后根据不用的配置来决定当前服务器有哪几个角色。
安装之前准备好mysql用户和mysql用户组，
相关命令：
```
groupadd mysql  
useradd mysql -g mysql
userdel mysql
```
为了方便测试，确定相关机器的防火墙已关闭（或者设置防火墙这几台机器之间的网络连接是畅通无阻的），
相关命令：
```
chkconfig iptables off 
service iptables stop
```

初始化系统 每个节点都操作
```
setenforce 0
sed -i "s/enforcing/disabled/g" /etc/selinux/config
# systemctl disable firewalld 
# vi /etc/selinux/config
    SELINUX=disabled    

﻿scp /home/deployer/mysql-cluster-gpl-7.6.8-el7-x86_64.tar.gz root@10.172.49.23:/home/deployer

﻿scp /home/deployer/mysql-cluster-gpl-7.6.8-el7-x86_64.tar.gz deployer@10.172.49.39:/home/deployer

tar -zxvf mysql-cluster-gpl-7.6.8-el7-x86_64.tar.gz 
mv mysql-cluster-gpl-7.6.8-el7-x86_64 /usr/local/mysql

# cp /usr/local/mysql/bin/ndb_mgm* /usr/local/bin/
# chmod +x /usr/local/bin/ndb_mgm*
# chmod +x /usr/local/mysql/bin/
# echo "export PATH=$PATH:/usr/local/mysql/bin/" >> /etc/profile

##### reboot 或 重新打开一个命令窗口连接
```

### b、安装集群版本
1.授权
```
chown -R mysql:mysql /usr/local/mysql
```
2.切换mysql用户
```
su - mysql
```
3.搭建MySQL NDB安装依赖 （正在进行此步骤）
[https://fossies.org/linux/misc/mysql-refman/mysql-refman-5.7-en.html-chapter.tar.gz/refman-5.7-en.html-chapter/mysql-cluster.html#mysql-cluster-installer-requirements](https://fossies.org/linux/misc/mysql-refman/mysql-refman-5.7-en.html-chapter.tar.gz/refman-5.7-en.html-chapter/mysql-cluster.html#mysql-cluster-installer-requirements)

5.安装MySQL
```
cd /usr/local/mysql
bin/ndb_setup.py &
```
注：所有服务器上都需要执行上述操作来安装MySQL集群版本。
```
bin/ndb_setup.py 
```
报错：ImportError: No module named cryptography.fernet
解决：[https://bugzilla.redhat.com/show_bug.cgi?id=1459947](https://bugzilla.redhat.com/show_bug.cgi?id=1459947)
1. confirm python-setuptools is NOT installed

2. # yum install python-cryptography

3. # python

   >> from cryptography import fernet
yum install python-setuptools

再启动
```
bin/ndb_setup.py 
```
![图片](https://uploader.shimo.im/f/goBg0gGZJAgXrQdq.png!thumbnail)
[https://10.172.49.23:8081/welcome.html](https://10.172.49.23:8081/welcome.html)


## 2、集群配置
优化原因:
[https://dev.mysql.com/doc/refman/8.0/en/column-count-limit.html](https://dev.mysql.com/doc/refman/8.0/en/column-count-limit.html)
[https://learnku.com/laravel/t/3421/text-is-a-solution-to-the-row-size-too-blobs-not-counting-is-65535-or-blobs-caused-by-too-many-fields-in-the-error-message-mysql](https://learnku.com/laravel/t/3421/text-is-a-solution-to-the-row-size-too-blobs-not-counting-is-65535-or-blobs-caused-by-too-many-fields-in-the-error-message-mysql)
![图片](https://uploader.shimo.im/f/mlFPgW4IUmkOcrMH.png!thumbnail)
解决参考：[https://www.cnblogs.com/52php/p/5675427.html](https://www.cnblogs.com/52php/p/5675427.html)
问题：[http://blog.51cto.com/11374450/1939809](http://blog.51cto.com/11374450/1939809)
优化后表格SQL语句仍然报错
![图片](https://uploader.shimo.im/f/dn0T3IxJmbMw0tWB.png!thumbnail)
解决参考:[https://bbs.huaweicloud.com/forum/thread-5747-1-1.html](https://bbs.huaweicloud.com/forum/thread-5747-1-1.html)
show variables like '%max_heap_table_size%';
![图片](https://uploader.shimo.im/f/zN4VTTtBQGY0lOvs.png!thumbnail)
参数修改为64M
解决方法:[https://stackoverflow.com/questions/4179087/mysql-cluster-error-1114-hy000-the-table-users-is-full](https://stackoverflow.com/questions/4179087/mysql-cluster-error-1114-hy000-the-table-users-is-full)
参考管理节点配置：[https://dba.stackexchange.com/questions/101203/ndbcluster-error-1114-the-table-is-full-when-using-table](https://dba.stackexchange.com/questions/101203/ndbcluster-error-1114-the-table-is-full-when-using-table)
创建logfile tablespace
参考：[https://dev.mysql.com/doc/refman/8.0/en/mysql-cluster-disk-data-objects.html](https://dev.mysql.com/doc/refman/8.0/en/mysql-cluster-disk-data-objects.html)
```
CREATE LOGFILE GROUP lg_1
    ADD UNDOFILE 'undo_1.log'
    INITIAL_SIZE 16M
    UNDO_BUFFER_SIZE 2M
    ENGINE NDBCLUSTER;
   
ALTER LOGFILE GROUP lg_1
    ADD UNDOFILE 'undo_2.log'
    INITIAL_SIZE 12M
    ENGINE NDBCLUSTER;
    
CREATE TABLESPACE ts_1
    ADD DATAFILE 'data_1.dat'
    USE LOGFILE GROUP lg_1
    INITIAL_SIZE 32M
    ENGINE NDBCLUSTER;

ALTER TABLESPACE ts_1
    ADD DATAFILE 'data_2.dat'
    INITIAL_SIZE 48M
    ENGINE NDBCLUSTER;
```
![图片](https://uploader.shimo.im/f/c8G2jGGbCCMaGhvp.png!thumbnail)
```
ERROR 1178 (42000): The storage engine for the table doesn't support ALTER TABLESPACE
```
指定tablespace的engine
ALTER TABLESPACE ts_1
    ADD DATAFILE 'data_2.dat'
    INITIAL_SIZE 48M
    ENGINE NDBCLUSTER;
![图片](https://uploader.shimo.im/f/z86JL7pHhA0hznM9.png!thumbnail)
```
1296 - Got error 4243 'Index not found' from NDBCLUSTER
```
参考：[https://blog.csdn.net/lwei_998/article/details/7414588](https://blog.csdn.net/lwei_998/article/details/7414588)
drop table 重新创建
```
1296 - Got error 851 'Maximum 8052 bytes of FIXED columns supported, use varchar or COLUMN_FORMAT DYNAMIC instead' from NDBCLUSTER
```
错误码参考:[https://dev.mysql.com/doc/ndbapi/en/ndb-error-codes-application-error.html](https://dev.mysql.com/doc/ndbapi/en/ndb-error-codes-application-error.html)
变量：[https://dev.mysql.com/doc/mysql-cluster-excerpt/5.7/en/mysql-cluster-system-variables.html](https://dev.mysql.com/doc/mysql-cluster-excerpt/5.7/en/mysql-cluster-system-variables.html)
![图片](https://uploader.shimo.im/f/aqS9u4tMzCI8GmXg.png!thumbnail)
SQL节点增加配置
```
ndb_default_column_format=DYNAMIC
```
![图片](https://uploader.shimo.im/f/loZPeij3ovw6pwrD.png!thumbnail)
char修改为varchar


### a、管理节点49.23
配置参考:[https://forums.mysql.com/read.php?25,657949,657986#msg-657986](https://forums.mysql.com/read.php?25,657949,657986#msg-657986)
1.root用户下，创建目录和配置文件
```
mkdir /var/lib/mysql-cluster
cd /var/lib/mysql-cluster
vim config.ini
```
config.ini配置信息如下：
[number_of_node_groups] = number_of_data_nodes / NoOfReplicas
[http://mysql-cluster.1050023.n4.nabble.com/My-First-Cluster-Getting-error-on-Nodegroup-configuration-td4655329.html](http://mysql-cluster.1050023.n4.nabble.com/My-First-Cluster-Getting-error-on-Nodegroup-configuration-td4655329.html)
```
[ndbd default]
NoOfReplicas=2
DataMemory=8G
#StringMemory = 50
#MaxNoOfTables = 4096
#MaxBufferedEpochs=100000
#TimeBetweenEpochsTimeout=32000
#TransactionDeadlockDetectionTimeout=1000000
#TransactionInactiveTimeout=10000000
#MaxNoOfOrderedIndexes = 8192
#MaxNoOfUniqueHashIndexes = 1024
#MaxNoOfAttributes = 100000
#MaxNoOfTriggers = 10240
#SchedulerSpinTimer = 400
#SchedulerExecutionTimer = 100
#RealTimeScheduler = 1
ServerPort=2202

[ndb_mgmd]
NodeId=1
HostName=10.172.49.23
DataDir=/var/lib/mysql-cluster

[ndbd]
HostName=10.172.49.32
NodeId=7
DataDir=/usr/local/mysql/data

[ndbd]
HostName=10.172.49.33
NodeId=8
DataDir=/usr/local/mysql/data

[mysqld]
NodeId=3
HostName=10.172.49.24

[mysqld]
NodeId=4
```
HostName=10.172.49.39

2.授权
```
chown -R mysql:mysql /var/lib/mysql-cluster
```
3.切换用户
```
su - mysql
```
4.启动管理服务
```
/usr/local/mysql/bin/ndb_mgmd -f /var/lib/mysql-cluster/config.ini --initial

ndb_mgmd -f /var/lib/mysql-cluster/config.ini
```
注:命令行中的ndb_mgmd是mysql cluster的管理服务器，后面的-f表示后面的参数是启动的参数配置文件。
如果在启动后过了几天又添加了一个数据节点，这时修改了配置文件启动时就必须加上--initial参数，不然添加的节点不会作用在mysql cluster中。

ndbd命令报错
![图片](https://uploader.shimo.im/f/8jRMO7TR11gE0LwO.png!thumbnail)

报错参考：[https://blog.csdn.net/lxpbs8851/article/details/8942513](https://blog.csdn.net/lxpbs8851/article/details/8942513)

配置不生效，需要停止后重新reload配置
ndb_mgm -e "SHUTDOWN"
ndb_mgmd --reload --config-file /var/lib/mysql-cluster/config.ini
ndb_mgm -c 10.172.49.23:1186

查看集群情况。数据节点和SQL节点等待加入
![图片](https://uploader.shimo.im/f/FeWIa510RFQcVsJz.png!thumbnail)
加入数据节点后：
![图片](https://uploader.shimo.im/f/JsGee581cgM0q1wH.png!thumbnail)
加入SQL节点后：
![图片](https://uploader.shimo.im/f/8bgsX5W0GMENOSDO.png!thumbnail)

### b、数据节点~~49.1 ~~/ 49.32 / 49.33
yum -y remove mari*
1.编辑/etc/my.cnf文件
```
# vim /etc/my.cnf
[mysqld] 
#sql_mode=NO_ENGINE_SUBSTITUTION,STRICT_TRANS_TABLES 
#datadir=/usr/local/mysql/data
#socket=/var/lib/mysql/mysql.sock
user=mysql
ndbcluster 
ndb-connectstring=10.172.49.23

[mysql_cluster] 
ndb-connectstring=10.172.49.23
```
![图片](https://uploader.shimo.im/f/TYjgp95mz7sJMx2l.png!thumbnail)
2.切换用户
```
su - mysql
```
3.启动数据节点服务
```
mkdir -p /usr/local/mysql/data
/usr/local/mysql/bin/ndbd --initial

ndbd
```
注：第一次启动需要加参数：–initial，以后就不用加了，直接运行： /usr/local/mysql/bin/ndbd
![图片](https://uploader.shimo.im/f/1XkHE7DGapsLkmAL.png!thumbnail)
启动成功

PID terminated by signal 6: Aborted
Initiated by signal 6. Caused by error 6000
Forced node shutdown completed. Occured during startphase 0. Initiated by signal 6. Caused by error 6000: 'Error OS signal received(Internal error, programming error or missing error message, please report a bug). Temporary error, restart node'.
[https://forums.mysql.com/read.php?25,522361,532256#msg-532256](https://forums.mysql.com/read.php?25,522361,532256#msg-532256)
[https://dev.mysql.com/doc/mysql-cluster-excerpt/5.7/en/mysql-cluster-logs-cluster-log.html](https://dev.mysql.com/doc/mysql-cluster-excerpt/5.7/en/mysql-cluster-logs-cluster-log.html)
解决：将管理节点中相关参数屏蔽，重新init，再启动数据节点。完成；
完成后将参数放开，进行reload


### c、SQL节点49.24 / 49.39
1.编辑/etc/my.cnf文件（数据节点和SQL节点在统一服务器时可省略）
```
# vim /etc/my.cnf
[mysqld]
#sql_mode=NO_ENGINE_SUBSTITUTION,STRICT_TRANS_TABLES 
datadir=/usr/local/mysql/data
#socket=/var/lib/mysql/mysql.sock
#############优化
basedir = /usr/local/mysql
#default-storage-engine = ndbcluster

slow-query-log = on
slow_query_log_file = /usr/local/mysql/data/slow-query.log
long_query_time = 5

#skip-external-locking
key_buffer_size = 600M
max_allowed_packet = 100M
table_open_cache = 2048
sort_buffer_size = 1024M
net_buffer_length = 8K
read_buffer_size = 400M
read_rnd_buffer_size = 200M

lower_case_table_names = 1
back_log = 384
thread_stack = 256K
join_buffer_size = 500M
thread_cache_size = 200
query_cache_size = 640M
tmp_table_size = 256M
max_connections = 5000
max_connect_errors = 10000000
wait_timeout = 2880000
interactive_timeout = 2880000
#thread_concurrency = 8
max_heap_table_size = 64M
ndb_default_column_format=DYNAMIC

user=mysql
ndbcluster 
ndb-connectstring=10.172.49.23


[mysql_cluster] 
ndb-connectstring=10.172.49.23

```
2.复制mysqld到系统服务里面去
```
cp /usr/local/mysql/support-files/mysql.server /etc/init.d/mysqld
```
3.切换用户
```
su - mysql
```
4.启动数据节点服务
```
service mysqld start
```
service mysqld start报错
![图片](https://uploader.shimo.im/f/5vvguk9EHCE6zjIE.png!thumbnail)
[https://my.oschina.net/u/3769333/blog/1816742](https://my.oschina.net/u/3769333/blog/1816742)
```
chown -R mysql:mysql /usr/local/mysql/data
chmod -R 755 /usr/local/mysql/data
```
![图片](https://uploader.shimo.im/f/3yEepgFma7EOBY7H.png!thumbnail)
错误汇总此处存在：[https://wenku.baidu.com/view/82b7cc5e11a6f524ccbff121dd36a32d7375c7f5.html?re=view](https://wenku.baidu.com/view/82b7cc5e11a6f524ccbff121dd36a32d7375c7f5.html?re=view)
```
cat /usr/local/mysql/data/02l14b003.xx01.err
```
![图片](https://uploader.shimo.im/f/RMlsfLyV2hMd0oBF.png!thumbnail)

![图片](https://uploader.shimo.im/f/Cl5KU7RiIb4wOukf.png!thumbnail)
```
cd /usr/local/mysql/bin
mysqld --initialize
#root@localhost: 5qk(v=ofv&H*
#root@localhost: .hVug*ayS7jc
```
root@localhost: qaF53-s+l:v&

![图片](https://uploader.shimo.im/f/5oa0hodD8UgjlIwW.png!thumbnail)
![图片](https://uploader.shimo.im/f/BlbMrUNy2sgBjV5O.png!thumbnail)
数据库创建完，启动成功
![图片](https://uploader.shimo.im/f/eAIWYMWWhXYrIC3Z.png!thumbnail)

集群完成：
![图片](https://uploader.shimo.im/f/dPmgyBUHC2gokQ1s.png!thumbnail)

```
/usr/local/mysql/bin/mysqladmin -u root password '5qk(v=ofv&H*'
/usr/local/mysql/bin/mysqladmin -u root password 'qaF53-s+l:v&'
```
![图片](https://uploader.shimo.im/f/erAOclZpGQoToBM1.png!thumbnail)
杀掉多余的mysql进程
![图片](https://uploader.shimo.im/f/WBHIpnG8ae4Hucn6.png!thumbnail)
MySQL无法连接问题：
[https://blog.csdn.net/mchdba/article/details/10630701](https://blog.csdn.net/mchdba/article/details/10630701)
```
service mysqld stop
```
![图片](https://uploader.shimo.im/f/OdjDA97zII4jYv23.png!thumbnail)
安全模式启动：
```
mysqld_safe --skip-grant-tables &
```
![图片](https://uploader.shimo.im/f/uNMF3jQITpUWvZj5.png!thumbnail)
无账号密码登陆：
mysql -uroot -p【注释，在下面的要求你输入密码的时候，你不用管，直接回车键一敲就过去了】
```
SET PASSWORD = PASSWORD('Abc@1234');
use mysql;
update user set authentication_string=PASSWORD("Abc@1234") where user='root' and host='localhost';
update user set host = '%' where user='root';
flush privileges;
quit
```
service mysqld restart
![图片](https://uploader.shimo.im/f/z8ZW97zw1VQgA7RV.png!thumbnail)
(2003) Can't connect to MySQL server on '***server***' (10061)
**ps xa | grep mysqld**
**kill -9 mysqld_safe的进程**
[https://dev.mysql.com/doc/refman/8.0/en/can-not-connect-to-server.html](https://dev.mysql.com/doc/refman/8.0/en/can-not-connect-to-server.html)

NDB: server id set to zero - changes logged to bin log with server id zero will be logged with another server id by slave mysqlds
No free node id found for mysqld(API).
相关错误参考：[https://my.oschina.net/out1kiss/blog/1817877](https://my.oschina.net/out1kiss/blog/1817877)
防火墙未关闭：[https://dba.stackexchange.com/questions/133609/mysql-cluster-api-node-wont-start-successfully](https://dba.stackexchange.com/questions/133609/mysql-cluster-api-node-wont-start-successfully)

MySQL Cluster Nodes, Node Groups, Replicas, and Partitions
[https://docs.oracle.com/cd/E17952_01/mysql-5.0-en/mysql-cluster-nodes-groups.html](https://docs.oracle.com/cd/E17952_01/mysql-5.0-en/mysql-cluster-nodes-groups.html)

ERROR! MySQL server PID file could not be found
[http://blog.51cto.com/dahui09/1841627](http://blog.51cto.com/dahui09/1841627)
[https://my.oschina.net/adailinux/blog/1513702](https://my.oschina.net/adailinux/blog/1513702)
[http://www.sail.name/2018/05/19/cannot-kill-mysql/](http://www.sail.name/2018/05/19/cannot-kill-mysql/)

### d、完成效果
```
[root@01l14b003 deployer]# ndb_mgm -c 10.172.49.23:1186
-- NDB Cluster -- Management Client --
ndb_mgm> show
Connected to Management Server at: 10.172.49.23:1186
Cluster Configuration
---------------------
[ndbd(NDB)]	1 node(s)
id=2	@10.172.49.1  (mysql-5.7.24 ndb-7.6.8, Nodegroup: 0, *)

[ndb_mgmd(MGM)]	1 node(s)
id=1	@10.172.49.23  (mysql-5.7.24 ndb-7.6.8)

[mysqld(API)]	2 node(s)
id=3	@10.172.49.24  (mysql-5.7.24 ndb-7.6.8)
id=4 (not connected, accepting connect from any host)


```
## 3、集群验证
**mysqladmin -u root -p version**
![图片](https://uploader.shimo.im/f/wUHAfMBl1IoRhB5c.png!thumbnail)
mysqladmin -u root -p variables
![图片](https://uploader.shimo.im/f/O18sW4a7KO45BHIx.png!thumbnail)
### NDB Cluster Example with Tables and Data
[https://dev.mysql.com/doc/refman/5.7/en/mysql-cluster-install-example-data.html](https://dev.mysql.com/doc/refman/5.7/en/mysql-cluster-install-example-data.html)
使用ENGINE=NDBCLUSTER创建表
# 四、常用命令与问题整理
1） ndb_mgmd管理命令：/usr/local/mysql/bin/ndb_mgm 执行之后就是管理控制台了，里面可以继续输入命令。(具体命令可以使用help查看)
ndb_mgm -e "SHUTDOWN"
ndb_mgmd --reload --config-file /var/lib/mysql-cluster/config.ini
ndb_mgm -c 10.172.49.23:1186

2） 停止集群服务器的命令：/usr/local/mysql/bin/ndb_mgm -e shutdown
ndb_mgm -e shutdown
如果集群配置有更新了：rm /usr/local/mysql/mysql-cluster/ndb_1_config.bin.1
ndb_mgmd --reload --config-file /var/lib/mysql-cluster/config.ini

3） 停止SQL节点的命令：/usr/local/mysql/bin/mysqladmin -uroot shutdown
4）使用需要注意如下两点：
a.表必须用ENGINE=NDB或ENGINE=NDBCLUSTER选项创建，或用ALTER TABLE选项更改ALTER TABLE City ENGINE=NDBCLUSTER;，以使用NDB Cluster存储引擎在 Cluster内复制它们。如果使用mysqldump的输出从已有数据库导入表，可在文本编辑器中打开SQL脚本，并将该选项添加到任何表创建语句，或 用这类选项之一替换任何已有的ENGINE（或TYPE）选项。
b.另外还请记住，每个NDB表必须有一个主键。如果在创建表时用户未定义主键，NDB Cluster存储引擎将自动生成隐含的主键。（注释：该隐含 键也将占用空间，就像任何其他的表索引一样。由于没有足够的内存来容纳这些自动创建的键，出现问题并不罕见）。
其他操作上没有什么区别！
文章来源[http://www.roncoo.com/article/detail/129594](http://www.roncoo.com/article/detail/129594)

## 停止&重启
[https://fossies.org/linux/misc/mysql-refman/mysql-refman-5.7-en.html-chapter.tar.gz/refman-5.7-en.html-chapter/mysql-cluster.html#mysql-cluster-install-example-data](https://fossies.org/linux/misc/mysql-refman/mysql-refman-5.7-en.html-chapter.tar.gz/refman-5.7-en.html-chapter/mysql-cluster.html#mysql-cluster-install-example-data)

[https://fossies.org/linux/misc/mysql-refman/mysql-refman-5.7-en.html-chapter.tar.gz/refman-5.7-en.html-chapter/mysql-cluster.html#mysql-cluster-install-configuration](https://fossies.org/linux/misc/mysql-refman/mysql-refman-5.7-en.html-chapter.tar.gz/refman-5.7-en.html-chapter/mysql-cluster.html#mysql-cluster-install-configuration)

[https://fossies.org/linux/misc/mysql-refman/mysql-refman-5.7-en.html-chapter.tar.gz/refman-5.7-en.html-chapter/mysql-cluster.html#mysql-cluster-installer-requirements](https://fossies.org/linux/misc/mysql-refman/mysql-refman-5.7-en.html-chapter.tar.gz/refman-5.7-en.html-chapter/mysql-cluster.html#mysql-cluster-installer-requirements)

To shut down the cluster, enter the following command in a shell on the machine hosting the management node:
shell> **ndb_mgm -e shutdown**


To restart the cluster on Unix platforms, run these commands:
On the management host (198.51.100.10 in our example setup):
* shell> **ndb_mgmd -f /var/lib/mysql-cluster/config.ini**

On each of the data node hosts (198.51.100.30 and 198.51.100.40):
* shell> **ndbd**
* Use the [ndb_mgm](https://fossies.org/linux/misc/mysql-refman/mysql-refman-5.7-en.html-chapter.tar.gz/refman-5.7-en.html-chapter/mysql-cluster.html#mysql-cluster-programs-ndb-mgm) client to verify that both data nodes have started successfully.

On the SQL host (198.51.100.20):
* shell> **mysqld_safe &**

## 使用cluster
启动顺序为：管理节点->数据节点->SQL节点
1. 启动管理节点：ndb_mgmd -f /data/mysql-cluster/config.ini

启动NDB（数据节点）:ndbd --initial
1. **注意：只是在第一次启动或在备份/恢复或配置变化后重启ndbd时，才加–initial参数！原因在于，该参数会使节点删除由早期ndbd实例创建的，用于恢复的任何文件，包括用于恢复的日志文件。**
2. 启动SQL节点（启动mysql服务）:/etc/init.d/mysqld start
## MySQL Cluster集群的关闭
关闭顺序：SQL节点->数据节点->管理节点
1. SQL节点关闭:/etc/init.d/mysqld stop
2. （NDB）数据节点关闭:ndbd stop 

管理节点关闭
| 1  2  3  4  5  6   | ndb_mgm> shutdown  Node 2: Cluster shutdown initiated  Node 3: Cluster shutdown initiated  3 NDB Cluster node(s) have shutdown.  Disconnecting to allow management server to shutdown.  Node 3: Node shutdown completed.   | 
|----|----|
# Converting InnoDB Tables to MySQL Cluster
[https://blogs.oracle.com/jsmyth/converting-innodb-tables-to-mysql-cluster](https://blogs.oracle.com/jsmyth/converting-innodb-tables-to-mysql-cluster)

参考（3台）：[https://cloud.tencent.com/developer/article/1005764](https://cloud.tencent.com/developer/article/1005764)
参考（5台）：[http://blog.51cto.com/afterdawn/2125638](http://blog.51cto.com/afterdawn/2125638)

Grafana监控MySQL：[https://blog.csdn.net/aixiaoyang168/article/details/81354059](https://blog.csdn.net/aixiaoyang168/article/details/81354059)
zabbix监控mysql：[https://www.linuxea.com/1655.html](https://www.linuxea.com/1655.html)
MySQL监控脚本:[https://blog.csdn.net/wyzxg/article/details/42875345](https://blog.csdn.net/wyzxg/article/details/42875345)

## PXC （Percona XtraDB Cluster）
>建议PXC使用PerconaServer（MySQL改进版，性能提升很大）

[https://zhuanlan.zhihu.com/p/46184438](https://zhuanlan.zhihu.com/p/46184438)
[https://www.percona.com/doc/percona-xtradb-cluster/LATEST/bootstrap.html](https://www.percona.com/doc/percona-xtradb-cluster/LATEST/bootstrap.html)

容器化mysql集群：
[http://dockone.io/article/2048](http://dockone.io/article/2048)

[MySQL监控-1550458354707.json](https://uploader.shimo.im/f/B5mjKaEhhvE8ud5c.json)

[http://10.172.49.24:9104/metrics](http://10.172.49.24:9104/metrics)
[https://prometheus.io/docs/prometheus/latest/querying/operators/](https://prometheus.io/docs/prometheus/latest/querying/operators/)
[https://help.aliyun.com/document_detail/29060.html](https://help.aliyun.com/document_detail/29060.html)
[https://povilasv.me/prometheus-go-metrics/](https://povilasv.me/prometheus-go-metrics/)

包含MySQL告警规则
[MySQL Overview-1550458840387.json](https://uploader.shimo.im/f/aJrTUBXuDCAwUNMk.json)


[https://blog.csdn.net/qq_25934401/article/details/82594478](https://blog.csdn.net/qq_25934401/article/details/82594478)
