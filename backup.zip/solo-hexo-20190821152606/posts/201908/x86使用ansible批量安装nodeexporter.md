title: x86使用ansible批量安装node_exporter
date: '2019-08-07 16:16:40'
updated: '2019-08-07 16:18:19'
tags: [x86, ansible, node_exporter]
permalink: /articles/2019/08/07/1565165800252.html
---
## node_exporter.service
```
[Unit]
Description=Node Exporter
[Service]
User=root
ExecStart=/home/deployer/node_exporter-0.17.0.linux-amd64/node_exporter
[Install]
WantedBy=default.target
```

## node_exporter.sh
```
#!/bin/sh
#chkconfig: 2345 80 90
#description:node_exporter.sh
RECDIR=$PWD
#start node_exporter service
/home/deployer/node_exporter-0.17.0.linux-amd64/node_exporter &
```


# 安装
## ansible批量安装
ansible的组在此处定义：
/etc/ansible/hosts
账号密码可联系杨阳测试正确的密码。
阿里天宫的机器使用prom账号安装的，其他的是使用deployer账号安装
```
-bash-4.2$ vi /etc/ansible/hosts 
10.125.128.123  ansible_ssh_user=deployer ansible_ssh_pass=XXX@2018 ansible_sudo_pass=XXX@2018
10.125.128.124  ansible_ssh_user=deployer ansible_ssh_pass=XXX@2018 ansible_sudo_pass=XXX@2018
```
### centos6
```
#0 查看操作系统版本
ansible ipmi_xkf -m shell -a "cat /etc/redhat-release" --sudo
#1 拷贝文件
ansible ipmi_xkf -m copy -a "src=/home/deployer/node_exporter-0.17.0.linux-amd64.tar.gz dest=/home/deployer"
#2 解压文件
ansible ipmi_xkf -m shell -a "tar xvzf /home/deployer/node_exporter-0.17.0.linux-amd64.tar.gz" --sudo

[centos6设置开机启动]
#3 拷贝开机启动文件
ansible ipmi_xkf -m copy -a "src=/home/deployer/node_exporter.sh dest=/home/deployer"
#3.1 拷贝开机启动文件到启动目录
ansible ipmi_xkf -m shell -a "cp /home/deployer/node_exporter.sh  /etc/rc.d/init.d/" --sudo
#4 设置开机启动
ansible ipmi_xkf -m shell -a "chkconfig --add node_exporter.sh " --sudo
ansible ipmi_xkf -m shell -a "chkconfig node_exporter.sh on" --sudo

[centos6]
#5 启动文件
ansible ipmi_xkf -m shell -a "service node_exporter start" --sudo
# ansible ipmi_xkf -m shell -a "systemctl stop node_exporter" --sudo
#6 查看启动状态
ansible ipmi_xkf -m shell -a "service node_exporter status" --sudo

#7 启动防火墙 【(尽量保留原装，不运行此命令，kennel影响业务)】
# ansible ipmi_xkf -m shell -a "systemctl start firewalld" --sudo
#7.1 防火墙打开9100端口
ansible ipmi_xkf -m shell -a "firewall-cmd --zone=public --add-port=9100/tcp --permanent" --sudo
#7.2 重载规则
ansible ipmi_xkf -m shell -a "firewall-cmd --reload" --sudo

#8 设置selinux
ansible ipmi_xkf -m shell -a "setenforce 0" --sudo
ansible ipmi_xkf -m shell -a "sed -i 's/SELINUX=enforcing/SELINUX=disabled/g' /etc/selinux/config" --sud
```

### centos7
```
#0 查看操作系统版本
ansible ipmi_xkf -m shell -a "cat /etc/redhat-release" --sudo
#1 拷贝文件
ansible ipmi_xkf -m copy -a "src=/home/deployer/node_exporter-0.17.0.linux-amd64.tar.gz dest=/home/deployer"
#2 解压文件
ansible ipmi_xkf -m shell -a "tar xvzf /home/deployer/node_exporter-0.17.0.linux-amd64.tar.gz" --sudo

[centos7设置开机启动]
#3 拷贝开机启动文件
ansible ipmi_xkf -m copy -a "src=/home/deployer/node_exporter.service dest=/home/deployer"
#3.1 拷贝开机启动文件到启动目录
ansible ipmi_xkf -m shell -a "cp /home/deployer/node_exporter.service /lib/systemd/system/" --sudo
#4 设置开机启动
ansible ipmi_xkf -m shell -a "systemctl enable node_exporter" --sudo

[centos7]
#5 启动文件
ansible ipmi_xkf -m shell -a "systemctl start node_exporter" --sudo
# ansible ipmi_xkf -m shell -a "systemctl stop node_exporter" --sudo
#6 查看启动状态
ansible ipmi_xkf -m shell -a "systemctl status node_exporter" --sudo

#7 启动防火墙 【(尽量保留原装，不运行此命令，kennel影响业务)】
# ansible ipmi_xkf -m shell -a "systemctl start firewalld" --sudo
#7.1 防火墙打开9100端口
ansible ipmi_xkf -m shell -a "firewall-cmd --zone=public --add-port=9100/tcp --permanent" --sudo
#7.2 重载规则
ansible ipmi_xkf -m shell -a "firewall-cmd --reload" --sudo

#8 设置selinux
ansible ipmi_xkf -m shell -a "setenforce 0" --sudo
ansible ipmi_xkf -m shell -a "sed -i 's/SELINUX=enforcing/SELINUX=disabled/g' /etc/selinux/config" --sud
```

## 手动安装
```
#登陆10.172.49.1 跳板机  IP替换为需要安装的IP即可
scp node_exporter-0.17.0.linux-amd64.tar.gz deployer@10.172.48.4:/home/deployer/
scp node_exporter.service deployer@10.172.48.4:/home/deployer/

#安装
sudo tar xvzf node_exporter-0.17.0.linux-amd64.tar.gz
sudo cp /home/deployer/node_exporter.service /lib/systemd/system/
sudo systemctl enable node_exporter
sudo systemctl start node_exporter
sudo systemctl status node_exporter
sudo firewall-cmd --zone=public --add-port=9100/tcp --permanent
sudo firewall-cmd --reload
sudo setenforce 0
sudo sed -i "s/SELINUX=enforcing/SELINUX=disabled/g" /etc/selinux/config
```

## 结果测试
### prometheus 10.172.49.1
[http://10.172.49.1:9090/targets](http://10.172.49.1:9090/targets)
![图片](https://uploader.shimo.im/f/0k0hK9EMOZMBOCS8.png!thumbnail)
打开CBSS2和XKF，网页上搜索IP。如果显示UP代表OK。
### prometheus 10.172.49.24
[http://10.172.49.24:9090/targets](http://10.172.49.24:9090/targets)
![图片](https://uploader.shimo.im/f/YKGZmAYhQdcvjuIO.png!thumbnail)

## FAQ：
### 1 ssh链接不上
只需要给firewalld添加该tcp的端口规则，则可以正常访问了。
//允许某端口放行
# firewall-cmd --permanent --add-port=3389/tcp

![](https://raw.githubusercontent.com/samucc/mypicbed/master/images/20190807161513.png)
1 启动防火墙
2 添加tcp端口，重载防火墙规则
3 关闭防火墙
即可
不用关闭iptables，也不用启动防火墙。保持原有的状态。

## 回退操作
```
# ansible ipmi_rongzai_yanshou -m shell -a "rm -rf /home/deployer/node_exporter-0.15.2.linux-amd64.tar.gz" --sudo

# ansible ipmi_rongzai_yanshou -m shell -a "rm -rf /home/deployer/node_exporter.service" --sudo

# ansible ipmi_rongzai_yanshou -m shell -a "rm -rf /lib/systemd/system/node_exporter.service" --sudo

# ansible ipmi_rongzai_yanshou -m shell -a "echo '/bin/systemctl start node_exporter' >> /etc/rc.local" --sudo-sudo

# ansible ipmi_rongzai_yanshou -m shell -a "systemctl disable node_exporter" --sudo

# ansible ipmi_rongzai_yanshou -m shell -a "systemctl stop node_exporter" --sudo
```

