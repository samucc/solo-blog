title: WEB页集成AliPlayer
date: '2019-07-05 15:51:10'
updated: '2019-07-05 16:09:48'
tags: [AliPlayer, 视频播放]
permalink: /articles/2019/07/05/1562313070127.html
---
# 官方参考
[Demo地址](https://player.alicdn.com/aliplayer/presentation/index.html?type=cover)
[接口说明](https://help.aliyun.com/document_detail/62941.html?spm=a2c4g.11186623.6.713.Q0wYfV)

# WEB集成
## 下载播放器需要的js，css，img等资源
[图片下载地址](`https://g.alicdn.com/de/prismplayer/2.8.2/skins/default/img/bigplay.png`)
替换bigplay为bigplay,cc,dragcursor,dragcursorhover,fullscreen,pauseanimation,playanimation,setting,smallpause,smallplay,smallscreen,snapshot,volume。
一共十三个文件。

[aliplayercomponents.min.js](https://player.alicdn.com/aliplayer/presentation/js/aliplayercomponents.min.js)
[aliplayer-min.js](https://g.alicdn.com/de/prismplayer/2.8.2/aliplayer-min.js)
[aliplayer-min.css](https://g.alicdn.com/de/prismplayer/2.8.2/skins/default/aliplayer-min.css)
资源图如下
![](https://raw.githubusercontent.com/samucc/mypicbed/master/images/20190705154738.png)

## 初始化代码
```
player = new Aliplayer({
        id: "player-con",
        source: cur_video_path,
        width: "100%",
        height: "500px",
        autoplay: true,//是否自动播放
        isLive: false,//是不是直播
        "extraInfo": {//定制型接口参数
            "crossOrigin": "anonymous"
        },
        "skinLayout": [//按钮UI
            { "name": "bigPlayButton", "align": "blabs", "x": 30, "y": 80 },
            { "name": "H5Loading", "align": "cc" },
            { "name": "errorDisplay", "align": "tlabs", "x": 0, "y": 0 },
            { "name": "infoDisplay" },
            { "name": "tooltip", "align": "blabs", "x": 0, "y": 56 },
            { "name": "thumbnail" },
            {
                "name": "controlBar", "align": "blabs", "x": 0, "y": 0,
                "children": [
                  { "name": "progress", "align": "blabs", "x": 0, "y": 44 },
                  { "name": "playButton", "align": "tl", "x": 15, "y": 12 },
                  { "name": "timeDisplay", "align": "tl", "x": 10, "y": 7 },
                  { "name": "fullScreenButton", "align": "tr", "x": 10, "y": 12 },
                  { "name": "subtitle", "align": "tr", "x": 15, "y": 12 },
                  { "name": "setting", "align": "tr", "x": 15, "y": 12 },
                  { "name": "volume", "align": "tr", "x": 5, "y": 10 },
                  { "name": "snapshot", "align": "tr", "x": 10, "y": 12 }
                ]
            }
        ],
          //https://g.alicdn.com/de/prismplayer/2.8.2/skins/default/img/bigplay.png
        progressMarkers:[
            {
              offset: 30,
              isCustomized:true,
              coverUrl: 'https://alivc-demo-vod.aliyuncs.com/image/cover/9A3F562E595E4764AD1DD546FA52C6E5-6-2.png',
              title: 'test title',
              describe: 'test string',
            },
            {
              offset:50,
              isCustomized:true,
              coverUrl: 'https://alivc-demo-vod.aliyuncs.com/image/cover/1E7F402241CD4C0F94AD2BBB5CCC3EC7-6-2.png',
              title: 'test title',
              describe: 'test string',
            },
            {
              offset:150,
              isCustomized:true,
              coverUrl: 'https://alivc-demo-vod.aliyuncs.com/image/cover/553AEA01161342C8A2B1756E83B69B5B-6-2.png',
              title: 'test title',
              describe: 'test string',
            }, {
              offset:120,
              isCustomized:true,
              coverUrl: 'https://alivc-demo-vod.aliyuncs.com/image/cover/553AEA01161342C8A2B1756E83B69B5B-6-2.png',
              title: 'test title',
              describe: 'test string',
            }
        ],
        components: [
            {
              name: 'MemoryPlayComponent',
              type: AliPlayerComponent.MemoryPlayComponent,
              args: [true] //记忆自动播放
            },
            {
              name: 'ProgressComponent',
              type: AliPlayerComponent.ProgressComponent
            },
            {
              name: 'PlaylistComponent',
              type: AliPlayerComponent.PlaylistComponent,
              args: [
              video_list
              ]
            }
        ]
    }, function (player) {
        console.log("The player is created");
    });
```

## 使用的组件插件
### 记忆播放：(点击播放，自动播放）

```
<div id="player-con"></div>
<script>
  var player = new Aliplayer({
    id: "player-con",
    source: "//player.alicdn.com/video/editor.mp4",
    width: "100%",
    height: "500px",
    autoplay: true,
    isLive: false,
    components: [{
      name: 'MemoryPlayComponent',
      type: AliPlayerComponent.MemoryPlayComponent,
    }]
  }, function (player) {
    console.log("The player is created");
  });
</script>


<div id="player-con"></div>
<script>
  var player = new Aliplayer({
    id: "player-con",
    source: "//player.alicdn.com/video/editor.mp4",
    width: "100%",
    height: "500px",
    autoplay: true,
    isLive: false,
    components: [{
      name: 'MemoryPlayComponent',
      type: AliPlayerComponent.MemoryPlayComponent,
      /* Set the first parameter to true to enable auto play. The default is false. */
      args: [true]
    }]
  }, function (player) {
    console.log("The player is created");
  });
</script
```
### 视频打点

```
<div id="player-con"></div>
<script>
  var player = new Aliplayer({
    id: "player-con",
    source: "//player.alicdn.com/video/editor.mp4",
    width: "100%",
    height: "500px",
    autoplay: true,
    isLive: false,
    progressMarkers:[{
      offset: 30,
      isCustomized:true,
      coverUrl: 'https://alivc-demo-vod.aliyuncs.com/image/cover/9A3F562E595E4764AD1DD546FA52C6E5-6-2.png',
      title: 'test title',
      describe: 'test string',
    }, {
      offset:50,
      isCustomized:true,
      coverUrl: 'https://alivc-demo-vod.aliyuncs.com/image/cover/1E7F402241CD4C0F94AD2BBB5CCC3EC7-6-2.png',
      title: 'test title',
      describe: 'test string',
    }, {
      offset:150,
      isCustomized:true,
      coverUrl: 'https://alivc-demo-vod.aliyuncs.com/image/cover/553AEA01161342C8A2B1756E83B69B5B-6-2.png',
      title: 'test title',
      describe: 'test string',
    }, {
      offset:120,
      isCustomized:true,
      coverUrl: 'https://alivc-demo-vod.aliyuncs.com/image/cover/553AEA01161342C8A2B1756E83B69B5B-6-2.png',
      title: 'test title',
      describe: 'test string',
    }],
    components: [{
      name: 'ProgressComponent',
      type: AliPlayerComponent.ProgressComponent
    }]
  }, function (player) {
    console.log("The player is created");
  });
</script>
```
### 播放列表:

```
<div id="player-con"></div>
<script>
  var player = new Aliplayer({
    id: "player-con",
    source: "//player.alicdn.com/video/editor.mp4",
    width: "100%",
    height: "500px",
    autoplay: true,
    isLive: false,
    components: [{
      name: 'PlaylistComponent',
      type: AliPlayerComponent.PlaylistComponent,
      args: [[{
        name: '阿里云播放器介绍',
        source: '//player.alicdn.com/video/editor.mp4'
      }, {
        name: '趣拍演示视频',
        source: '//player.alicdn.com/resource/player/qupai.mp4'
      }, {
        name: '云栖大会',
        source: 'http://player.pier39.cn/video/yunxi.mp4'
      }, {
        name: '4K 阿里视频云介绍',
        source: 'https://player.alicdn.com/video/apsaravideo4k.mp4'
      }]]
    }]
  }, function (player) {
    console.log("The player is created");
  });
</script>
```

### 截图
```
<div id="player-con"></div>
<script>
  var player = new Aliplayer({
    id: "player-con",
    source: "//player.alicdn.com/video/editor.mp4",
    width: "100%",
    height: "500px",
    autoplay: true,
    isLive: false,
    "extraInfo": {
      "crossOrigin": "anonymous"
    },
    "skinLayout": [
      { "name": "bigPlayButton", "align": "blabs", "x": 30, "y": 80 },
      { "name": "H5Loading", "align": "cc" },
      { "name": "errorDisplay", "align": "tlabs", "x": 0, "y": 0 },
      { "name": "infoDisplay" },
      { "name": "tooltip", "align": "blabs", "x": 0, "y": 56 },
      { "name": "thumbnail" },
      { 
        "name": "controlBar", "align": "blabs", "x": 0, "y": 0,
        "children": [
          { "name": "progress", "align": "blabs", "x": 0, "y": 44 },
          { "name": "playButton", "align": "tl", "x": 15, "y": 12 },
          { "name": "timeDisplay", "align": "tl", "x": 10, "y": 7 },
          { "name": "fullScreenButton", "align": "tr", "x": 10, "y": 12 },
          { "name": "subtitle", "align": "tr", "x": 15, "y": 12 },
          { "name": "setting", "align": "tr", "x": 15, "y": 12 },
          { "name": "volume", "align": "tr", "x": 5, "y": 10 },
          { "name": "snapshot", "align": "tr", "x": 10, "y": 12 }
        ]
      }
    ]
  }, function (player) {
    console.log("The player is created");
  });

  /* HTML5 snapshot button and success callback */
  player.on('snapshoted', function (data) {
    var pictureData = data.paramData.base64
    var downloadElement = document.createElement('a')
    downloadElement.setAttribute('href', pictureData)
    var fileName = 'Aliplayer' + Date.now() + '.png'
    downloadElement.setAttribute('download', fileName)
    downloadElement.click()
    pictureData = null
  })
</script>
```

## 事件
### 暂停事件
```
player.on('pause',function(e) {
        console.log(player.getSourceUrl());
        var current_time_seconds = player.getCurrentTime();
        var result = sec_to_time(current_time_seconds);
    });
```
### ready事件
```
player.on('ready',function(e) {
        //播放列表切换属于ready事件里面的操作
}
```
## 播放器页面快捷键设置
```
//播放器快捷键
document.onkeydown=function(e) {
    var keyNum = window.event ? e.keyCode : e.which;
    //空格暂停播放
    if (keyNum == '32') {
        var videoplay = $('input[name="videoplay"]').val();//定义一个隐藏域 来区分播放状态
        if (videoplay == "0") {
            player.pause();
            $('input[name="videoplay"]').val(1);
        } else {
            player.play();
            $('input[name="videoplay"]').val(0);
        }
    } else if (keyNum == '37') {//快进
        var videotimes = player.getDuration();
        var playnum = player.getCurrentTime();
        playnum = parseInt(playnum - 10);
        if (playnum <= (videotimes - 30)) {
            player.seek(playnum);
        }
    } else if(keyNum=='39'){//快退
        var videotimes = player.getDuration();
        var playnum = player.getCurrentTime();
        playnum =parseInt(playnum +10);
        if(playnum>15){
            player.seek(playnum);
        }else{
            player.seek(0);
        }
    }else if(keyNum=='38'){ //音量大小 //获得当前音量
        var volume =parseInt(player.getVolume()*100);
        if(volume<100){
            volume = (volume+1)/100;
            player.setVolume(volume);
        }
    }else if(keyNum=='40'){
        var volume =parseInt(player.getVolume()*100);
        if(volume>0){
            volume = (volume-1)/100;
            player.setVolume(volume);
        }
    }
};
```

## 时分秒 与 秒 互转
```
/** * 时间秒数格式化 * @param s 秒数 * @returns {*} 格式化后的时分秒 */
function sec_to_time (s) {
    var t;
    if(s > -1){
        var hour = Math.floor(s/3600);
        var min = Math.floor(s/60) % 60;
        var sec = s % 60;
        if(hour < 10) {
            t = '0'+ hour + ":";
        } else {
            t = hour + ":";
        }

        if(min < 10){t += "0";}
        t += min + ":";
        if(sec < 10){t += "0";}
        t += sec.toFixed(2);
    }
    return t;
};
/** * 时间转为秒 * @param time 时间(00:00:00) * @returns {string} 秒数 */
function time_to_sec(time) {
    var s = '';

    var hour = time.split(':')[0];
    var min = time.split(':')[1];
    var sec = time.split(':')[2];

    s = Number(hour*3600) + Number(min*60) + Number(sec);

    return s;
};
```

## 效果图
![](https://raw.githubusercontent.com/samucc/mypicbed/master/images/20190705160904.png)