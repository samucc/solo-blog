title: 免费申请GCP资源 SSR VPN搭建
date: '2019-07-03 10:02:56'
updated: '2019-07-03 10:02:56'
tags: [GCP, SSR, VPN]
permalink: /articles/2019/07/03/1562119376259.html
---
# 免费申请GCP资源（Google Cloud Platform）VPN SSR搭建
参考：[Google Cloud Platform免费申请&一键搭建SSR & BBR加速教程](https://www.wmsoho.com/google-cloud-platform-ssr-bbr-tutorial/)

生成密钥：
[https://cloud.google.com/compute/docs/instances/adding-removing-ssh-keys?hl=zh-CN](https://cloud.google.com/compute/docs/instances/adding-removing-ssh-keys?hl=zh-CN)
![](https://raw.githubusercontent.com/samucc/mypicbed/master/images/20190703100050.png)

创建好的GCP实例：
![](https://raw.githubusercontent.com/samucc/mypicbed/master/images/20190703100020.png)