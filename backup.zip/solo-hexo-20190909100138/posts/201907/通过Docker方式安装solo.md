title: 通过Docker方式安装solo
date: '2019-07-02 11:30:41'
updated: '2019-07-02 17:50:16'
tags: [solo安装, docker]
permalink: /articles/2019/07/02/1562038241065.html
---
# 准备服务器
# 下载源码（未用到）

[https://github.com/b3log/solo/tree/v3.6.2](https://github.com/b3log/solo/tree/v3.6.2)

```
cd /opt
git clone https://github.com/b3log/solo.git
```

# 安装mariadb

```
# 安装 MySQL, 如果不使用 Mysql 可以跳过相关 Mysql 安装和配置, 支持sqlite3, mysql, postgres等
$ yum -y install mariadb mariadb-devel mariadb-server MariaDB-shared # centos7下叫mariadb, 用法与mysql一致
$ systemctl enable mariadb
$ systemctl start mariadb
# 创建数据库 Jumpserver 并授权
$ DB_PASSWORD=`cat /dev/urandom | tr -dc A-Za-z0-9 | head -c 24`  # 生成随机数据库密码
$ echo -e "\033[31m 你的数据库密码是 $DB_PASSWORD \033[0m"
$ mysql -uroot -e "create database solo default charset 'utf8'; grant all on solo.* to 'solo'@'127.0.0.1' identified by '$DB_PASSWORD'; flush privileges;"

mysql
update user set password=password("password") where user='root';
grant all on solo.* to 'solo'@'localhost' identified by 'password'; flush privileges;
FLUSH PRIVILEGES;
``````

你的数据库密码是 cUfgue4hUoDyL2UxN9G1pGLn
<img src="https://uploader.shimo.im/f/r754UJoyAK8Ee5Gs.png"/>



域名解析到公网地址

<img src='https://uploader.shimo.im/f/IxyJhfVKtfkA5Jdk.png'/>


# 安装 Nginx
$ vi /etc/yum.repos.d/nginx.repo
```
[nginx]
name=nginx repo
baseurl=http://nginx.org/packages/centos/7/$basearch/
gpgcheck=0
enabled=1
```
$ yum -y install nginx
$ systemctl enable nginx


vim /etc/nginx/conf.d/solo.conf

```
server {
   listen        80;
   server_name    jiashu.club;
   client_max_body_size 100m;
   access_log     off;

   location / {
        proxy_pass http://localhost:8080;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header Host $host;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }
```


# 删除docker


```yum remove docker*```


# 安装 docker 部署 solo
```
$ yum install -y yum-utils device-mapper-persistent-data lvm2
$ yum-config-manager --add-repo http://mirrors.aliyun.com/docker-ce/linux/centos/docker-ce.repo
$ yum makecache fast
$ rpm --import https://mirrors.aliyun.com/docker-ce/linux/centos/gpg
$ yum -y install docker-ce
$ systemctl enable docker
$ curl -sSL https://get.daocloud.io/daotools/set_mirror.sh | sh -s http://f1361db2.m.daocloud.io
$ systemctl restart docker
```

# Docker 部署

获取最新镜像：

```docker pull b3log/solo```

使用 MySQL

先手动建库（库名 solo，字符集使用 utf8mb4，排序规则 utf8mb4_general_ci），然后启动容器：

```
docker run --detach --name solo --network=host \
    --env RUNTIME_DB="MYSQL" \
    --env JDBC_USERNAME="solo" \
    --env JDBC_PASSWORD="password" \
    --env JDBC_DRIVER="com.mysql.cj.jdbc.Driver" \
    --env JDBC_URL="jdbc:mysql://127.0.0.1:3306/solo?useUnicode=yes&characterEncoding=UTF-8&useSSL=false&serverTimezone=UTC" \
    b3log/solo --listen_port=80 --server_scheme=http --server_host=jiashu.club 
```

启动参数说明：

*   --listen_port：进程监听端口
*   --server_scheme：最终访问协议，如果反代服务启用了 HTTPS 这里也需要改为 https
*   --server_host：最终访问域名或公网 IP，不要带端口号

完整启动参数的说明可以使用 -h 来查看。


# Docker 升级

1.  拉取最新镜像
2.  重启容器

可参考如下重启脚本，并通过 crontab 每日凌晨运行来实现自动更新。

`docker-restart.sh`

```
#!/bin/bash


#
# Solo docker 更新重启脚本
#
# 1. 请注意修改参数
# 2. 可将该脚本加入 crontab，每日凌晨运行来实现自动更新
#


docker pull b3log/solo
docker stop solo
docker rm solo
docker run --detach --name solo --network=host \
    --env RUNTIME_DB="MYSQL" \
    --env JDBC_USERNAME="solo" \
    --env JDBC_PASSWORD="password" \
    --env JDBC_DRIVER="com.mysql.cj.jdbc.Driver" \
    --env JDBC_URL="jdbc:mysql://127.0.0.1:3306/solo?useUnicode=yes&characterEncoding=UTF-8&useSSL=false&serverTimezone=UTC" \
    b3log/solo --listen_port=8080 --server_scheme=http --server_host=jiashu.club
   
```

# Docker Compose

请参考[这里](https://github.com/liumapp/solo-in-docker)，感谢 [@liumapp](https://github.com/liumapp) 提供 ❤️

[百度站长统计](https://tongji.baidu.com/web/help/article?id=170&type=0)
[查看统计](https://tongji.baidu.com/sc-web/10000007109/home/site/index?siteId=13626423)