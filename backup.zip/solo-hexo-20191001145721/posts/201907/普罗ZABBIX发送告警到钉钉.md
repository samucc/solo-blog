title: 普罗-ZABBIX发送告警到钉钉
date: '2019-07-16 15:47:35'
updated: '2019-07-16 15:48:56'
tags: [普罗, ZABBIX, 告警.钉钉]
permalink: /articles/2019/07/16/1563263254966.html
---
# 自定义机器人  
获取自定义机器人webhook
[https://open-doc.dingtalk.com/docs/doc.htm?treeId=257&articleId=105735&docType=1](https://open-doc.dingtalk.com/docs/doc.htm?treeId=257&articleId=105735&docType=1)

钉钉API：
```
钉钉机器人token：https://oapi.dingtalk.com/robot/send?access_token=24c0b36c8b7cccbd97c2fa4371a3c238710a51e832084c3d3f086057fe807441
端口：65500
```

# 安装Webhook
10.127.128.1  prometheus-webhook-dingtalk
[prometheus-webhook-dingtalk](https://uploader.shimo.im/f/soMmfNzTpzEeyRqg)

源码安装参考：[https://blog.csdn.net/AlbertFly/article/details/83414432](https://blog.csdn.net/AlbertFly/article/details/83414432)
[http://www.cnblogs.com/pyuh/articles/9544121.html](http://www.cnblogs.com/pyuh/articles/9544121.html)
插件下载地址：[https://github.com/timonwong/prometheus-webhook-dingtalk](https://github.com/timonwong/prometheus-webhook-dingtalk)

```
usage: prometheus-webhook-dingtalk --ding.profile=DING.PROFILE [<flags>]
Flags:
  -h, --help             Show context-sensitive help (also try --help-long and --help-man).
      --web.listen-address=":8060"
                         The address to listen on for web interface.
      --ding.profile=DING.PROFILE ...
                         Custom DingTalk profile (can specify multiple times, <profile>=<dingtalk-url>).
      --ding.timeout=5s  Timeout for invoking DingTalk webhook.
      --log.level=info   Only log messages with the given severity or above. One of: [debug, info, warn, error]
      --version          Show application version.

```
## 开放路由给AlertManager
默认监听在8060端口（可配置）上   启动命令：
```
/bin/nohup ./prometheus-webhook-dingtalk  --ding.profile="webhook1= https://oapi.dingtalk.com/robot/send?access_token=24c0b36c8b7cccbd97c2fa4371a3c238710a51e832084c3d3f086057fe807441"  --web.listen-address=":65500" --template.file=dingtalk.tmpl &
```
这里就定义了两个 WebHook，一个 webhook1，用来往不同的钉钉组发送报警消息。然后在 [AlertManager](https://github.com/prometheus/alertmanager) 的配置里面，加入相应的 receiver（注意下面的 url）即可：

webhook2=[https://oapi.dingtalk.com/robot/send?access_token=ad8b0743d5ffd369b68e846dda78205d8ae13d81d14863059917e6d5de6a5e57](https://oapi.dingtalk.com/robot/send?access_token=ad8b0743d5ffd369b68e846dda78205d8ae13d81d14863059917e6d5de6a5e57)
# AlertManager配置：
其他组件：[https://www.tidb.cc/Monitor/170607-AlertManager.html](https://www.tidb.cc/Monitor/170607-AlertManager.html)

钉钉组件
```
- name: 'send_to_dingding_webhook1'
  webhook_configs:
  - send_resolved: false
    url: 'http://10.127.128.1:65500/dingtalk/webhook1/send'
```

使用webhook扩展alertmanager：
[http://ylzheng.com/2018/03/01/alertmanager-webhook-dingtalk/](http://ylzheng.com/2018/03/01/alertmanager-webhook-dingtalk/)

# 外网-Zabbix实现推送到钉钉（暂时不用）
[https://huangwj.app/monitor/zabbix/python%E5%AE%9E%E7%8E%B0zabbix%E5%91%8A%E8%AD%A6%E6%8E%A8%E9%80%81%E9%92%89%E9%92%89.html](https://huangwj.app/monitor/zabbix/python%E5%AE%9E%E7%8E%B0zabbix%E5%91%8A%E8%AD%A6%E6%8E%A8%E9%80%81%E9%92%89%E9%92%89.html)
[https://blog.csdn.net/u010871982/article/details/80469859](https://blog.csdn.net/u010871982/article/details/80469859)
[https://blog.csdn.net/u010871982/article/details/79229953](https://blog.csdn.net/u010871982/article/details/79229953)
[https://www.linuxidc.com/Linux/2017-12/149953.htm](https://www.linuxidc.com/Linux/2017-12/149953.htm)

# 内网-Zabbix 使用AlertManager的路由地址
[https://blog.csdn.net/u010871982/article/details/79229953?utm_source=blogxgwz8](https://blog.csdn.net/u010871982/article/details/79229953?utm_source=blogxgwz8)
测试：
![图片](https://uploader.shimo.im/f/ssdbrPiLrQIafswI.png!thumbnail)
## url
http://10.127.128.1:65500/dingtalk/webhook1/send
## 发送报文
一个合格的报警通知，应该包含如下内容：
* 报警级别
* 简短的报警名称
* 简要说明
* 详细说明
* 附加上下文信息
* 一个链接，点击后进入指标的 Graph

样例：[https://github.com/timonwong/prometheus-webhook-dingtalk/blob/master/examples/send_alerts.sh](https://github.com/timonwong/prometheus-webhook-dingtalk/blob/master/examples/send_alerts.sh)
```
{
    "receiver": "admins",
    "status": "firing",
    "alerts": [
        {
            "status": "firing",
            "labels": {
                "alertname": "test something_happend",
                "env": "prod",
                "instance": "server01.int:9100",
                "job": "node",
                "service": "prometheus_bot",
                "severity": "warning",
                "supervisor": "runit"
            },
            "annotations": {
                "summary": "Oops, something happend!"
            },
            "startsAt": "2016-04-27T20:46:37.903Z",
            "endsAt": "0001-01-01T00:00:00Z",
            "generatorURL": "https://example.com/graph#..."
        }
    ],
    "groupLabels": {
        "alertname": "something_happend",
        "instance": "server01.int:9100"
    },
    "commonLabels": {
        "alertname": "something_happend",
        "env": "prod",
        "instance": "server01.int:9100",
        "job": "node",
        "service": "prometheus_bot",
        "severity": "warning",
        "supervisor": "runit"
    },
    "commonAnnotations": {
        "summary": "runit service prometheus_bot restarted, server01.int:9100"
    },
    "externalURL": "https://alert-manager.example.com",
    "version": "3"
}
```


```
curl -H "Content-Type:application/json" -X POST -d '{"receiver":"admins","status":"firing","alerts":[{"status":"firing","labels":{"alertname":"testsomething_happend","env":"prod","instance":"server01.int:9100","job":"node","service":"prometheus_bot","severity":"warning","supervisor":"runit"},"annotations":{"summary":"Oops,somethinghappend!"},"startsAt":"2016-04-27T20:46:37.903Z","endsAt":"0001-01-01T00:00:00Z","generatorURL":"https://example.com/graph#..."}],"groupLabels":{"alertname":"something_happend","instance":"server01.int:9100"},"commonLabels":{"alertname":"something_happend","env":"prod","instance":"server01.int:9100","job":"node","service":"prometheus_bot","severity":"warning","supervisor":"runit"},"commonAnnotations":{"summary":"runitserviceprometheus_botrestarted,server01.int:9100"},"externalURL":"https://alert-manager.example.com","version":"3"}' http://10.127.128.1:8094/dingtalk/ops_dingding/send
```
## 发送结果
![图片](https://uploader.shimo.im/f/E9KcNrrJcdoLt1Hb.png!thumbnail)


## 目标样式
参考：[http://theo.im/blog/2017/10/16/release-prometheus-alertmanager-webhook-for-dingtalk/](http://theo.im/blog/2017/10/16/release-prometheus-alertmanager-webhook-for-dingtalk/)

![图片](https://uploader.shimo.im/f/NbUr9xjcRLAqQbdY.png!thumbnail)
## 下载最新release版本：
[https://github.com/timonwong/prometheus-webhook-dingtalk/releases](https://github.com/timonwong/prometheus-webhook-dingtalk/releases)
![图片](https://uploader.shimo.im/f/GQjqlDKsqnc1DPeJ.png!thumbnail)
[prometheus-webhook-dingtalk](https://uploader.shimo.im/f/daghIfJfRW0Nb3Ea)


[default.tmpl](https://uploader.shimo.im/f/VxOBMaiosMUAvbNV.tmpl)


配置tmpl
[https://github.com/timonwong/prometheus-webhook-dingtalk/issues/8](https://github.com/timonwong/prometheus-webhook-dingtalk/issues/8)
配置 dingtalk.tmpl 即可

# prometheus使用webhook进行钉钉告警推送
参考地址：[https://github.com/timonwong/prometheus-webhook-dingtalk/blob/d04cd50b81e76af555fdb108a559a8a432a8dc4e/template/default.tmpl](https://github.com/timonwong/prometheus-webhook-dingtalk/blob/d04cd50b81e76af555fdb108a559a8a432a8dc4e/template/default.tmpl)

## golang template
```
{{ define "__subject" }}[{{ .Status | toUpper }}{{ if eq .Status "firing" }}:{{ .Alerts.Firing | len }}{{ end }}] {{ .GroupLabels.SortedPairs.Values | join " " }} {{ if gt (len .CommonLabels) (len .GroupLabels) }}({{ with .CommonLabels.Remove .GroupLabels.Names }}{{ .Values | join " " }}{{ end }}){{ end }}{{ end }}




{{ define "__alertmanagerURL" }}{{ .ExternalURL }}/#/alerts?receiver={{ .Receiver }}{{ end }}




{{ define "__text_alert_type" }}
{{ range .Annotations.SortedPairs }}
{{if eq .Name "summary"}} # {{ .Value | markdown | html }} # {{ end }}
{{ end }}


{{ end }}


{{/*
{{ define "__text_alert_list" }}{{ range . }}


*/}}


{{ define "__text_alert_list" }}{{ range $i, $v := .}}
## 第{{ $i }}条消息


{{ template "__text_alert_type" . }}


### 产生时间: {{ .StartsAt | printf "%.19s" }}(CST)


{{ range .Labels.SortedPairs }}
{{if eq .Name "collect"}}>- 收集节点: {{ .Value | markdown | html }}  {{ end }}
{{if eq .Name "instance"}}>- 主机IP: {{ .Value | markdown | html }}  {{ end }}
{{if eq .Name "job"}}>- 节点角色: {{ .Value | markdown | html }}  {{ end }}
{{if eq .Name "service"}}>- 服务名称: {{ .Value | markdown | html }}  {{ end }}
{{if eq .Name "severity"}}>- 严重等级: **{{ .Value | markdown | html }}** {{end }}
{{if eq .Name "type"}}>- 服务器类型: {{ .Value | markdown | html }}  {{ end }}
{{if eq .Name "zone"}}>- 归属位置: {{ .Value | markdown | html }}  {{ end }}
{{if eq .Name "mountpoint"}}>- 挂载点: {{ .Value | markdown | html }}  {{ end }}


{{ end }}


>- 描述: {{ index .Annotations "description" }}


- - -


{{ end }}{{ end }}


{{ define "ding.link.title" }}{{ template "__subject" . }}{{ end }}


{{/*
{{ define "ding.link.content" }}{{ if eq .Status "resolved" }} \[已解除]{{ index .CommonAnnotations "summary" }}{{ end }}
*/}}


{{ define "ding.link.content" }}# \[{{ .Status | toUpper }}{{ if eq .Status "firing" }}:{{ .Alerts.Firing | len }}{{ end }}\] **[{{ index .GroupLabels "alertname" }}]({{ template "__alertmanagerURL" . }})**
{{ template "__text_alert_list" .Alerts.Firing }}
```
{{ end }}



## 其他：
Alertmanager api：
[http://www.techscore.com/blog/2017/12/18/prometheus-alermanager-api/](http://www.techscore.com/blog/2017/12/18/prometheus-alermanager-api/)

[http://10.172.49.23:9093/api/v1/alerts](http://10.172.49.23:9093/api/v1/alerts)
[
  {
    "labels": {
      "alertname": "Test_Alert",
      "instance": "node0"
    },
    "annotations": {
      "link": "https://example.com",
      "summary": "This is a testing alert!"
    },
    "startsAt": "2018-12-18T14:55:24Z",
    "generatorURL": "http://my.testing.script.local" 
  }
]

{
    "status": "success"
}

## ZABBIX配置
配置媒介类型
![图片](https://uploader.shimo.im/f/w44smc79ix0Xbnxk.png!thumbnail)
![图片](https://uploader.shimo.im/f/LUKKS1x4Yz4yStRe.png!thumbnail)
![图片](https://uploader.shimo.im/f/IvOvQf5ygjAaPZ1I.png!thumbnail)
ZABBIX宏使用场景：[https://www.zabbix.com/documentation/4.0/zh/manual/appendix/macros/supported_by_location](https://www.zabbix.com/documentation/4.0/zh/manual/appendix/macros/supported_by_location)
```
#问题：
Problem started at {EVENT.TIME} on {EVENT.DATE}
Problem name: {EVENT.NAME}
Host: {HOST.NAME}
Severity: {EVENT.SEVERITY}

Original problem ID: {EVENT.ID}
URL:http://10.238.0.33/zabbix/tr_events.php?triggerid{TRIGGER.ID}&eventid={EVENT.ID}

#恢复：
Problem has been resolved at {EVENT.RECOVERY.TIME} on {EVENT.RECOVERY.DATE}
Problem name: {EVENT.NAME}
Host: {HOST.NAME}
Severity: {EVENT.SEVERITY}
Age: {EVENT.AGE}  at {EVENT.DATE} {EVENT.TIME}

Original problem ID: {EVENT.ID}
URL:http://10.238.0.33/zabbix/tr_events.php?triggerid{TRIGGER.ID}&eventid={EVENT.ID}

```

```
#!/usr/bin/env python3
# encoding: utf-8

import sys
import getopt
import requests
import json
import traceback
try:
    opts,args = getopt.getopt(sys.argv[1:],shortopts='',longopts=['webhook_url=','webhook_title=','alert_message=','trigger_url='])
    for opt,value in opts:
        if opt == '--webhook_url':
            webhook_url = value
        elif opt == '--webhook_title':
            webhook_title = value
        elif opt == '--alert_message':
            alert_message = value
        elif opt == '--trigger_url':
            trigger_url = value
    webhook_header = {
            "Content-Type": "application/json",
            "charset": "utf-8"
        }
    webhook_message = {
		"receiver": "admins",
		"status": "firing",
		"alerts": [
			{
				"status": "firing",
				"labels": {
					"消息": "{}".format(alert_message)
				},
				"annotations": {
					"summary": "Oops, here comes the surprise!"
				},
				"generatorURL": "{}".format(trigger_url)
			}
		],
		"groupLabels": {
			"alertname": "{}".format(webhook_title)
		},
		"version": "3"
	}
    sendData = json.dumps(webhook_message,indent=1)
    requests.post(url=webhook_url,headers=webhook_header,data=sendData)
except:
    traceback.print_exc(file=open('/tmp/alert_zabbix_dingding.log','w+'))

```

测试命令：
```
python dingding_inter.py --webhook_url=http://10.127.128.1:65500/dingtalk/webhook2/send --webhook_title={ALERT.SUBJECT} --alert_message={ALERT.MESSAGE} --trigger_url={TRIGGER.URL}
```

