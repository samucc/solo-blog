title: Mapbox地图本地离线部署 离线地图
date: '2019-07-16 15:11:34'
updated: '2019-07-16 15:15:22'
tags: [Mapbox离线地图, 瓦片文件下载]
permalink: /articles/2019/07/16/1563261094665.html
---
# Mapbox地图本地离线部署


==================

参考：[https://www.jianshu.com/p/43ce4591c621](https://www.jianshu.com/p/43ce4591c621)

[https://www.cnblogs.com/ATtuing/p/9216782.html](https://www.cnblogs.com/ATtuing/p/9216782.html)

 

Mapbox官方示例：[https://docs.mapbox.com/mapbox-gl-js/example](https://docs.mapbox.com/mapbox-gl-js/example)

## 下载前6层瓦片


-----------

[https://openmaptiles.com/downloads/tileset/satellite/asia/china/](https://openmaptiles.com/downloads/tileset/satellite/asia/china/)

Google Maps瓦片(tile)地图文件下载(1-11层级)

详细说明：[http://rovertang.com/google-maps-tile-files-download-level-1-11/](http://rovertang.com/google-maps-tile-files-download-level-1-11/)

下载链接: [https://pan.baidu.com/s/1hnypV8AOutJuat194aBxZA](https://pan.baidu.com/s/1hnypV8AOutJuat194aBxZA) 密码: pgyas

使用png图片代码

参考：[https://www.jianshu.com/p/43ce4591c621](https://www.jianshu.com/p/43ce4591c621)

```
 "sources": {
     "osm-tiles": {
         "type": "raster",
         "tiles": [
                 "http://c.tile.openstreetmap.org/{z}/{x}/{y}.png"
          ],
          "tileSize": 256
       }
  },
  "layers":[{
      "id": "123",
       "type": "raster",
       "source": "osm-tiles",
       "source-layer": "osmtiles"
  }]
```

sources参数说明：

*   sources是地图资源对象，以key,value组成，sources里的key不能重复，唯一声明一个地图资源的组成。
*   value里的type是资源的类型，必须是 vector, raster, raster-dem, geojson, image, video中的一种。当前声明是xyz的png图片组成的底图，所以声明类型是raster。
*   value里的tiles是xyz底图的url模板组合，tileSize声明一个切片宽高，一般切片都是是256*256的，所以此处声明256 。

layers参数说明：

*   layers是个数组，数组每一项代表一个图层。
*   id是每个图层的主键，每个图层的id必须不能重复。
*   type，声明一个图层的类型。
*   source，图层的地图数据来源，指向sources里的某个key的资源定义，比如sources里定义了一个osm-tiles的资源，该图层数据来源指向这个资源，即将key的值输入此处。
*   source-layer：图层的名称，可以当做是图层别名，用以描述图层的。

  

[https://zhuanlan.zhihu.com/p/45518647](https://zhuanlan.zhihu.com/p/45518647)

   

[mapbox-gl-js-offline-example-gh-pages](https://github.com/klokantech/mapbox-gl-js-offline-example)

![null](https://uploader.shimo.im/f/kyZiLa6kSgsdzmka.png!thumbnail)

拷贝countries文件使用 只有6层

## Python生成第7层瓦片的下载列表 建议使用2<<6 包含7层所有瓦片文件


------------------------------------------

最好前6层也是下载 风格统一

```
##get layer 7's x,y,x streets data list
Z = 7
Y = 99 #2<<(Z-1)
X = Y
LIST=[]
for y in range(Y):
     for(x) in range(X):
         LIST.append("mapbox.mapbox-terrain-v2,mapbox.mapbox-streets-v7/{}/{}/{}.vector.pbf".format(Z,y,x))
```

## 下载瓦片文件Shell脚本


-----------------

[https://github.com/mapbox/awesome-vector-tiles](https://github.com/mapbox/awesome-vector-tiles)

 

[Converting Mapbox Studio Vector Tiles to Rasters](https://www.azavea.com/blog/2015/05/29/converting-mapbox-studio-vector-tiles-to-rasters-2/)

 

vector better than others:

[https://github.com/mapbox/vector-tile-spec/issues/53](https://github.com/mapbox/vector-tile-spec/issues/53)

[https://docs.mapbox.com/vector-tiles/specification/](https://docs.mapbox.com/vector-tiles/specification/)

```
#!/usr/bin/env bash


set -u


# IMPORTANT 列表项只想不要包含逗号
LIST=(
  'mapbox.mapbox-terrain-v2,mapbox.mapbox-streets-v7/7/0/0.vector.pbf'
  'mapbox.mapbox-terrain-v2,mapbox.mapbox-streets-v7/7/98/95.vector.pbf'
  'mapbox.mapbox-terrain-v2,mapbox.mapbox-streets-v7/7/98/96.vector.pbf'
  'mapbox.mapbox-terrain-v2,mapbox.mapbox-streets-v7/7/98/97.vector.pbf'
  'mapbox.mapbox-terrain-v2,mapbox.mapbox-streets-v7/7/98/98.vector.pbf'
)


## download streets data
for OUTPUT in ${LIST[@]} ; do
    echo ${OUTPUT}
    if [ ! -f "${OUTPUT}" ] ; then
        mkdir -p "`dirname "${OUTPUT}"`"
        echo "Downloading tile '${OUTPUT}'"
        curl -o "${OUTPUT}" -# "https://a.tiles.mapbox.com/v4/${OUTPUT}?access_token=${YOUR_TOKEN}"
    fi
do
``` 

## Python重命名文件，去掉.vector


-------------------------

```
##rename filename
import os
root_path = "/opt/jumpserver/apps/static/plugins/mapbox/countries/7"
def rename_file(root_path):
    for filename in os.listdir(root_path):
        file_obs_path = os.path.join(root_path,filename)
        if os.path.isfile(file_obs_path):
            dst_name = os.path.join(root_path,filename.replace(".vector",""))
            os.rename(file_obs_path, dst_name)
        else:
            rename_file(file_obs_path)
     
rename_file(root_path)
```

## Shell重命名文件中的逗号（由于下载时列表中的逗号导致）


---------------------------------

sh下载脚本列表不包含逗号可不跑这一步骤。由于包含了逗号 导致文件内容写的是

{"message":"not found"}

```
##!/bin/bash
##
## rename script
## rename.sh
clear
dir=$(ls -l . |awk '/^d/ {print $NF}')
for d in $dir
do
    echo $d
    x=0
    for i in `ls $d/*.pbf,`
    do
        x=`echo $i | sed 's/,//g'`
        echo $i,$x
        mv $i $x
    done
done
echo “rename done!”
```
```

## 使用HTML

```
{% load i18n %}
{% load static %}
<!--link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.css"-->


<style>
#map { position:absolute;
   top: 55px;
    bottom: 55px;
   max-width: 585px;
   width:100%;
}
.mapboxgl-popup {
   max-width: 400px;
   font: 12px/20px 'Helvetica Neue', Arial, Helvetica, sans-serif;
}
</style>


<div id='map'></div>


<script>
    var style = {
      "version": 8,
      "sources": {
        "countries": {
          "type": "vector",
          // "url": "mapbox://map-id"
          // "url": "http://tileserver.com/layer.json",
          "tiles": [location.origin+"/static/plugins/mapbox/countries/{z}/{x}/{y}.pbf"],
          "maxzoom": 7
        }
      },
      "glyphs": location.origin+"/static/plugins/mapbox/fonts/{fontstack}/{range}.pbf",
      "layers": [{
        "id": "background",
        "type": "background",
        "paint": {
          "background-color": "#ddeeff"
        }
      },{
        "id": "country-glow-outer",
        "type": "line",
        "source": "countries",
        "source-layer": "country",
        "layout": {
          "line-join":"round"
        },
        "paint": {
          "line-color": "#226688",
          "line-width": 5,
          "line-opacity": {
            "stops": [[0,0],[1,0.1]]
          }
        }
      },{
        "id": "country-glow-inner",
        "type": "line",
        "source": "countries",
        "source-layer": "country",
        "layout": {
          "line-join":"round"
        },
        "paint": {
          "line-color": "#226688",
          "line-width": {
            "stops": [[0,1.2],[1,1.6],[2,2],[3,2.4]]
          },
          "line-opacity":0.8,
        }
      // rainbow start
      },{
        "id": "area-white",
        "type": "fill",
        "source": "countries",
        "filter":["in","ADM0_A3",'ATA'],
        "source-layer": "country",
        "paint": {
          "fill-color": "#F0F8FF"
        }
      },{
        "id": "area-red",
        "type": "fill",
        "source": "countries",
        "filter":["in","ADM0_A3",'AFG','ALD','BEN','BLR','BWA','COK','COL','DNK','DOM','ERI','FIN','FRA','FRO','GIB','GNB','GNQ','GRC','GTM','JPN','KIR','LKA','MHL','MMR','MWI','NCL','OMN','RWA','SMR','SVK','SYR','TCD','TON','URY','WLF'],
        "source-layer": "country",
        "paint": {
          "fill-color": "#fdaf6b"
        }
      },{
        "id": "area-orange",
        "type": "fill",
        "source": "countries",
        "filter":["in","ADM0_A3",'AZE','BGD','CHL','CMR','CSI','DEU','DJI','GUY','HUN','IOA','JAM','LBN','LBY','LSO','MDG','MKD','MNG','MRT','NIU','NZL','PCN','PYF','SAU','SHN','STP','TTO','UGA','UZB','ZMB'],
        "source-layer": "country",
        "paint": {
          "fill-color": "#fdc663"
        }
      },{
        "id": "area-yellow",
        "type": "fill",
        "source": "countries",
        "filter":["in","ADM0_A3",'AGO','ASM','ATF','BDI','BFA','BGR','BLZ','BRA','CHN','CRI','ESP','HKG','HRV','IDN','IRN','ISR','KNA','LBR','LCA','MAC','MUS','NOR','PLW','POL','PRI','SDN','TUN','UMI','USA','USG','VIR','VUT'],
        "source-layer": "country",
        "paint": {
          "fill-color": "#fae364"
        }
      },{
        "id": "area-green",
        "type": "fill",
        "source": "countries",
        "filter":["in","ADM0_A3",'ARE','ARG','BHS','CIV','CLP','DMA','ETH','GAB','GRD','GRL','HMD','IND','IOT','IRL','IRQ','ITA','KOS','LUX','MEX','NAM','NER','PHL','PRT','RUS','SEN','SUR','TZA','VAT'],
        "source-layer": "country",
        "paint": {
          "fill-color": "#d3e46f"
        }
      },{
        "id": "area-turquoise",
        "type": "fill",
        "source": "countries",
        "filter":["in","ADM0_A3",'AUT','BEL','BHR','BMU','BRB','CYN','DZA','EST','FLK','GMB','GUM','HND','JEY','KGZ','LIE','MAF','MDA','NGA','NRU','SLB','SOL','SRB','SWZ','THA','TUR','VEN','VGB'],
        "source-layer": "country",
        "paint": {
          "fill-color": "#aadb78"
        }
      },{
        "id": "area-blue",
        "type": "fill",
        "source": "countries",
        "filter":["in","ADM0_A3",'AIA','BIH','BLM','BRN','CAF','CHE','COM','CPV','CUB','ECU','ESB','FSM','GAZ','GBR','GEO','KEN','LTU','MAR','MCO','MDV','NFK','NPL','PNG','PRY','QAT','SLE','SPM','SYC','TCA','TKM','TLS','VNM','WEB','WSB','YEM','ZWE'],
        "source-layer": "country",
        "paint": {
          "fill-color": "#a3cec5"
        }
      },{
        "id": "area-purple",
        "type": "fill",
        "source": "countries",
        "filter":["in","ADM0_A3",'ABW','ALB','AND','ATC','BOL','COD','CUW','CYM','CYP','EGY','FJI','GGY','IMN','KAB','KAZ','KWT','LAO','MLI','MNP','MSR','MYS','NIC','NLD','PAK','PAN','PRK','ROU','SGS','SVN','SWE','TGO','TWN','VCT','ZAF'],
        "source-layer": "country",
        "paint": {
          "fill-color": "#ceb5cf"
        }
      },{
        "id": "area-pink",
        "type": "fill",
        "source": "countries",
        "filter":["in","ADM0_A3",'ARM','ATG','AUS','BTN','CAN','COG','CZE','GHA','GIN','HTI','ISL','JOR','KHM','KOR','LVA','MLT','MNE','MOZ','PER','SAH','SGP','SLV','SOM','TJK','TUV','UKR','WSM'],
        "source-layer": "country",
        "paint": {
          "fill-color": "#f3c1d3"
        }
      // rainbow end
      },{
        "id": "geo-lines",
        "type": "line",
        "source": "countries",
        "source-layer": "geo-lines",
        "paint": {
          "line-color": "#226688",
          "line-width": {
            "stops": [[0,0.2],[4,1]]
          },
          "line-dasharray":[6,2]
        }
      },{
        "id": "land-border-country",
        "type": "line",
        "source": "countries",
        "source-layer": "land-border-country",
        "paint": {
          "line-color": "#fff",
          "line-width": {
            "base":1.5,
            "stops": [[0,0],[1,0.8],[2,1]]
          }
        }
      },{
        "id": "state",
        "type": "line",
        "source": "countries",
        "source-layer": "state",
        "minzoom": 3,
        "filter": ["in","ADM0_A3",'USA','CAN','AUS'],
        "paint": {
          "line-color": "#226688",
          "line-opacity": 0.25,
          "line-dasharray":[6,2,2,2],
          "line-width": 1.2
        }
      // LABELS
      },{
        "id": "country-abbrev",
        "type": "symbol",
        "source": "countries",
        "source-layer": "country-name",
        "minzoom":1.8,
        "maxzoom":3,
        "layout": {
          "text-field": "{ABBREV}",
          "text-font": ["Open Sans Semibold"],
          "text-transform": "uppercase",
          "text-max-width": 20,
          "text-size": {
            "stops": [[3,10],[4,11],[5,12],[6,16]]
          },
          "text-letter-spacing": {
            "stops": [[4,0],[5,1],[6,2]]
          },
          "text-line-height": {
            "stops": [[5,1.2],[6,2]]
          }
        },
        "paint": {
          "text-halo-color": "#fff",
          "text-halo-width": 1.5
        }
      },{
        "id": "country-name",
        "type": "symbol",
        "source": "countries",
        "source-layer": "country-name",
        "minzoom":3,
        "layout": {
          "text-field": "{NAME}",
          "text-font": ["Open Sans Semibold"],
          "text-transform": "uppercase",
          "text-max-width": 20,
          "text-size": {
            "stops": [[3,10],[4,11],[5,12],[6,16]]
          }
        },
        "paint": {
          "text-halo-color": "#fff",
          "text-halo-width": 1.5
        }
      },{
        "id": "geo-lines-lables",
        "type": "symbol",
        "source": "countries",
        "source-layer": "geo-lines",
        "minzoom":1,
        "layout": {
          "text-field": "{DISPLAY}",
          "text-font": ["Open Sans Semibold"],
          "text-offset": [0,1],
          "symbol-placement": "line",
          "symbol-spacing": 600,
          "text-size": 9
        },
        "paint": {
          "text-color": "#226688",
          "text-halo-width": 1.5
        }
      }]
    };


   var idc_longitude = '{{ object.longitude }}';
   var idc_latitude = '{{ object.latitude }}';
   point = [];
   // mapboxgl.accessToken = 'pk.eyJ1IjoiYWJ1ZHVsZW11c2EiLCJhIjoiY2p3cTBmYmNwMjNkdjN5bnN3bTJra29qeSJ9.kcz_P7jl3iI8vRZZa283cQ';


   var map = new mapboxgl.Map({
      container: 'map',
      // style: "{% static 'plugins/mapbox/streets-v10.json' %}",
        style:style,
      center: [108.7070345879, 34.2957018227],
      zoom: 3
   });


   // mapboxgl.setRTLTextPlugin("{% static 'js/plugins/mapbox/mapbox-gl-rtl-text.js' %}");
   // map.addControl(new MapboxLanguage({defaultLanguage: 'zh'}));


   var size = 200;


   var pulsingDot = {
      width: size,
      height: size,
      data: new Uint8Array(size * size * 4),


      onAdd: function() {
         var canvas = document.createElement('canvas');
         canvas.width = this.width;
         canvas.height = this.height;
         this.context = canvas.getContext('2d');
      },


      render: function() {
         var duration = 1000;
         var t = (performance.now() % duration) / duration;


         var radius = size / 2 * 0.3;
         var outerRadius = size / 2 * 0.7 * t + radius;
         var context = this.context;


         // draw outer circle
         context.clearRect(0, 0, this.width, this.height);
         context.beginPath();
         context.arc(this.width / 2, this.height / 2, outerRadius, 0, Math.PI * 2);
         context.fillStyle = 'rgba(255, 200, 200,' + (1 - t) + ')';
         context.fill();


         // draw inner circle
         context.beginPath();
         context.arc(this.width / 2, this.height / 2, radius, 0, Math.PI * 2);
         context.fillStyle = 'rgba(255, 100, 100, 1)';
         context.strokeStyle = 'white';
         context.lineWidth = 2 + 4 * (1 - t);
         context.fill();
         context.stroke();


         // update this image's data with data from the canvas
         this.data = context.getImageData(0, 0, this.width, this.height).data;


         // keep the map repainting
         map.triggerRepaint();


         // return `true` to let the map know that the image was updated
         return true;
      }
   };


   if (idc_longitude != 'None' & idc_latitude != 'None'){
      var idc_description = "<strong>{{ object.name }}</strong><p>{% trans 'Room count' %}:{{ object.rooms.count }}</p>";


      map.on('load', function () {


         map.addImage('pulsing-dot', pulsingDot, { pixelRatio: 2 });


         map.addLayer({
            "id": "points",
            "type": "symbol",
            "source": {
               "type": "geojson",
               "data": {
                  "type": "FeatureCollection",
                  "features": [{
                     "type": "Feature",
                     "properties": {
                        "description": idc_description,
                        "icon": "theatre"
                     },
                     "geometry": {
                        "type": "Point",
                        "coordinates": [idc_longitude, idc_latitude]
                     }
                  }]
               }
            },
            "layout": {
               "icon-image": "pulsing-dot",
               // "icon-image": "{icon}-15",
               "icon-allow-overlap": true
            }
         });


         // When a click event occurs on a feature in the places layer, open a popup at the
         // location of the feature, with description HTML from its properties.
         map.on('click', 'points', function (e) {
            var coordinates = e.features[0].geometry.coordinates.slice();
            var description = e.features[0].properties.description;


            // Ensure that if the map is zoomed out such that multiple
            // copies of the feature are visible, the popup appears
            // over the copy being pointed to.
            while (Math.abs(e.lngLat.lng - coordinates[0]) > 180) {
               coordinates[0] += e.lngLat.lng > coordinates[0] ? 360 : -360;
            }


            new mapboxgl.Popup().setLngLat(coordinates).setHTML(description).addTo(map);
         });


         // Change the cursor to a pointer when the mouse is over the places layer.
         map.on('mouseenter', 'points', function () {
            map.getCanvas().style.cursor = 'pointer';
         });


         // Change it back to a pointer when it leaves.
         map.on('mouseleave', 'points', function () {
            map.getCanvas().style.cursor = '';
         });
  
```
```
```

## 静态文件


--------

countries存放7层瓦片文件

![](https://raw.githubusercontent.com/samucc/mypicbed/master/images/20190716151347.png)
## 6层效果图：


----------

![null](https://uploader.shimo.im/f/HQMv1pIHZfo5ipsj.png!thumbnail)

## 7层效果图：


----------

  

全部使用MapBox的vector.pbf文件

![null](https://uploader.shimo.im/f/mCqkVcpOOB0mnoTh.png!thumbnail)

## Unimplemented type: 3


=========================

[https://github.com/mapbox/pbf](https://github.com/mapbox/pbf)

 

[https://github.com/mapbox/tippecanoe/issues/582](https://github.com/mapbox/tippecanoe/issues/582)

[https://github.com/naturalatlas/tilestrata-disk/issues/2](https://github.com/naturalatlas/tilestrata-disk/issues/2)

django配置gzip middleware

[https://docs.djangoproject.com/en/2.0/ref/middleware/#django.middleware.gzip.GZipMiddleware](https://docs.djangoproject.com/en/2.0/ref/middleware/#django.middleware.gzip.GZipMiddleware)

[https://docs.djangoproject.com/en/2.0/_modules/django/middleware/gzip/](https://docs.djangoproject.com/en/2.0/_modules/django/middleware/gzip/)

 ```
Access-Control-Allow-Methods: GET
Access-Control-Allow-Origin: *
Cache-Control: max-age=43200,s-maxage=300
Connection: keep-alive
Content-Encoding: gzip
Content-Length: 37365
Content-Type: application/x-protobuf
Date: Fri, 14 Jun 2019 01:26:39 GMT
ETag: "4194a00920cb92bb4f318d9ed92d9fa6"
Last-Modified: Wed, 03 Oct 2018 23:36:35 GMT
Timing-Allow-Origin: *
Via: 1.1 fe526590cbb2126b4baee2eb7ee38048.cloudfront.net (CloudFront)
X-Amz-Cf-Id: 6qK-iqjM05kz3strX5T6fSwjG8aPTjZNCXNSeVSNIOMQ2kREOPqRDw==
X-Amz-Cf-Pop: SIN2-C1
X-Cache: RefreshHit from cloudfront
X-Powered-By: Express
X-Rate-Limit-Interval: 60
X-Rate-Limit-Limit: 100000
X-Rate-Limit-Reset: 1560475659
```

nginx配置pbf文件的返回头信息

[https://lovebeyond.iteye.com/blog/1220616](https://lovebeyond.iteye.com/blog/1220616)

```
    location ~\.pbf$ {
        root /opt/jumpserver/data;
        add_header Content-Encoding gzip;
        add_header Content-Type application/x-protobuf;
    }
```  

nginx添加etag 需要重新编译安装nginx

[https://blog.csdn.net/hoewang/article/details/80240381](https://blog.csdn.net/hoewang/article/details/80240381)

reponse header etag show If-None-Match value

[https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/If-None-Match](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/If-None-Match)