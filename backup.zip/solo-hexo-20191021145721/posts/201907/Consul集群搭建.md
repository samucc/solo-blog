title: Consul集群搭建
date: '2019-07-16 15:42:47'
updated: '2019-07-16 15:42:47'
tags: [Consul, 集群]
permalink: /articles/2019/07/16/1563262967809.html
---
# 准备：
## 1 环境
```
操作系统版本：centos7.5
操作系统内核：4.8.4
系统工具：yum
数据分区（200G容量以上）：/data
启用端口：8300、8301、8302、8500、8600
```
## 2 下载文件
下载：[https://www.consul.io/downloads.html](https://www.consul.io/downloads.html)
[https://releases.hashicorp.com/consul/1.3.0/consul_1.3.0_linux_amd64.zip](https://releases.hashicorp.com/consul/1.3.0/consul_1.3.0_linux_amd64.zip)
consul_1.3.0_linux_amd64.zip
## 3 解压安装文件
```
scp /home/deployer/consul_1.3.0_linux_amd64.zip root@10.172.49.23:/home/deployer

scp /home/deployer/consul_1.3.0_linux_amd64.zip root@10.238.0.33:/home/deployer

unzip consul_1.3.0_linux_amd64.zip -d /usr/bin
```
## 4 日志配置
```
rm -rf /etc/rsyslog.d/consul.conf
rm -rf /etc/logrotate.d/consul
echo ':programname, isequal, "consul" /var/log/consul.log' >> /etc/rsyslog.d/consul.conf
echo '& ~' >> /etc/rsyslog.d/consul.conf
echo '/var/log/consul.log' >> /etc/logrotate.d/consul
echo '{' >> /etc/logrotate.d/consul
echo '    daily' >> /etc/logrotate.d/consul
echo '    rotate 7' >> /etc/logrotate.d/consul
echo '    missingok' >> /etc/logrotate.d/consul
echo '    dateext' >> /etc/logrotate.d/consul
echo '    copytruncate' >> /etc/logrotate.d/consul
echo '    compress' >> /etc/logrotate.d/consul
echo '}' >> /etc/logrotate.d/consul
```
## 5 查看集群
consul members
![图片](https://images-cdn.shimo.im/pAfr4lPYyXwyMxLR/image.png!thumbnail)
![图片](https://images-cdn.shimo.im/ZN6YeEhPA3sLUBHP/image.png!thumbnail)
集群选举
![图片](https://images-cdn.shimo.im/MQi5Oas7iyIAZaAR/image.png!thumbnail)

管理Excel：[https://shimo.im/sheet/BdN2unMFUc0UfkJC/21c95](https://shimo.im/sheet/BdN2unMFUc0UfkJC/21c95)

33,36的consul都修改为加入到49.23的集群。
# 一：master 10.172.49.23 ~~10.238.0.33~~
## 1 创建配置文件
### vim /etc/consul/server.json
```
{
  "datacenter": "xx-dc1",
  "data_dir": "/tmp/consul",
  "log_level": "INFO",
  "node_name": "master-10.172.49.23",
  "server": true,
  "bootstrap_expect": 3,
  "client_addr": "0.0.0.0",
  "advertise_addr": "10.172.49.23",
  "advertise_addr_wan": "10.172.49.23",
  "domain":"consul-master-server",
  "ports":{
      "dns": 53
    },
  "telemetry": {
      "statsd_address": "10.172.49.23:8125"
  },
  "acl_datacenter": "xx-dc1",
  "acl_agent_token": "p2BE1AtpwPbrxZdC6k+eXA==",
  "acl_master_token": "p2BE1AtpwPbrxZdC6k+eXA==",
  "acl_default_policy": "deny",
  "acl_down_policy": "extend-cache"
}

```
### vim /etc/consul/client.json 可以不要
```
{
  "datacenter": "xx-dc1",
  "data_dir": "/tmp/consul",
  "log_level": "INFO",
  "node_name": "master-10.172.49.23",
  "acl_enforce_version_8":false,
  "acl_datacenter": "xx-dc1",
  "bind_addr":"10.172.49.23",
  "domain":"consul-master-server",
  "telemetry": {
      "statsd_address": "10.172.49.23:8125"
  },
  "rejoin_after_leave":true,
  "enable_script_checks":true,
  "acl_agent_token": "p2BE1AtpwPbrxZdC6k+eXA==",
  "acl_master_token": "p2BE1AtpwPbrxZdC6k+eXA==",
  "acl_default_policy": "deny"
}
```
## 2 创建启动文件  集群Server，2个节点开始选举 防止一个节点出错奔溃
```
vim /lib/systemd/system/consul.service
[Unit]
Description=consul-master-server
Documentation=https://www.consul.io/
Requires=network-online.target
After=network-online.target
ConditionFileNotEmpty=/etc/consul/server.json
[Service]
ExecStart=/usr/bin/consul agent -server -ui -bootstrap-expect=2 -data-dir=/tmp/consul -config-dir=/etc/consul -advertise=10.172.49.23 -bind=0.0.0.0 -client=0.0.0.0
ExecReload=/usr/bin/consul reload
KillMode=process
Restart=on-failure
LimitNOFILE=65536
KillSignal=SIGINT
[Install]
WantedBy=multi-user.target
```

## 3 配置开机启动
```
echo "/bin/systemctl start consul" >> /etc/rc.local
```
启动服务：
```
systemctl enable consul
systemctl start consul
```
查看日志：
```
journalctl -fu consul
```

## 4 环境访问：
[http://10.172.49.23:8500](http://10.172.49.23:8500)
## 5 普罗配置
[http://10.172.49.23:9090/targets](http://10.172.49.23:9090/targets)
Master不存放任何机器

# 二：slave2 10.172.49.24 ~~10.238.0.36~~
## 1 创建配置文件
### vim /etc/consul/server.json
```
{
  "datacenter": "xx-dc1",
  "data_dir": "/tmp/consul",
  "log_level": "INFO",
  "node_name": "slave1-10.172.49.24",
  "server": true,
  "bootstrap_expect": 3,
  "client_addr": "0.0.0.0",
  "advertise_addr": "10.172.49.24",
  "advertise_addr_wan": "10.172.49.24",
  "domain":"consul-agent-slave1",
  "ports":{
      "dns": 53
    },
  "telemetry": {
      "statsd_address": "10.172.49.24:8125"
  },
  "acl_datacenter": "xx-dc1",
  "acl_agent_token": "p2BE1AtpwPbrxZdC6k+eXA==",
  "acl_master_token": "p2BE1AtpwPbrxZdC6k+eXA==",
  "acl_default_policy": "deny",
  "acl_down_policy": "extend-cache"
}

```
### vim /etc/consul/client.json  
```
{
  "datacenter": "xx-dc1",
  "data_dir": "/tmp/consul",
  "log_level": "INFO",
  "node_name": "slave1-10.172.49.24",
  "acl_enforce_version_8":false,
  "acl_datacenter": "xx-dc1",
  "bind_addr":"10.172.49.24",
  "domain":"consul-agent-slave1",
  "telemetry": {
      "statsd_address": "10.172.49.24:8125"
  },
  "rejoin_after_leave":true,
  "enable_script_checks":true,
  "acl_agent_token": "p2BE1AtpwPbrxZdC6k+eXA==",
  "acl_master_token": "p2BE1AtpwPbrxZdC6k+eXA==",
  "acl_default_policy": "deny"
}
```
## 2 创建启动文件 集群节点添加
```
vim /lib/systemd/system/consul.service
[Unit]
Description=consul-agent-slave1
Documentation=https://www.consul.io/
Requires=network-online.target
After=network-online.target
ConditionFileNotEmpty=/etc/consul/server.json
[Service]
ExecStart=/usr/bin/consul agent -join=10.172.49.23 -ui -data-dir=/tmp/consul -config-dir=/etc/consul -advertise=10.172.49.24 -bind=0.0.0.0 -client=0.0.0.0
ExecReload=/usr/bin/consul reloadKillMode=process
Restart=on-failure
LimitNOFILE=65536
KillSignal=SIGINT
[Install]
WantedBy=multi-user.target
```

## 3 配置开机启动
```
echo "/bin/systemctl start consul" >> /etc/rc.local
```
启动服务：
```
enablesystsystemctl enable consul
systemctl start consul
```
查看日志：
```
journalctl -fu consul
```
## 4 环境访问：
[http://10.172.49.24:8500](http://10.172.49.24:8500)

## 5 普罗配置
[http://10.172.49.24:9090/targets](http://10.172.49.24:9090/targets)
```
  - job_name: 'X-86-Consul'
    consul_sd_configs:
      - server: '10.172.49.24:8500'
        token: p2BE1AtpwPbrxZdC6k+eXA==
        services: ['dcos']
    relabel_configs:
      - source_labels: ['__meta_consul_address']
        regex: '(.*)'
        target_label: '__address__'
        replacement: '$1:9100'
        action: 'replace'
      - source_labels: ['__meta_consul_dc']
        target_label: 'dc'
      - source_labels: ['__meta_consul_metadata_environment']
        target_label: 'env'
      - source_labels: ['__meta_consul_metadata_bearing_project']
        target_label: 'project'
      - source_labels: ['__meta_consul_metadata_ownership']
        target_label: 'ownership'
      - source_labels: ['__meta_consul_metadata_idc']
        target_label: 'idc'
      - source_labels: ['__meta_consul_metadata_room']
        target_label: 'room'
      - source_labels: ['__meta_consul_metadata_cabinet']
        target_label: 'cabinet'
      - source_labels: ['__meta_consul_metadata_u_location']
        target_label: 'u_location'
      - source_labels: ['__meta_consul_metadata_subarea']
        target_label: 'subarea'
      - source_labels: ['__meta_consul_metadata_service']
        target_label: 'service'
```
# 三：slave1 10.172.49.1
## 1 创建配置文件
### vim /etc/consul/server.json
```
{
  "datacenter": "xx-dc1",
  "data_dir": "/tmp/consul",
  "log_level": "INFO",
  "node_name": "slave2-10.172.49.1",
  "server": true,
  "bootstrap_expect": 3,
  "client_addr": "0.0.0.0",
  "advertise_addr": "10.172.49.1",
  "advertise_addr_wan": "10.172.49.1",
  "domain":"consul-agent-slave2",
  "ports":{
      "dns": 53
    },
  "telemetry": {
      "statsd_address": "10.172.49.1:8125"
  },
  "acl_datacenter": "xx-dc1",
  "acl_agent_token": "p2BE1AtpwPbrxZdC6k+eXA==",
  "acl_master_token": "p2BE1AtpwPbrxZdC6k+eXA==",
  "acl_default_policy": "deny",
  "acl_down_policy": "extend-cache"
}

```
### vim /etc/consul/client.json
```
{
  "datacenter": "xx-dc1",
  "data_dir": "/tmp/consul",
  "log_level": "INFO",
  "node_name": "slave2-10.172.49.1",
  "acl_enforce_version_8":false,
  "acl_datacenter": "xx-dc1",
  "bind_addr":"10.172.49.1",
  "domain":"consul-agent-slave2",
  "telemetry": {
      "statsd_address": "10.172.49.1:8125"
  },
  "rejoin_after_leave":true,
  "enable_script_checks":true,
  "acl_agent_token": "p2BE1AtpwPbrxZdC6k+eXA==",
  "acl_master_token": "p2BE1AtpwPbrxZdC6k+eXA==",
  "acl_default_policy": "deny"
}
```
## 2 创建启动文件  集群节点添加
```
vim /lib/systemd/system/consul.service
[Unit]
Description=consul-agent-slave2
Documentation=https://www.consul.io/
Requires=network-online.target
After=network-online.target
ConditionFileNotEmpty=/etc/consul/server.json
[Service]
ExecStart=/usr/bin/consul agent -join=10.172.49.23 -ui -data-dir=/tmp/consul -config-dir=/etc/consul -advertise=10.172.49.1 -bind=0.0.0.0 -client=0.0.0.0
ExecReload=/usr/bin/consul reload
KillMode=process
Restart=on-failure
LimitNOFILE=65536
KillSignal=SIGINT
[Install]
WantedBy=multi-user.target
```

## 3 配置开机启动
```
echo "/bin/systemctl start consul" >> /etc/rc.local
```
启动服务：
```
esystemctlsystemctl enable consul
systemctl start consul
```
查看日志：
```
journalctl -fu consul
```

## 4 环境访问：
[http://10.172.49.23:8500](http://10.172.49.23:8500)

## 5 普罗配置
[http://10.172.49.1:9090/targets](http://10.172.49.1:9090/targets)
```
  - job_name: 'X-86-Consul'
    consul_sd_configs:
      - server: '10.172.49.1:8500'
        token: p2BE1AtpwPbrxZdC6k+eXA==
        services: ['xkf','ryy','cbss2']
    relabel_configs:
      - source_labels: ['__meta_consul_address']
        regex: '(.*)'
        target_label: '__address__'
        replacement: '$1:9100'
        action: 'replace'
      - source_labels: ['__meta_consul_dc']
        target_label: 'dc'
      - source_labels: ['__meta_consul_metadata_environment']
        target_label: 'env'
      - source_labels: ['__meta_consul_metadata_bearing_project']
        target_label: 'project'
      - source_labels: ['__meta_consul_metadata_ownership']
        target_label: 'ownership'
      - source_labels: ['__meta_consul_metadata_idc']
        target_label: 'idc'
      - source_labels: ['__meta_consul_metadata_room']
        target_label: 'room'
      - source_labels: ['__meta_consul_metadata_cabinet']
        target_label: 'cabinet'
      - source_labels: ['__meta_consul_metadata_u_location']
        target_label: 'u_location'
      - source_labels: ['__meta_consul_metadata_subarea']
        target_label: 'subarea'
      - source_labels: ['__meta_consul_metadata_service']
        target_label: 'service'
```
# 四：slave3 10.172.49.39
## 1 创建配置文件
### vim /etc/consul/server.json
```
{
  "datacenter": "xx-dc1",
  "data_dir": "/tmp/consul",
  "log_level": "INFO",
  "node_name": "slave3-10.172.49.39",
  "server": true,
  "bootstrap_expect": 3,
  "client_addr": "0.0.0.0",
  "advertise_addr": "10.172.49.39",
  "advertise_addr_wan": "10.172.49.39",
  "domain":"consul-agent-slave3",
  "ports":{
      "dns": 53
    },
  "telemetry": {
      "statsd_address": "10.172.49.39:8125"
  },
  "acl_datacenter": "xx-dc1",
  "acl_agent_token": "p2BE1AtpwPbrxZdC6k+eXA==",
  "acl_master_token": "p2BE1AtpwPbrxZdC6k+eXA==",
  "acl_default_policy": "deny",
  "acl_down_policy": "extend-cache"
}

```
### vim /etc/consul/client.json
```
{
  "datacenter": "xx-dc1",
  "data_dir": "/tmp/consul",
  "log_level": "INFO",
  "node_name": "slave3-10.172.49.39",
  "acl_enforce_version_8":false,
  "acl_datacenter": "xx-dc1",
  "bind_addr":"10.172.49.39",
  "domain":"consul-agent-slave3",
  "telemetry": {
      "statsd_address": "10.172.49.39:8125"
  },
  "rejoin_after_leave":true,
  "enable_script_checks":true,
  "acl_agent_token": "p2BE1AtpwPbrxZdC6k+eXA==",
  "acl_master_token": "p2BE1AtpwPbrxZdC6k+eXA==",
  "acl_default_policy": "deny"
}
```
## 2 创建启动文件  集群节点添加
```
vim /lib/systemd/system/consul.service
[Unit]
Description=consul-agent-slave2
Documentation=https://www.consul.io/
Requires=network-online.target
After=network-online.target
ConditionFileNotEmpty=/etc/consul/server.json
[Service]
ExecStart=/usr/bin/consul agent -join=10.172.49.23 -ui -data-dir=/tmp/consul -config-dir=/etc/consul -advertise=10.172.49.39 -bind=0.0.0.0 -client=0.0.0.0
ExecReload=/usr/bin/consul reload
KillMode=process
Restart=on-failure
LimitNOFILE=65536
KillSignal=SIGINT
[Install]
WantedBy=multi-user.target
```

## 3 配置开机启动
```
echo "/bin/systemctl start consul" >> /etc/rc.local
```
启动服务：
```
systemctl enable consul
systemctl start consul
```
查看日志：
```
journalctl -fu consul
```

## 4 环境访问：
[http://10.172.49.23:8500](http://10.172.49.23:8500)

## 5 普罗配置
[http://10.172.49.1:9090/targets](http://10.172.49.1:9090/targets)
```
  - job_name: 'X-86-Consul'
    consul_sd_configs:
      - server: '10.172.49.1:8500'
        token: p2BE1AtpwPbrxZdC6k+eXA==
        services: ['xkf','ryy','cbss2']
    relabel_configs:
      - source_labels: ['__meta_consul_address']
        regex: '(.*)'
        target_label: '__address__'
        replacement: '$1:9100'
        action: 'replace'
      - source_labels: ['__meta_consul_dc']
        target_label: 'dc'
      - source_labels: ['__meta_consul_metadata_environment']
        target_label: 'env'
      - source_labels: ['__meta_consul_metadata_bearing_project']
        target_label: 'project'
      - source_labels: ['__meta_consul_metadata_ownership']
        target_label: 'ownership'
      - source_labels: ['__meta_consul_metadata_idc']
        target_label: 'idc'
      - source_labels: ['__meta_consul_metadata_room']
        target_label: 'room'
      - source_labels: ['__meta_consul_metadata_cabinet']
        target_label: 'cabinet'
      - source_labels: ['__meta_consul_metadata_u_location']
        target_label: 'u_location'
      - source_labels: ['__meta_consul_metadata_subarea']
        target_label: 'subarea'
      - source_labels: ['__meta_consul_metadata_service']
        target_label: 'service'
```

# 四：问题
Fatal: invalid genesis file: invalid character ‘â’ looking for beginning of object key string
![图片](https://uploader.shimo.im/f/JKqEK9AcBXMAV5ig.png!thumbnail)
something doesn’t cooypaste right…
If you write it by hand it will work


![图片](https://uploader.shimo.im/f/ylARh1RxJ7AINhnv.png!thumbnail)
netstat -tulpn| grep 53
netstat -atunlp| grep 53
kill掉53的接口
![图片](https://uploader.shimo.im/f/0ukmLGG718cRTims.png!thumbnail)
找一台一样的机器。派出掉原因

一次修改资产信息后consul无法正常启动，找不到集群，原因为服务器上有多个ipv4地址，需要添加advertise
此外考虑到没有删除干净，nodename与之前不对应导致集群无法选举，重新修改了slave节点名，并修正了因输入错导致server.json和client.json中nodename不一致，再次启动问题解决。

# 五：Consul Python
官方API：[https://www.consul.io/api/index.html](https://www.consul.io/api/index.html)  ACL Token

[consul.postman_collection.json](https://uploader.shimo.im/f/wffx0qdQ8PQYuT7i.json)


[python consul demo.zip](https://uploader.shimo.im/f/ol3GZ9p5Ou4YW8ei.zip)


