title: Centos7 安装ELK方案（filebeat+kafka+elasticsearch+logstash+kibana）
date: '2019-10-13 13:11:15'
updated: '2019-10-15 15:19:08'
tags: [elk, filebeat, kafka, elasticsearch]
permalink: /articles/2019/10/13/1570943474689.html
---
CentOS7.5：10.172.40.24 / 32 / 33

filebeat-7.4.0-x86_64.rpm
zookeeper-3.4.14.tar.gz
kafka_2.12-2.3.0.tgz
kafka-manager-2.0.0.2_build.zip
elasticsearch-7.4.0-x86_64.rpm
logstash-7.4.0.rpm
kibana-7.4.0-x86_64.rpm

``` # 停止所有服务 并重新开启
systemctl stop kibana.service
systemctl stop elasticsearch.service
systemctl stop logstash.service
systemctl stop kafka-manager.service
systemctl stop kafka.service
systemctl stop zookeeper.service
systemctl stop filebeat.service

systemctl status kibana.service
systemctl status elasticsearch.service
systemctl status logstash.service
systemctl status kafka-manager.service
systemctl status kafka.service
systemctl status zookeeper.service
systemctl status filebeat.service

sudo filebeat modules disable system  # 开启会导致日志很多
sudo filebeat modules disable nats
sudo filebeat modules disable iptables
sudo filebeat modules disable coredns

rm -rf /vdata/zookeeper/
rm -rf /vdata/kafka/
rm -rf /vdata/elasticsearch/
rm -rf /vdata/kibana/
rm -rf /vdata/logstash/

mkdir /vdata/zookeeper/
mkdir /vdata/kafka/
mkdir /vdata/elasticsearch/
mkdir /vdata/kibana/
mkdir /vdata/logstash/

chown -R elasticsearch:elasticsearch /vdata/elasticsearch/
chown -R kibana:kibana /vdata/kibana/
chown -R logstash:logstash /vdata/logstash/

echo 24 > /vdata/zookeeper/myid # zk24 
echo 32 > /vdata/zookeeper/myid # zk32 
echo 33 > /vdata/zookeeper/myid # zk33

systemctl start zookeeper.service
systemctl start kafka.service
systemctl start elasticsearch.service
curl -XGET 'http://10.172.49.24:9200/_cat/nodes?pretty'
systemctl start logstash.service
systemctl start filebeat.service
systemctl start kibana.service
rm -rf /opt/kafka-manager-2.0.0.2/RUNNING_PID
systemctl start kafka-manager.service
sh /opt/kafka-manager-2.0.0.2/start.
```


# 一：监控架构
![](https://raw.githubusercontent.com/samucc/mypicbed/master/images/20191013125739.png)

## 1 搭建架构
![](https://raw.githubusercontent.com/samucc/mypicbed/master/images/20191013125750.png)

这个架构是在上面第二个架构基础上改进而来的，主要是将前端收集数据的Logstash Agent换成了filebeat，消息队列使用了kafka集群，然后将Logstash和Elasticsearch都通过集群模式进行构建，此架构适合大型集群、海量数据的业务场景，它通过将前端Logstash Agent替换成filebeat，有效降低了收集日志对业务系统资源的消耗。同时，消息队列使用kafka集群架构，有效保障了收集数据的安全性和稳定性，而后端Logstash和Elasticsearch均采用集群模式搭建，从整体上提高了ELK系统的高效性、扩展性和吞吐量。

————————————————

用大数据思维做运维监控

大数据分析最早就来源于运维人的日志分析，到逐渐发展对各种业务的分析，人们发现这些数据蕴涵着非常大的价值，通过实时监测、跟踪研究对象在互联网上产生的海量行为数据，进行挖掘分析，揭示出规律性的东西，提出研究结论和对策。这就是大数据的用途。

同样，通过大数据分析，我们可以得到各种指标，例如：

1、在业务层面，如团购业务每秒访问数，团购券每秒验券数，每分钟支付、创建订单等。

2、在应用层面，每个应用的错误数，调用过程，访问的平均耗时，最大耗时，95线等

3、在系统资源层面：如cpu、内存、swap、磁盘、load、主进程存活等

4、在网络层面： 如丢包、ping存活、流量、tcp连接数等

而这些指标，刚好是运维特别需要的东西。通过大数据分析出的这些指标，可以解决如下方面的问题：

>系统健康状况监控
>查找故障根源
>系统瓶颈诊断和调优
>追踪安全相关问题

那么如何用大数据思维做运维呢，大数据架构上的一个思维就是：提供一个平台让运维方便解决这些问题， 而不是，让大数据平台去解决出现的问题。

## 2 基本的一个大数据运维架构是这样的：
![](https://raw.githubusercontent.com/samucc/mypicbed/master/images/20191013125758.png)


对于运维的监控，利用大数据思维，需要分三步走：

获取需要的数据

过滤出异常数据并设置告警阀值

通过第三方监控平台进行告警

所有系统最可靠的就是日志输出，系统是不是正常，发生了什么情况，我们以前是出了问题去查日志，或者自己写个脚本定时去分析。现在这些事情都可以整合到一个已有的平台上，我们唯一要做的就是定义分析日志的的逻辑。

————————————————

版权声明：本文为CSDN博主「tencentfly」的原创文章，遵循 CC 4.0 BY-SA 版权协议，转载请附上原文出处链接及本声明。

原文链接：[https://blog.csdn.net/Tencentfly/article/details/90411774](https://blog.csdn.net/Tencentfly/article/details/90411774)


# 四：Filebeat安装(安装完成3个，需要全部机器ansible安装)
[https://www.elastic.co/cn/downloads/beats/filebeat](https://www.elastic.co/cn/downloads/beats/filebeat)

![](https://raw.githubusercontent.com/samucc/mypicbed/master/images/20191013125816.png)

[https://www.elastic.co/guide/en/beats/filebeat/current/filebeat-configuration.html](https://www.elastic.co/guide/en/beats/filebeat/current/filebeat-configuration.html)

[https://blog.csdn.net/jeikerxiao/article/details/84841792](https://blog.csdn.net/jeikerxiao/article/details/84841792)

## 10.172.49.32 / 24 / 33
rpm卸载

```
rpm -qa | grep filebeat
rpm -e --nodeps filebeat-7.4.0-1.x86_64
```
### rpm安装  
```
sudo rpm --install filebeat-7.4.0-x86_64.rpm
sudo systemctl daemon-reload
sudo systemctl enable filebeat.service
sudo systemctl start filebeat.service
sudo systemctl stop filebeat.service
sudo journalctl --unit filebeat
sudo journalctl --unit filebeat --since  "2016-10-30 18:17:16"
```
### vim /etc/filebeat/filebeat.yml
```
filebeat.inputs:
- type: log
  enabled: true
  paths:
    - /var/log/*.log
    - /var/log/history/*/*
filebeat.config.modules:
  path: ${path.config}/modules.d/*.yml
  reload.enabled: false
setup.template.settings:
  index.number_of_shards: 1
processors:
  - add_host_metadata: ~
  - add_cloud_metadata: ~
#output.elasticsearch:
#  hosts: ["10.172.49.32:9200"]
#  username: "my_kibana_user"  
#  password: "YOUR_PASSWORD
output.kafka: 
  enabled: true 
  hosts: ["10.172.49.24:9092","10.172.49.32:9092","10.172.49.33:9092"]
  topic: filebeat_log
#setup.kibana:
#  host: "10.172.49.32:5601"
#  username: "my_kibana_user"  
#  password: "YOUR_PASSWORD"
```
## 


### Filebeat获取IP地址：
https://blog.csdn.net/jybbh/article/details/86649721
配置说明：https://www.elastic.co/guide/en/beats/filebeat/current/add-host-metadata.html
```
processors:
  - add_host_metadata:
      netinfo.enabled: true
      cache.ttl: 5m
      geo:
        name: xx_idc
        location: 218.7070345879, 55.2957018227
        continent_name: China
        country_iso_code: CN
        region_name: Xi'an
        region_iso_code: XA
        city_name: Xi'an
```


# 三：kafka集群(搭建完成)
## kafka-manager安装（先安装完成zookeeper和kafka）（搭建完成）
[下载：https://github.com/yahoo/kafka-manager/releases/tag/2.0.0.2](https://github.com/yahoo/kafka-manager/releases/tag/2.0.0.2)

参考：[https://my.oschina.net/kcw/blog/3002728](https://my.oschina.net/kcw/blog/3002728)

### **编译：**
参考：[https://blog.csdn.net/qq_22222499/article/details/93379364#1_5](https://blog.csdn.net/qq_22222499/article/details/93379364#1_5)

[https://www.jianshu.com/p/f65e76efe895](https://www.jianshu.com/p/f65e76efe895)

或：

下载编译好的包：

[https://download.csdn.net/download/kangsafe/11265741](https://download.csdn.net/download/kangsafe/11265741)

```
curl https://bintray.com/sbt/rpm/rpm > bintray-sbt-rpm.repo
mv bintray-sbt-rpm.repo /etc/yum.repos.d/
yum install sbt
将github上/kafka-manager的×××到/root/ 目录下，并解压好
cd /root/kafka-manager-2.0.0.2
./sbt clean dist
然后漫长的等待后，就可以编译完成了。
编译好的文件在： /root/kafka-manager-2.0.0.2/target/universal/kafka-manager-2.0.0.2.zip
cp /root/kafka-manager-2.0.0.2/target/universal/kafka-manager-2.0.0.2.zip /tmp/
cd /tmp/
unzip kafka-manager-2.0.0.2.zip
mv kafka-manager-2.0.0.2 /usr/local/
cd /usr/local/kafka-manager-2.0.0.2/
vim conf/application.conf  修改下 kafka-manager.zkhosts="192.168.2.4:2181"    # 这里改成了我们kafka-manager用的zk的地址
然后启动：
./bin/kafka-manager -Dconfig.file=./conf/application.conf -Dhttp.port=8080
```
### 安装 10.172.49.24
```
#下载的是编译好的包
unzip kafka-manager-2.0.0.2_build.zip -d /opt/
vim /opt/kafka-manager-2.0.0.2/conf/application.conf
'''
kafka-manager.zkhosts="10.172.49.24:2181,10.172.49.32:2181,10.172.49.33:2181"
'''
/opt/kafka-manager-2.0.0.2/bin/kafka-manager -Dconfig.file=/opt/kafka-manager-2.0.0.2/conf/application.conf -Dhttp.port=8080
bin/kafka-manager -Djava.security.auth.login.config=/path/to/my-jaas.conf
```
### 启动脚本
```
mkdir /var/log/kafka
# 启动脚本：vim /opt/kafka-manager-2.0.0.2/start.sh
#!/bin/bash
nohup /opt/kafka-manager-2.0.0.2/bin/kafka-manager -Dconfig.file=/opt/kafka-manager-2.0.0.2/conf/application.conf -Dhttp.port=8080 >> /var/log/kafka/kafka-manager.log & 
# 停止脚本： vim /opt/kafka-manager-2.0.0.2/stop.sh
#!/bin/bash
PID=$(ps -ef|grep kafka-manager |grep -v grep |awk '{print $2}')
PID=${PID%"\n"}
if [ "${PID}" != "" ]; then
    echo "stopping  kafka-manager..."
    kill -9 $PID  && rm -f /opt/kafka-manager-2.0.0.2/RUNNING_PID
    echo "kafka-manager is  stopped"
fi
chmod +x /opt/kafka-manager-2.0.0.2/start.sh
chmod +x /opt/kafka-manager-2.0.0.2/stop.sh
```
### systemd启动(使用脚本启动）
```
vim /usr/lib/systemd/system/kafka-manager.service
[Unit]
Description=kafka-manager.service
After=network.target
[Service]
Type=forking
# # 24 java变量在/usr 无需配置 $JAVA_HOME
# Environment=JAVA_HOME=/home/prom/jdk1.8.0_191 #32 $JAVA_HOME 
# Environment=JAVA_HOME=/usr/java/jdk1.8.0_201 #33 $JAVA_HOME
ExecStart=/opt/kafka-manager-2.0.0.2/start.sh
ExecStop=/opt/kafka-manager-2.0.0.2/stop.sh
Restart=always
[Install]
WantedBy=multi-user.target
systemctl disable kafka-manager
systemctl daemon-reload
systemctl enable kafka-manager
systemctl start kafka-manager
systemctl status kafka-manager
```
[https://raw.githubusercontent.com/ulyaoth/repository/master/ulyaoth-kafka-manager/SOURCES/kafka-manager.init](https://raw.githubusercontent.com/ulyaoth/repository/master/ulyaoth-kafka-manager/SOURCES/kafka-manager.init)
### 测试：
[http://10.172.49.24:8080/](http://10.172.49.24:8080/)

### 配置kafka集群 使用
使用参考：[https://blog.51cto.com/liqingbiao/2417010](https://blog.51cto.com/liqingbiao/2417010)

[https://docs.ksyun.com/documents/5807](https://docs.ksyun.com/documents/5807)

1 设置JMX_PORT 重启kafka

2.不要勾选JMX with SSL

3. 如果没有安装补丁，不要勾选Display Broker and Topic Size

```
10.172.49.24:2181,10.172.49.32:2181,10.172.49.33:2181
```
![](https://raw.githubusercontent.com/samucc/mypicbed/master/images/20191013125832.png)




## Kafka集群环境搭建，需要准备好一个zookeeper环境（集群），zk集群部署
## 0 zookeeper集群 （完成）
参考：[https://my.oschina.net/colben/blog/2994102](https://my.oschina.net/colben/blog/2994102)

[https://www.cnblogs.com/ding2016/p/8280696.html](https://www.cnblogs.com/ding2016/p/8280696.html)

客户端命令操作：[https://www.cnblogs.com/frankdeng/p/9018177.html](https://www.cnblogs.com/frankdeng/p/9018177.html)

| 主机名   | eth0 IP   | 操作系统   | ZK 版本   | myid   | 
|:----|:----|:----|:----|:----|
| zk24   | 10.172.49.24   | CentOS7.5   | 3.4.14   | 24   | 
| zk32   | 10.172.49.32   | CentOS7.5   | 3.4.14   | 32   | 
| zk33   | 10.172.49.33   | CentOS7.5   | 3.4.14   | 33   | 

### 1 node 10.172.49.24
```
mkdir -p /vdata/zookeeper/ #创建数据(快照日志)目录
mkdir -p /var/lib/zookeeper # 事物日志目录
mkdir -p /var/log/zookeeper # 服务日志目录
# 生成 myid 文件
echo 24 > /vdata/zookeeper/myid # zk24 
# echo 32 > /vdata/zookeeper/myid # zk32 
# echo 33 > /vdata/zookeeper/myid # zk33
tar -zxvf zookeeper-3.4.14.tar.gz -C /opt/
cd /opt/zookeeper-3.4.14/conf
cp zoo_sample.cfg  zoo.cfg
vim zoo.cfg  #三台配置都是一样
'''
dataDir=/vdata/zookeeper
# clientPort=2181
dataLogDir=/var/lib/zookeeper
server.24=10.172.49.24:2888:3888
server.32=10.172.49.32:2888:3888
server.33=10.172.49.33:2888:3888
'''
vim /opt/zookeeper-3.4.14/bin/zkEnv.sh
'''
# 找到 ZOO_LOG_DIR="." 一行，换成如下
ZOO_LOG_DIR="/var/log/zookeeper"
'''
#配置JMX（JAVA管理扩展）
#为了监控Kafka，我们建议配置下JMX，使得监控能够提供更加详细的内容。kafka是用#scala写的，而scala依赖JVM，所以用JMX来监控是理所当然的。
#修改bin/kafka-server-start.sh，可以在堆信息配置那里添加JMX_PORT参数。我们这里#使JMX端口为9999。
# 在顶部加入下面的内容 http://www.tracefact.net/tech/084.html
vim /opt/kafka_2.12-2.3.0/bin/kafka-server-start.sh
''' #hostname 修改未对应的IP地址
export JMX_PORT="9999"
export KAFKA_JMX_OPTS="-Dcom.sun.management.jmxremote=true -Dcom.sun.management.jmxremote.authenticate=false -Dcom.sun.management.jmxremote.ssl=false -Dcom.sun.management.jmxremote.rmi.port=$JMX_PORT -Djava.rmi.server.hostname=10.172.49.32 -Djava.net.preferIPv4Stack=true"
if [ "x$KAFKA_HEAP_OPTS" = "x" ]; then
    export KAFKA_HEAP_OPTS="-Xmx1G -Xms1G"
    export JMX_PORT="9999"
fi
'''
cd /opt
zip -r zookeeper-3.4.14_24.zip zookeeper-3.4.14
sudo scp zookeeper-3.4.14_24.zip deployer@10.172.49.32:/home/deployer/
sudo scp zookeeper-3.4.14_24.zip deployer@10.172.49.33:/home/deployer/
```
### 2 node 10.172.49.32
```
cd /home/deployer/
mkdir -p /vdata/zookeeper/ #创建数据(快照日志)目录
mkdir -p /var/lib/zookeeper # 事物日志目录
mkdir -p /var/log/zookeeper # 服务日志目录
# 生成 myid 文件
echo 32 > /vdata/zookeeper/myid # zk32 
unzip zookeeper-3.4.14_24.zip -d /opt/
```
### 3 node 10.172.49.33
```
cd /home/deployer/
mkdir -p /vdata/zookeeper/ #创建数据(快照日志)目录
mkdir -p /var/lib/zookeeper # 事物日志目录
mkdir -p /var/log/zookeeper # 服务日志目录
# 生成 myid 文件
echo 33 > /vdata/zookeeper/myid # zk33
unzip zookeeper-3.4.14_24.zip -d /opt/
```
### vim /etc/profile
```
export ZOOKEEPER_HOME=/opt/zookeeper-3.4.14
export PATH=$ZOOKEEPER_HOME/bin:$PATH
export PATH
```
### 启动
每个节点上启动 zookeeper 服务

```
/opt/zookeeper-3.4.14/bin/zkServer.sh start
```
### 查看zookeeper状态
```
/opt/zookeeper-3.4.14/bin/zkServer.sh status
```
![图片](https://uploader.shimo.im/f/7uALbUJuMqg373K0.png!thumbnail)

![图片](https://uploader.shimo.im/f/QNaPazOKp9sdQiVz.png!thumbnail)

![图片](https://uploader.shimo.im/f/cnrsw2pZeW0PhVgu.png!thumbnail)

当一个节点掉了之后 会通过2888端口重新选举leader，测试成功

### systemd启动
```
vim /usr/lib/systemd/system/zookeeper.service
[Unit]
Description=zookeeper.service
After=network.target
[Service]
Type=forking
# # 24 java变量在/usr 无需配置 $JAVA_HOME
# Environment=JAVA_HOME=/home/prom/jdk1.8.0_191 #32 $JAVA_HOME 
# Environment=JAVA_HOME=/usr/java/jdk1.8.0_201 #33 $JAVA_HOME
ExecStart=/opt/zookeeper-3.4.14/bin/zkServer.sh start
ExecStop=/opt/zookeeper-3.4.14/bin/zkServer.sh stop
ExecReload=/opt/zookeeper-3.4.14/bin/zkServer.sh restart
[Install]
WantedBy=multi-user.target
systemctl disable zookeeper
systemctl daemon-reload
systemctl enable zookeeper
systemctl start zookeeper
systemctl status zookeeper
```
### FAQ
[root@localhost ~]# /usr/zookeeper/bin/zkServer.sh stop

ZooKeeper JMX enabled by default

Using config: /usr/zookeeper/bin/../conf/zoo.cfg

Stopping zookeeper ... /usr/zookeeper/bin/zkServer.sh: 第 182 行:kill: (2453) - 没有那个进程 

解决：安装配置好java之后，需要赋予权限：

~~ chmod +x /usr/java/jdk1.8.0_201/bin/java~~

由于没有在启动文件里面配置JAVA_HOME

```
[root@14l07b003 conf]# tail -n 50 /var/log/zookeeper/zookeeper.out 
nohup: 无法运行命令"java": 没有那个文件或目录
```
**总结：**linux服务器出了问题一定要看日志，日志是找到错误最有效的办法。在出现nohup: failed to run command `java’: No such file or directory这种问题时，一般都是JAVA_HOME路径没加载进去，找到对应文件添加路径即可。
## kafka集群(搭建完成)
| Host | eth0 IP | software | port | ZK集群 | OS | usage | 
|:----:|:----:|:----:|:----:|:----:|:----:|:----:|
| server-24 | 10.172.49.24 | kafka-2.3.0 | 9092 | zk3.4.14 | CentOS7.5 | node-1 | 
| server-32 | 10.172.49.32 | kafka-2.3.0 | 9092 | zk3.4.14 | CentOS7.5 | node-2 | 
| server-33 | 10.172.49.33 | kafka-2.3.0 | 9092 | zk3.4.14 | CentOS7.5 | node-3 | 

参考：[https://www.cnblogs.com/ding2016/p/8282907.html](https://www.cnblogs.com/ding2016/p/8282907.html)

[https://kafka.apache.org/downloads](https://kafka.apache.org/downloads)

## 1 node 10.172.49.24
```
mkdir -p /vdata/kafka/ #创建数据(快照日志)目录
tar -zxvf kafka_2.12-2.3.0.tgz -C /opt/
cd /opt/kafka_2.12-2.3.0/config/
vim /opt/kafka_2.12-2.3.0/config/server.properties
'''
broker.id=24
host.name=10.172.49.24
delete.topic.enable=true
log.dirs=/vdata/kafka
zookeeper.connect=10.172.49.24:2181,10.172.49.32:2181,10.172.49.33:2181
'''
vim /opt/kafka_2.12-2.3.0/config/zookeeper.properties
'''暂时未修改
dataDir=/vdata/zookeeper
'''
cd /opt
zip -r kafka_2.12-2.3.0_24.zip kafka_2.12-2.3.0
scp kafka_2.12-2.3.0_24.zip deployer@10.172.49.32:/home/deployer/
scp kafka_2.12-2.3.0_24.zip deployer@10.172.49.33:/home/deployer/
```
## 2 node 10.172.49.32
```
cd /home/deployer/
mkdir -p /vdata/kafka/ #创建数据(快照日志)目录

unzip kafka_2.12-2.3.0_24.zip -d /opt/
vim /opt/kafka_2.12-2.3.0/config/server.properties
'''
broker.id=32
host.name=10.172.49.32
'''
```
## 3 node 10.172.49.33
```
cd /home/deployer/
mkdir -p /vdata/kafka/ #创建数据(快照日志)目录
unzip kafka_2.12-2.3.0_24.zip -d /opt/
vim /opt/kafka_2.12-2.3.0/config/server.properties
'''
broker.id=33
host.name=10.172.49.33
'''
```
## 启动
```
cd /opt/kafka_2.12-2.3.0/bin
/opt/kafka_2.12-2.3.0/bin/kafka-server-start.sh -daemon /opt/kafka_2.12-2.3.0/config/server.properties
/opt/kafka_2.12-2.3.0/bin/kafka-server-stop.sh #不带参数
```
## systemd启动
```
vim /usr/lib/systemd/system/kafka.service
[Unit]
Description=kafka.service
After=network.target
[Service]
Type=forking
# # 24 java变量在/usr 无需配置 $JAVA_HOME
# Environment=JAVA_HOME=/home/prom/jdk1.8.0_191 #32 $JAVA_HOME 
# Environment=JAVA_HOME=/usr/java/jdk1.8.0_201 #33 $JAVA_HOME
ExecStart=/opt/kafka_2.12-2.3.0/bin/kafka-server-start.sh -daemon /opt/kafka_2.12-2.3.0/config/server.properties
ExecStop=/opt/kafka_2.12-2.3.0/bin/kafka-server-stop.sh
[Install]
WantedBy=multi-user.target
systemctl disable kafka
systemctl daemon-reload
systemctl enable kafka
systemctl start kafka
systemctl status kafka
```

## 测试zookeeper变化，集成zookeeper成功
```
/opt/zookeeper-3.4.14/bin/zkCli.sh -server 10.172.49.24:2181
/opt/zookeeper-3.4.14/bin/zkCli.sh -server 10.172.49.32:2181
/opt/zookeeper-3.4.14/bin/zkCli.sh -server 10.172.49.33:2181
```
![图片](https://uploader.shimo.im/f/LVIpLnICQAMNHM2W.png!thumbnail)

## 测试kafka topic 创建，查询，删除
参考：[https://www.cnblogs.com/frankdeng/p/9403883.html](https://www.cnblogs.com/frankdeng/p/9403883.html)

```
# 创建一个新的Topic
/opt/kafka_2.12-2.3.0/bin/kafka-topics.sh --create --zookeeper 10.172.49.24:2181,10.172.49.32:2181,10.172.49.33:2181 --replication-factor 3 --partitions 3 --topic TestTopic
```
![图片](https://uploader.shimo.im/f/62Wl3JgmKkUzcpvl.png!thumbnail)

```
# 查看topic副本信息
/opt/kafka_2.12-2.3.0/bin/kafka-topics.sh --describe --zookeeper 10.172.49.24:2181,10.172.49.32:2181,10.172.49.33:2181 --topic TestTopic
```
![图片](https://uploader.shimo.im/f/SrIuG0m7ViI2QvcO.png!thumbnail)

```
# 查看已经创建的topic信息
/opt/kafka_2.12-2.3.0/bin/kafka-topics.sh --list --zookeeper 10.172.49.24:2181,10.172.49.32:2181,10.172.49.33:2181
```
![图片](https://uploader.shimo.im/f/QG5sygb7LoAOHtWg.png!thumbnail)

```
# 删除topic
/opt/kafka_2.12-2.3.0/bin/kafka-topics.sh --zookeeper 10.172.49.24:2181,10.172.49.32:2181,10.172.49.33:2181 --delete --topic TestTopic
```
![图片](https://uploader.shimo.im/f/ROYb1d21n10RyG1w.png!thumbnail)

## 测试生产者/消费者
```
#旧命令
/opt/kafka_2.12-2.3.0/bin/kafka-console-consumer.sh --zookeeper 10.172.49.24:2181,10.172.49.32:2181,10.172.49.33:2181  --from-beginning --topic TestTopic
#新命令 (现在使用)
/opt/kafka_2.12-2.3.0/bin/kafka-console-consumer.sh --bootstrap-server 10.172.49.24:2181,10.172.49.32:2181,10.172.49.33:2181  --from-beginning --topic TestTopic
```
![图片](https://uploader.shimo.im/f/cqkQp6ChyJsulYgr.png!thumbnail)


# 二：Elasticsearch集群 （搭建完成）
社区：[https://elasticsearch.cn](https://elasticsearch.cn/)

下载安装包：

[https://www.elastic.co/cn/downloads/](https://www.elastic.co/cn/downloads/)

![](https://raw.githubusercontent.com/samucc/mypicbed/master/images/20191013125847.png)

安装：

[https://www.elastic.co/cn/downloads/elasticsearch](https://www.elastic.co/cn/downloads/elasticsearch)

![](https://raw.githubusercontent.com/samucc/mypicbed/master/images/20191013125856.png)

[https://www.elastic.co/cn/webinars/getting-started-elasticsearch](https://www.elastic.co/cn/webinars/getting-started-elasticsearch)

[https://www.elastic.co/cn/webinars/introduction-elk-stack?baymax=rtp&elektra=docs&storm=top-video](https://www.elastic.co/cn/webinars/introduction-elk-stack?baymax=rtp&elektra=docs&storm=top-video)

视频中的链接

[https://www.elastic.co/guide/cn/index.html](https://www.elastic.co/guide/cn/index.html)

参考：

[https://www.jianshu.com/p/3166294d77c6](https://www.jianshu.com/p/3166294d77c6)

[https://blog.csdn.net/gamer_gyt/article/details/59077189](https://blog.csdn.net/gamer_gyt/article/details/59077189)

[https://www.jianshu.com/p/7d1deb9a7307](https://www.jianshu.com/p/7d1deb9a7307)


## 1 master 10.172.49.24
### rpm卸载
```
rpm -qa | grep elasticsearch
rpm -e --nodeps elasticsearch-7.4.0-1.x86_64
```
### rpm安装  
[https://www.elastic.co/guide/en/elasticsearch/reference/6.0/rpm.html](https://www.elastic.co/guide/en/elasticsearch/reference/6.0/rpm.html)

```
sudo rpm --install elasticsearch-7.4.0-x86_64.rpm
sudo systemctl daemon-reload
sudo systemctl enable elasticsearch.service
sudo systemctl start elasticsearch.service
sudo systemctl stop elasticsearch.service
sudo journalctl --unit elasticsearch
sudo journalctl --unit elasticsearch --since  "2016-10-30 18:17:16"
```
![图片](https://uploader.shimo.im/f/0gYcFamHVPsh6m5m.png!thumbnail)

### 修改数据目录
```
mkdir /vdata/elasticsearch
chown -R elasticsearch:elasticsearch /vdata/elasticsearch/
```
日志报错：[failed to send join request to master](https://blog.csdn.net/diyiday/article/details/83926488)
[https://blog.csdn.net/gamer_gyt/article/details/59077189](https://blog.csdn.net/gamer_gyt/article/details/59077189)

### vim /etc/elasticsearch/elasticsearch.yml
```
#在文件中添加以下内容
cluster.name: xx_elasticsearch #集群的名称。 默认名称为elasticsearch。
node.name: 10_172_49_24 #节点名称。默认情况下，Elasticsearch将使用随机生成的uuid的第一个字符作为节点id。
path.data: /vdata/elasticsearch #数据存放目录。默认数据目录是$ES_HOME的子文件夹。
path.logs: /var/log/elasticsearch #日志存放目录。默认日志目录是$ES_HOME的子文件夹。
bootstrap.memory_lock: false
bootstrap.system_call_filter: false
network.host: 10.172.49.24 #ip
http.port: 9200 #port
transport.tcp.port: 9300
node.master: true #标识该节点为master
cluster.initial_master_nodes: ["10.172.49.24", "10.172.49.33","10.172.49.32"]
discovery.zen.ping.unicast.hosts: ["10.172.49.24"]
discovery.zen.minimum_master_nodes: 2
http.cors.enabled: true
http.cors.allow-origin: "*"
```
### 测试
curl [http://10.172.49.24:9200/](http://10.172.49.24:9200/)

### vim  /usr/lib/systemd/system/elasticsearch.service（rpm安装自带的，无需修改）
```
[Unit]
Description=Elasticsearch
Documentation=http://www.elastic.co
Wants=network-online.target
After=network-online.target


[Service]
Type=notify
RuntimeDirectory=elasticsearch
PrivateTmp=true
Environment=ES_HOME=/usr/share/elasticsearch
Environment=ES_PATH_CONF=/etc/elasticsearch
Environment=PID_DIR=/var/run/elasticsearch
Environment=ES_SD_NOTIFY=true
EnvironmentFile=-/etc/sysconfig/elasticsearch


WorkingDirectory=/usr/share/elasticsearch


User=elasticsearch
Group=elasticsearch


ExecStart=/usr/share/elasticsearch/bin/elasticsearch -p ${PID_DIR}/elasticsearch.pid --quiet


# StandardOutput is configured to redirect to journalctl since
# some error messages may be logged in standard output before
# elasticsearch logging system is initialized. Elasticsearch
# stores its logs in /var/log/elasticsearch and does not use
# journalctl by default. If you also want to enable journalctl
# logging, you can simply remove the "quiet" option from ExecStart.
StandardOutput=journal
StandardError=inherit


# Specifies the maximum file descriptor number that can be opened by this process
LimitNOFILE=65535


# Specifies the maximum number of processes
LimitNPROC=4096


# Specifies the maximum size of virtual memory
LimitAS=infinity


# Specifies the maximum file size
LimitFSIZE=infinity


# Disable timeout logic and wait until process is stopped
TimeoutStopSec=0


# SIGTERM signal is used to stop the Java process
KillSignal=SIGTERM


# Send the signal only to the JVM rather than its control group
KillMode=process


# Java process is never killed
SendSIGKILL=no


# When a JVM receives a SIGTERM signal it exits with code 143
SuccessExitStatus=143


[Install]
WantedBy=multi-user.target


# Built for packages-7.4.0 (packages)
```
## 2 slave 10.172.49.32
### vim /etc/elasticsearch/elasticsearch.yml
```
#在文件中添加以下内容
cluster.name: xx_elasticsearch #集群的名称。 默认名称为elasticsearch。
node.name: 10_172_49_32 #节点名称。默认情况下，Elasticsearch将使用随机生成的uuid的第一个字符作为节点id。
node.data: true
path.data: /vdata/elasticsearch #数据存放目录。默认数据目录是$ES_HOME的子文件夹。
path.logs: /var/log/elasticsearch #日志存放目录。默认日志目录是$ES_HOME的子文件夹。
bootstrap.memory_lock: false 
bootstrap.system_call_filter: false
network.host: 10.172.49.32 #ip
http.port: 9200 #port
transport.tcp.port: 9300
cluster.initial_master_nodes: ["10.172.49.24", "10.172.49.33","10.172.49.32"]
discovery.zen.ping.unicast.hosts: ["10.172.49.24"]
discovery.zen.minimum_master_nodes: 2 
http.cors.enabled: true
http.cors.allow-origin: "*"
```
### 测试
curl [http://10.172.49.32:9200/](http://10.172.49.32:9200/)

## 3 slave 10.172.49.33
### vim /etc/elasticsearch/elasticsearch.yml
```
cluster.name: xx_elasticsearch #集群的名称。 默认名称为elasticsearch。
node.name: 10_172_49_33 #节点名称。默认情况下，Elasticsearch将使用随机生成的uuid的第一个字符作为节点id。
node.data: true
path.data: /vdata/elasticsearch #数据存放目录。默认数据目录是$ES_HOME的子文件夹。
path.logs: /var/log/elasticsearch #日志存放目录。默认日志目录是$ES_HOME的子文件夹。
bootstrap.memory_lock: false 
bootstrap.system_call_filter: false
network.host: 10.172.49.33 #ip
http.port: 9200 #port
transport.tcp.port: 9300
cluster.initial_master_nodes: ["10.172.49.24", "10.172.49.33","10.172.49.32"]
discovery.zen.ping.unicast.hosts: ["10.172.49.24"]
discovery.zen.minimum_master_nodes: 2
http.cors.enabled: true
http.cors.allow-origin:
```
### 测试
curl [http://10.172.49.33:9200/](http://10.172.49.33:9200/)

## 4 查看集群
curl -XGET '[http://10.172.49.24](http://10.172.49.24):9200/_cat/nodes?pretty'

![](https://raw.githubusercontent.com/samucc/mypicbed/master/images/20191013125909.png)

*号代表master

## # 五：Logstash（先安装好filebeat和elasticsearch）(搭建完成)
[https://www.elastic.co/cn/downloads/logstash](https://www.elastic.co/cn/downloads/logstash)

![](https://raw.githubusercontent.com/samucc/mypicbed/master/images/20191013125918.png)

[https://www.elastic.co/guide/en/logstash/current/configuration.html](https://www.elastic.co/guide/en/logstash/current/configuration.html)

## 10.172.49.32 / 24 / 30
rpm卸载

```
rpm -qa | grep logstash
rpm -e --nodeps logstash-7.4.0-1.noarch
```
### rpm安装  
```
sudo rpm --install logstash-7.4.0.rpm
sudo systemctl daemon-reload
sudo systemctl enable logstash.service
sudo systemctl start logstash.service
sudo systemctl stop logstash.service
sudo journalctl --unit logstash
sudo journalctl --unit logstash --since  "2016-10-30 18:17:16"
```
### 修改数据目录
```
mkdir /vdata/logstash
chown -R logstash:logstash /vdata/logstash/
```
### vim /etc/logstash/logstash.yml
[https://www.elastic.co/guide/en/logstash/current/configuration-file-structure.html](https://www.elastic.co/guide/en/logstash/current/configuration-file-structure.html)

[https://www.elastic.co/guide/en/logstash/current/plugins-inputs-kafka.html](https://www.elastic.co/guide/en/logstash/current/plugins-inputs-kafka.html)

[https://www.elastic.co/guide/en/logstash/current/plugins-outputs-elasticsearch.html](https://www.elastic.co/guide/en/logstash/current/plugins-outputs-elasticsearch.html)

```
node.name: logstash_10_172_49_32
path.data: /vdata/logstash
path.logs: /var/log/logstash
```
### vim /etc/logstash/conf.d/kafka_elas.conf
```
# FilbBeats -> kafka -> Logstash -> Elasticsearch pipeline.
input {
  kafka {
    bootstrap_servers => ["10.172.49.24:9092,10.172.49.32:9092,10.172.49.33:9092"]
    group_id => "xx_logstash_kafka"
    auto_offset_reset => "earliest"
    consumer_threads => "5"
    decorate_events => "false"
    topics => ["filebeat_log"]
    type => "kafka-to-elas"
    codec => json
  }
}


output {
  elasticsearch {
    hosts => ["10.172.49.24:9200","10.172.49.32:9200","10.172.49.33:9200"]
    index => "%{[@metadata][beat]}-%{[@metadata][version]}-%{+YYYY.MM.dd}"
  }
}
#原文链接：https://blog.csdn.net/wayds/article/details/82981828
#http://liupzmin.com/2018/03/20/bigdata/logstash-consume-from-kafka-to-elasticsearch/
```
### FAQ 32暂时无法启动
参考：[https://www.wandouip.com/t5i172605/](https://www.wandouip.com/t5i172605/)

vim  /etc/systemd/system/logstash.service

```
# Environment=JAVA_HOME=/home/prom/jdk1.8.0_191 #32 $JAVA_HOME 
# Environment=JAVA_HOME=/usr/java/jdk1.8.0_201 #33 $JAVA_HOME
```
![](https://raw.githubusercontent.com/samucc/mypicbed/master/images/20191013125927.png)

# 六：Kibana（搭建完成）
[https://www.elastic.co/cn/downloads/kibana](https://www.elastic.co/cn/downloads/kibana)

![](https://raw.githubusercontent.com/samucc/mypicbed/master/images/20191013125936.png)

参考：

[https://www.elastic.co/guide/en/kibana/current/rpm.html](https://www.elastic.co/guide/en/kibana/current/rpm.html)

[https://www.elastic.co/guide/en/kibana/7.4/settings.html](https://www.elastic.co/guide/en/kibana/7.4/settings.html)

## 10.172.49.32
rpm卸载

```
rpm -qa | grep kibana
rpm -e --nodeps kibana-7.4.0-1.x86_64
```
### rpm安装  
[https://www.elastic.co/guide/en/kibana/current/rpm.html](https://www.elastic.co/guide/en/kibana/current/rpm.html)

```
sudo rpm --install kibana-7.4.0-x86_64.rpm
sudo systemctl daemon-reload
sudo systemctl enable kibana.service
sudo systemctl start kibana.service
sudo systemctl stop kibana.service
sudo journalctl --unit kibana
sudo journalctl --unit kibana --since  "2016-10-30 18:17:16"
```
### vim /etc/kibana/kibana.yml
```
server.port: 5601
server.host: "10.172.49.32"
server.name: "kibana_10_172_49_32"
path.data: /vdata/kibana
elasticsearch.hosts: ["http://10.172.49.24:9200","http://10.172.49.33:9200","http://10.172.49.32:9200"]
i18n.locale: "zh-CN"
```
### 修改数据目录
```
mkdir /vdata/kibana
chown -R kibana:kibana /vdata/kibana/
```
### 测试
curl [http://10.172.49.32:5601/](http://10.172.49.32:5601/)

### nginx代理
[https://www.koukousky.com/%E9%A6%96%E9%A1%B5/2225.html](https://www.koukousky.com/%E9%A6%96%E9%A1%B5/2225.html)

## Kibana-api

### 1 kibana plugin(TODO)

[https://www.elastic.co/guide/en/kibana/current/api.html](https://www.elastic.co/guide/en/kibana/current/api.html)

[https://github.com/Webiks/kibana-API](https://github.com/Webiks/kibana-API)

 

### 2 kibana log url scrape（USE）

[http://10.172.49.32:5601/app/infra#/logs/stream?_g=()&flyoutOptions=(flyoutId:!n,flyoutVisibility:hidden,surroundingLogsId:!n)&logFilter=(expression:'02l14b003',kind:kuery)&logPosition=(position:(tiebreaker:87284,time:1571043002862),streamLive:!f)](http://10.172.49.32:5601/app/infra#/logs/stream?_g=()&flyoutOptions=(flyoutId:!n,flyoutVisibility:hidden,surroundingLogsId:!n)&logFilter=(expression:'02l14b003',kind:kuery)&logPosition=(position:(tiebreaker:87284,time:1571043002862),streamLive:!f))

![](https://raw.githubusercontent.com/samucc/mypicbed/master/images/20191015151607.png)

[http://10.172.49.32:5601/api/infra/graphql](http://10.172.49.32:5601/api/infra/graphql) POST
```
kbn-xsrf:7.4.0
Content-Type:application/json
Content-Length:1371
Accept-Encoding:gzip, deflate

{"operationName":"LogEntries","variables":{"sourceId":"default","countBefore":200,"countAfter":200,"timeKey":{"time":1571108096093,"tiebreaker":0},"filterQuery":"{\"multi_match\":{\"type\":\"best_fields\",\"query\":\"02l14b003\",\"lenient\":true}}"},"query":"query LogEntries($sourceId: ID = \"default\", $timeKey: InfraTimeKeyInput!, $countBefore: Int = 0, $countAfter: Int = 0, $filterQuery: String) {\n  source(id: $sourceId) {\n    id\n    logEntriesAround(key: $timeKey, countBefore: $countBefore, countAfter: $countAfter, filterQuery: $filterQuery) {\n      start {\n        ...InfraTimeKeyFields\n      }\n      end {\n        ...InfraTimeKeyFields\n      }\n      hasMoreBefore\n      hasMoreAfter\n      entries {\n        ...InfraLogEntryFields\n      }\n    }\n  }\n}\n\nfragment InfraTimeKeyFields on InfraTimeKey {\n  time\n  tiebreaker\n}\n\nfragment InfraLogEntryFields on InfraLogEntry {\n  gid\n  key {\n    time\n    tiebreaker\n  }\n  columns {\n    ... on InfraLogEntryTimestampColumn {\n      columnId\n      timestamp\n    }\n    ... on InfraLogEntryMessageColumn {\n      columnId\n      message {\n        ... on InfraLogMessageFieldSegment {\n          field\n          value\n        }\n        ... on InfraLogMessageConstantSegment {\n          constant\n        }\n      }\n    }\n    ... on InfraLogEntryFieldColumn {\n      columnId\n      field\n      value\n    }\n  }\n}\n"}
```

![](https://raw.githubusercontent.com/samucc/mypicbed/master/images/20191015151615.png)

![](https://raw.githubusercontent.com/samucc/mypicbed/master/images/20191015151623.png)

entries格式如下

![](https://raw.githubusercontent.com/samucc/mypicbed/master/images/20191015151630.png)

 

![](https://raw.githubusercontent.com/samucc/mypicbed/master/images/20191015151639.png)

```
query：
"query LogEntries($sourceId: ID = "default", $timeKey: InfraTimeKeyInput!, $countBefore: Int = 0, $countAfter: Int = 0, $filterQuery: String) {
  source(id: $sourceId) {
    id
    logEntriesAround(key: $timeKey, countBefore: $countBefore, countAfter: $countAfter, filterQuery: $filterQuery) {
      start {
        ...InfraTimeKeyFields
      }
      end {
        ...InfraTimeKeyFields
      }
      hasMoreBefore
      hasMoreAfter
      entries {
        ...InfraLogEntryFields
      }
    }
  }
}


fragment InfraTimeKeyFields on InfraTimeKey {
  time
  tiebreaker
}


fragment InfraLogEntryFields on InfraLogEntry {
  gid
  key {
    time
    tiebreaker
  }
  columns {
    ... on InfraLogEntryTimestampColumn {
      columnId
      timestamp
    }
    ... on InfraLogEntryMessageColumn {
      columnId
      message {
        ... on InfraLogMessageFieldSegment {
          field
          value
        }
        ... on InfraLogMessageConstantSegment {
          constant
        }
      }
    }
    ... on InfraLogEntryFieldColumn {
      columnId
      field
      value
    }
  }
}
"


filterQuery：
"{"multi_match":{"type":"best_fields","query":"02l14b003","lenient":true}}"


operationName: "LogEntries"
query: ""
variables: {
countAfter: 200
countBefore: 200
filterQuery: ""
sourceId: "default"
timeKey: {time: 1571108096093, tiebreaker: 0}


1571108096093
1571108631253 new Date().getTime()
```
