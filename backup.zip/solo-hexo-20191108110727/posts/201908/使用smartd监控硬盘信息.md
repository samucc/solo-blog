title: 使用smartd监控硬盘信息
date: '2019-08-23 09:55:15'
updated: '2019-08-23 10:01:02'
tags: [smartd, disk]
permalink: /articles/2019/08/23/1566525314983.html
---
# 安装

## 源码安装：

[https://www.smartmontools.org/wiki/Download#Installfromthesourcetarball](https://www.smartmontools.org/wiki/Download#Installfromthesourcetarball)

## YUM安装：

重点参考：[https://linux.cn/article-4682-1.html](https://linux.cn/article-4682-1.html)

[https://www.milesweb.com/forums/how-to's/how-to-install-smartctl-utility-on-centos/](https://www.milesweb.com/forums/how-to's/how-to-install-smartctl-utility-on-centos/)

**Steps to install of Smartcl in CentOS:**
1 Login to your server via SSH as a root user. 
2 Use yum command to install Smartctl. 
 ```
yum install smartmontools 
```
3 Now start the service of Smartctl. 
```
service smartd start 
chkconfig smartd on
```
4 To enable Smart Capability for the disk run below command. 
```
smartctl -s on /dev/sdb
```
5 To disable Smart Capability for the disk run below command. 
```
smartctl -s off  /dev/sdb
```
6 To display details Smart info for the disk run below command. 
```
smartctl -a /dev/sdb              // For IDE drive
smartctl -a -d ata /dev/sdb       // For SATA drive
```

```
smartctl -H  /dev/sdb
smartctl  --scan
smartctl -d scsi -i /dev/sda
man 8 smartctl
smartctl --test=long /dev/sdb
smartctl --test=short /dev/sdb
smartctl -t long /dev/sda
smartctl -t short /dev/sda
smartctl -s on -o on -S on /dev/sda
smartctl -l selftest /dev/sda
```

That's it, Enjoy !!

 

## smartctl command usage

smartctl和nagio：[https://blog.51cto.com/bbotte/1603985](https://blog.51cto.com/bbotte/1603985)

包含配置：[https://blog.shadypixel.com/monitoring-hard-drive-health-on-linux-with-smartmontools/](https://blog.shadypixel.com/monitoring-hard-drive-health-on-linux-with-smartmontools/)

测试命令：[https://www.linuxjournal.com/article/6983](https://www.linuxjournal.com/article/6983)

硬盘SMART检测参数详解[转]：[https://www.cnblogs.com/xqzt/p/5512075.html](https://www.cnblogs.com/xqzt/p/5512075.html)

C2（194）温度 Temperature 

存储健康分级机制：[https://segmentfault.com/a/1190000002680853#articleHeader2](https://segmentfault.com/a/1190000002680853#articleHeader2)

## config smartd

配置参考：

[https://github.com/clear-datacenter/cloud-atlas/blob/master/storage/das/smart.md](https://github.com/clear-datacenter/cloud-atlas/blob/master/storage/das/smart.md)

![](https://raw.githubusercontent.com/samucc/mypicbed/master/images/20190823095149.png)
```
DEVICESCAN -a -o on -S on -n standby,q -s (S/../.././02|L/../../6/03) -W 4,35,40 -m <username or email>
```

  
```
vim /etc/smartmontools/smartd.conf
#原有配置：
DEVICESCAN -H -m root -M exec /usr/libexec/smartmontools/smartdnotify -n standby,10,q


修改为：
DEVICESCAN -a -o on -S on -n standby,q -s (S/../.././02|L/../../6/03) -W 4,35,40 -M exec /usr/libexec/smartmontools/smartdnotify -m root
```
另一种可用配置
```
DEVICESCAN -d removable -n standby -m root -M exec /usr/share/smartmontools/smartd-runner
```
 

[https://blog.shadypixel.com/monitoring-hard-drive-health-on-linux-with-smartmontools/](https://blog.shadypixel.com/monitoring-hard-drive-health-on-linux-with-smartmontools/)

/dev/sda -a -d sat -o on -S on -s (S/../.././02|L/../../6/03) -m root -M exec /usr/share/smartmontools/smartd-runner

 

配置表示smartd以静默状态工作，当SMART中报告PASSED的时候不理睬一旦出现Failure，立刻用邮件通知用户指定的邮箱

vi /etc/smartd.conf

/dev/sdb -H -m neo@domain.com

修改配置后重启服务：

/etc/init.d/smartd start

 

我刚刚配置了Debian服务器如下

apt-get install smartmontools

vi / etc / default / smartmontools – 这里取消注释这2行

#uncomment在系统启动时启动smartd

start_smartd = YES

#uncomment在启动时将其他选项传递给smartd

smartd_opts = “ – 间隔= 1800”然后我编辑了/etc/smartd.conf并仅取消注释了这一行

DEVICESCAN -S on -o -a -m myemail@mydomain.com -s(S /../.././ 02 | L /../../ 6/03)

我想知道这是否足以让系统在出现问题时向我发送警报消息和/或是否有办法模拟问题并查看smartd是否通过电子邮件向我发送警告.

最佳答案

您可以通过在该关键字之后立即将-M test添加到以DEVICESCAN开头的行来测试配置.下次重启smartd时,会发出电子邮件通知.

 
```
/usr/libexec/smartmontools/smartdnotify
# 一
#! /bin/sh


# Send mail
echo "$SMARTD_MESSAGE" | mail -s "$SMARTD_FAILTYPE" "$SMARTD_ADDRESS"


# Notify desktop user
MESSAGE="WARNING: Your hard drive is failing"


# direct write to terminals, do not use 'wall', because we don't want its ugly header
for t in $(who | awk '{ print $2; }' | grep -e '^tty' -e '^pts/')
do
  echo "$MESSAGE
$SMARTD_MESSAGE" >/dev/$t 2>/dev/null ||:
done
```

# 二
```
#! /bin/sh




# Send mail
echo "$SMARTD_MESSAGE" | mail -s "$SMARTD_FAILTYPE" "$SMARTD_ADDRESS"




# Notify desktop user
MESSAGE="SMART Disk monitor:"
case "$SMARTD_FAILTYPE" in
    "EmailTest"|"Health"|"Temperature"|"Usage")
        ;;
    *)
#       "CurrentPendingSector",       // 10
#       "OfflineUncorrectableSector", // 11
#       "FailedReadSmartErrorLog",    // 7
#       "ErrorCount",                 // 4
#       "FailedReadSmartData",        // 6
#       "FailedHealthCheck",          // 5
#       "FailedOpenDevice",           // 9
#       "SelfTest",                   // 3
#       "FailedReadSmartSelfTestLog", // 8
      exit 0
esac




# direct write to terminals, do not use 'wall', because we don't want its ugly header
for t in $(who | awk '{ print $2; }' | grep -e '^tty' -e '^pts/')
do
  echo "$MESSAGE
$SMARTD_MESSAGE" >/dev/$t 2>/dev/null

## 

restart smartd

/etc/init.d/smartmontools restart

service smartd restart
```
 

## 采集硬盘信息脚本

获取IP

ip addr | grep inet | egrep -nE 'bond0.*'  | awk '{print $3}' | tr -d "addr:" | head -n 1 | cut -d / -f1

 
```
#!/bin/bash
smartctl --scan |sed s/[[:space:]]//g > smartmontools.out


val="/dev/bus"


netcard=$(ifconfig |grep ^bond[[:digit:]]*.[[:digit:]][[:digit:]][[:digit:]][[:digit:]] |sed 's/[ ][ ]*/,/g' |cut -d ',' -f 1 |sed 's/://g')


if [ "${netcard}" == "" ];then
netcard=$(ifconfig |grep ^bond0.* |sed 's/[ ][ ]*/,/g' |cut -d ',' -f 1 |sed 's/://g')
fi


if [ "${netcard}" == "" ];then
netcard=$(ifconfig |grep ^bond_p.* |sed 's/[ ][ ]*/,/g' |cut -d ',' -f 1 |sed 's/://g')
fi


ip=$(ifconfig ${netcard}|grep -w "inet" |sed 's/[ ][ ]*/,/g' |cut -d ',' -f 3 )


for line in $(cat smartmontools.out);do
if [ "${line:0:8}" == "${val}" ];then
continue
fi


cmd="smartctl -H "${line:0:8}" -d sat+megaraid,0"
$cmd |grep "SMART overall-health self-assessment test result:"* > smartout.out
out=$(cat smartout.out)


if [ "${out}" == "" ];then
cmd="smartctl -H "${line:0:8}" -d megaraid,0"
$cmd |grep "SMART Health Status:"* > smartout.out
fi


echo ${ip}":"${line:0:8}":"$(cat smartout.out)
done


rm -f smartmontools.out
rm -f sm
```