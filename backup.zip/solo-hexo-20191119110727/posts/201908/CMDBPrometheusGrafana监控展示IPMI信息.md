title: CMDB-Prometheus-Grafana监控展示IPMI信息
date: '2019-08-23 09:40:41'
updated: '2019-08-23 09:47:04'
tags: [grafana, ipmi, cmdb]
permalink: /articles/2019/08/23/1566524440966.html
---
# 一 安装IPMI-Tool
## 1.1 手动安装
参考：[手动安装](http://jiashu.club/articles/2019/08/07/1565168296048.html)
## 1.2 ansible批量安装
```
#1 设置Ansible的账号密码等信息。以IPMI开头

vi /etc/ansible/hosts
#2 查看操作系统信息
ansible ipmi_dcos -m shell -a "cat /etc/redhat-release" --sudo
#3 【centos7】拷贝freeipmi文件
ansible ipmi_dcos -m copy -a "src=/home/deployer/freeipmi-1.5.7-2.el7.x86_64.rpm dest=/home/deployer"
[centos6]
ansible ipmi_dcos -m copy -a "src=/home/deployer/freeipmi-1.2.1-10.el6.x86_64.rpm dest=/home/deployer"

#4 安装FreeIPMI
ansible ipmi_dcos -m shell -a "rpm -ivh /home/deployer/freeipmi-1.5.7-2.el7.x86_64.rpm" --sudo
ansible ipmi_dcos -m shell -a "rpm -ivh /home/deployer/freeipmi-1.2.1-10.el6.x86_64.rpm" --sudo


#5 安装IPMI-Tools
#YUM安装
ansible ipmi_dcos -m shell -a "yum install -y OpenIPMI-tools" --sudo
#RPM安装
[centos7]
ansible ipmi_dcos -m copy -a "src=/home/deployer/ipmitool-1.8.18-7.el7.x86_64.rpm dest=/home/deployer"
[centos6]
ansible ipmi_dcos -m copy -a "src=/home/deployer/ipmitool-1.8.15-2.el6.x86_64.rpm dest=/home/deployer"

ansible ipmi_dcos -m shell -a "rpm -ivh /home/deployer/ipmitool-1.8.18-7.el7.x86_64.rpm" --sudo
ansible ipmi_dcos -m shell -a "rpm -ivh /home/deployer/ipmitool-1.8.15-2.el6.x86_64.rpm" --sud

#6 查看IPMI用户
ansible ipmi_dcos -m shell -a "ipmitool user list 1" --sudo
#7 设置用户名称
ansible ipmi_dcos -m shell -a "ipmitool user set name 7 prom" --sudo
#8 设置用户密码
ansible ipmi_dcos -m shell -a "ipmitool user set password 7 Linux@web7" --sudo
mEke5lpiBDTcm?

#9 启用用户
ansible ipmi_dcos -m shell -a "ipmitool user enable 7" --sudo
#10 设置用户access权限
ansible ipmi_dcos -m shell -a "ipmitool channel setaccess 1 7 callin=on ipmi=on link=on privilege=4" --sudo
#11 通道打开
ansible ipmi_dcos -m shell -a "ipmitool lan set 1 access on" --sudo
```

# 二 prometheus安装ipmi-exporter并监控
## 2.1 安装go
```
https://golang.org/doc/install?download=go1.11.4.linux-amd64.tar.gz


tar zxvf go1.11.4.linux-amd64.tar.gz -C /usr/local
新建go项目根目录

mkdir -p /var/opt/wwwroot/goblog
配置环境变量

vim /etc/profile
export GOROOT=/usr/local/go
export GOBIN=$GOROOT/bin
export PATH=$PATH:$GOBIN
export GOPATH=/var/opt/wwwroot/goblin

source /etc/profile
安装结束，验证

go version
```
## 2.2 安装ipmi-exporter
[https://github.com/soundcloud/ipmi_exporter](https://github.com/soundcloud/ipmi_exporter)
```
ipmi_exporter-master.zip

unzip ipmi_exporter-master.zip

mkdir -p /var/opt/wwwroot/goblin/src/github.com/soundcloud/ipmi_exporter


cp -r ipmi_exporter-master/* /var/opt/wwwroot/goblin/src/github.com/soundcloud/ipmi_exporter


cd /var/opt/wwwroot/goblin/src/github.com/soundcloud/ipmi_exporter


go build


./ipmi_exporter


/var/opt/wwwroot/goblin/src/github.com/soundcloud/ipmi_exporter/ipmi_exporter --web.listen-address=":9290" --config.file=/var/opt/wwwroot/goblin/src/github.com/soundcloud/ipmi_exporter/ipmi.yml &


/var/opt/wwwroot/goblin/src/github.com/soundcloud/ipmi_exporter/ipmi_exporter --config.file=/var/opt/wwwroot/goblin/src/github.com/soundcloud/ipmi_exporter/ipmi.
```
[http://10.172.49.32:9290/](http://10.172.49.32:9290/)

配置ipmi.yml
/var/opt/wwwroot/goblin/src/github.com/soundcloud/ipmi_exporter/ipmi.yml
```
credentials:

        default:

                user: "root"
                pass: "password"
        10.8.0.2:
                user: "host_specific_user"
                pass: "another_pw"
```
可配置非root账号，参考ipmi-tool安装时设置的账号

# 三 资产管理-机房机柜等管理
以下管理需求参考opendcim
## 3.1 IDC列表
![](https://raw.githubusercontent.com/samucc/mypicbed/master/images/20190823091037.png)
## 3.2 IDC详情
![](https://raw.githubusercontent.com/samucc/mypicbed/master/images/20190823090916.png)
## 3.3 机房列表
![](https://raw.githubusercontent.com/samucc/mypicbed/master/images/20190823091151.png)
## 3.4 机房详情
![](https://raw.githubusercontent.com/samucc/mypicbed/master/images/20190823091319.png)
![](https://raw.githubusercontent.com/samucc/mypicbed/master/images/20190823091320.png)
## 3.5 区域列表
![](https://raw.githubusercontent.com/samucc/mypicbed/master/images/20190823091447.png)
## 3.6 区域详情
![](https://raw.githubusercontent.com/samucc/mypicbed/master/images/20190823091542.png)
## 3.7 机柜列 列表
![](https://raw.githubusercontent.com/samucc/mypicbed/master/images/20190823091640.png)
## 3.8 机柜 列表
![](https://raw.githubusercontent.com/samucc/mypicbed/master/images/20190823091843.png)
## 3.9 机柜详情
![](https://raw.githubusercontent.com/samucc/mypicbed/master/images/20190823092036.png)
![](https://raw.githubusercontent.com/samucc/mypicbed/master/images/20190823092035.png)

# 四 Grafana根据机房机柜等纬度统计功耗等情况
![](https://raw.githubusercontent.com/samucc/mypicbed/master/images/20190823092146.png)
![](https://raw.githubusercontent.com/samucc/mypicbed/master/images/20190823093252.png)
![](https://raw.githubusercontent.com/samucc/mypicbed/master/images/20190823093312.png)
![](https://raw.githubusercontent.com/samucc/mypicbed/master/images/20190823093340.png)
![](https://raw.githubusercontent.com/samucc/mypicbed/master/images/20190823093351.png)
![](https://raw.githubusercontent.com/samucc/mypicbed/master/images/20190823093407.png)
![](https://raw.githubusercontent.com/samucc/mypicbed/master/images/20190823093419.png)