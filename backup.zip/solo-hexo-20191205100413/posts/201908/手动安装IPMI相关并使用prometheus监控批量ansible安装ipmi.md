title: 手动安装IPMI相关并使用prometheus监控，批量ansible安装ipmi
date: '2019-08-07 16:58:16'
updated: '2019-08-07 16:58:16'
tags: [freeipmi, ipmitool, prometheus, ansible]
permalink: /articles/2019/08/07/1565168296048.html
---
# RPM安装FreeIPMI（Prometheus的IPMI-Exporter需要）
rpm安装（根据系统不同，找不同的包）
[https://centos.pkgs.org/7/centos-x86_64/freeipmi-1.5.7-2.el7.x86_64.rpm.html](https://centos.pkgs.org/7/centos-x86_64/freeipmi-1.5.7-2.el7.x86_64.rpm.html)
![](https://raw.githubusercontent.com/samucc/mypicbed/master/images/20190807163207.png)
[RPM包说明](http://wiki.jikexueyuan.com/project/linux/rpm.html)
![](https://raw.githubusercontent.com/samucc/mypicbed/master/images/20190807163906.png)
```
rpm -ivh freeipmi-1.5.7-2.el7.x86_64.rpm
```
![图片](https://uploader.shimo.im/f/8WnUDlLtrr42nYhj.png!thumbnail)
```
find / -name ipmiconsole
find / -name bmc-info
find / -name ipmi-dcmi
```
查看对应的impiconsole，bmc-info和ipmi-dcmi全部安装完成
![](https://raw.githubusercontent.com/samucc/mypicbed/master/images/20190807163928.png)
# 安装IPMI Tool（测试成功的是Dell机器）
## 设置本地源   并安装OpenIPMI-tools 
需要根据不同系统设置不同的数据。
```
vim /etc/yum.repos.d/local.repo

[local]
NAME=sjw
baseurl=http://10.172.49.1/iso
gpgcheck=0
enable=1

yum clean all 
yum repolist

yum install -y OpenIPMI-tools
```
需要到OpenIPMI-tools的包并安装
# 设置IPMI 账号
## 查看IPMI用户列表
```
ipmitool user list 1
```
>ID  Name	     Callin  Link Auth	IPMI Msg   Channel Priv Limit
>2   root             true    true       true       ADMINISTRATOR
>3   admin            true    true       true       ADMINISTRATOR
>5   yunwei           true    true       true       ADMINISTRATOR
>......
## 创建用户（修改ID=7为prom账号）
如果没有prom用户（默认prom账号是7，如果不是请联系并告知）
```
ipmitool user set name 7 prom
ipmitool user set password 7 Linux@web7
```
>Password for user 2: Linux@web7  #密码默认是这个，待后面测试不通过联系手动修改
>Password for user 2: 
>Set User Password command successful (user 2)

```
ipmitool user enable 7   #新用户需要设置为enable。已有用户无需设置
```
## 设置用户权限
设置用户权限（如果权限和绿色部分一直，则无需跑下面的命令）
	channel 为1（默认为1），user ID为7，privilege为4
	privilege的值定义如下；	1 callback  2 user  3 operator 4 administrator 5 OEM
```
ipmitool channel setaccess 1 7 callin=on ipmi=on link=on privilege=4
```
## 打开通道
仅打开802.3 LAN通道访问权限即可（1就是上方的channel id）
```
ipmitool lan set 1 access on

# 查看channel信息
ipmitool lan print 1
```
![](https://raw.githubusercontent.com/samucc/mypicbed/master/images/20190807165215.png)
## 结果测试
### 网页测试（修改为对应的带外IP即可）（网站测试的密码Linux@web7）
[http://10.172.49.32:9290/ipmi?target=10.4.118.43](http://10.172.49.32:9290/ipmi?target=10.4.118.43)
### 命令行测试：
```
ssh 10.172.49.32  #  IPMI-Exporter的安装服务器
#带外地址
sudo ipmitool -I lanplus -H 10.4.119.145 -p 623 -U prom -P Linux@web7 sdr list
```
![](https://raw.githubusercontent.com/samucc/mypicbed/master/images/20190807165235.png)
```
sudo ipmi-sensors -h 10.4.119.145 -u prom -p Linux@web7 -l USER -D lan_2_0
```

![](https://raw.githubusercontent.com/samucc/mypicbed/master/images/20190807165254.png)
# Ansible批量操作
```
#1 设置Ansible的账号密码等信息。以IPMI开头
vi /etc/ansible/hosts
#2 查看操作系统信息
ansible ipmi_dcos -m shell -a "cat /etc/redhat-release" --sudo
#3 【centos7】拷贝freeipmi文件
ansible ipmi_dcos -m copy -a "src=/home/deployer/freeipmi-1.5.7-2.el7.x86_64.rpm dest=/home/deployer"

#4 安装FreeIPMI
ansible ipmi_dcos -m shell -a "rpm -ivh /home/deployer/freeipmi-1.5.7-2.el7.x86_64.rpm" --sudo
#5 安装IPMI-Tools
ansible ipmi_dcos -m shell -a "yum install -y OpenIPMI-tools" --sudo
#6 查看IPMI用户
ansible ipmi_dcos -m shell -a "ipmitool user list 1" --sudo
#7 设置用户名称
ansible ipmi_dcos -m shell -a "ipmitool user set name 7 prom" --sudo
#8 设置用户密码
ansible ipmi_dcos -m shell -a "ipmitool user set password 7 Linux@web7" --sudo
#9 启用用户
ansible ipmi_dcos -m shell -a "ipmitool user enable 7" --sudo
#10 设置用户access权限
ansible ipmi_dcos -m shell -a "ipmitool channel setaccess 1 7 callin=on ipmi=on link=on privilege=4" --sudo
#11 通道打开
ansible ipmi_dcos -m shell -a "ipmitool lan set 1 access on" --sudo

```
# FAQ
## Invalid data field in request
[root@07l04b003 deployer]# ipmitool user list
Get User Access command failed (channel 14, user 1): Invalid data field in request
参考:[https://github.com/uebayasi/openbsd-ipmi/issues/10](https://github.com/uebayasi/openbsd-ipmi/issues/10)

解决：[http://www.voidcn.com/article/p-nitsjhqt-bde.html](http://www.voidcn.com/article/p-nitsjhqt-bde.html)
[https://www.robustperception.io/dealing-with-too-many-open-files](https://www.robustperception.io/dealing-with-too-many-open-files)
```
vi /etc/security/limits.conf 最后一行增加
* soft nofile 65535
* hard nofile 65535
注销一下生效

ulimit -n 102400
ulimit -a
```


