title: ELK 配置获取交换机日志
date: '2019-11-18 11:28:03'
updated: '2019-11-18 11:28:03'
tags: [ELK, 网络日志, KIBANA]
permalink: /articles/2019/11/18/1574047683447.html
---
[ELK环境搭建](http://jiashu.club/articles/2019/10/13/1570943474689.html)

# Logstash配置
## 服务以root身份启动
```
# 服务以root身份启动
vim /etc/systemd/system/logstash.service
User=root
Group=root
```
## 网络日志相关配置
vim /etc/logstash/conf.d/net_log.conf
```
# 由于没有Cisco设备，因此match函数没有更新
input{
    tcp {
        port => 5002 
        type => "Cisco"
    }
    udp {
        port => 514 
        type => "HUAWEI"
    }
    udp {
        port => 5002 
        type => "Cisco"
    }
    udp {
        port => 5003 
        type => "H3C"
    }
    udp {
        port => 5004
        type => "H3C"
    }
}
filter {
    if [type] == "Cisco"{
        grok{
            match => { "message" => "<%{BASE10NUM:syslog_pri}>%{NUMBER:log_sequence}: .%{SYSLOGTIMESTAMP:timestamp}: %%{DATA:facility}-%{POSINT:severity}-%{CISCO_REASON:mnemonic}: %{GREEDYDATA:message}" }
            match => { "message" => "<%{BASE10NUM:syslog_pri}>%{NUMBER:log_sequence}: %{SYSLOGTIMESTAMP:timestamp}: %%{DATA:facility}-%{POSINT:severity}-%{CISCO_REASON:mnemonic}: %{GREEDYDATA:message}" }
            add_field => {"severity_code" => "%{severity}"}
            overwrite => ["message"]
        }    
    }
    else if [type] == "H3C"{
        grok {
            match => { "message" => "<%{BASE10NUM:syslog_pri}>%{DATA:month} %{DATA:day} %{DATA:time} %{DATA:year} %{DATA:hostname} %%%{DATA:ddModuleName}/%{POSINT:severity}/%{DATA:brief}: %{GREEDYDATA:message}" }
            add_field => {"syslog_time" => "%{month} %{day} %{year} %{time}"}
            add_field => {"severity_code" => "%{severity}"}
            overwrite => ["message"]
        }
    }
    else if [type] == "H3C-Firewall"{
        grok {
            match => { "message" => "<%{BASE10NUM:syslog_pri}>%{DATA:month} %{DATA:day} %{DATA:time} %{DATA:year} %{DATA:hostname} %%%{DATA:ddModuleName}/%{POSINT:severity}/%{DATA:brief}: %{GREEDYDATA:message}" }
            add_field => {"syslog_time" => "%{month} %{day} %{year} %{time}"}
            add_field => {"severity_code" => "%{severity}"}
            overwrite => ["message"]
        }
    }
    else if [type] == "HUAWEI" {
        grok {
            match => { "message" => "<%{BASE10NUM:syslog_pri}>%{DATA:month} %{DATA:day} %{DATA:year} %{DATA:time} %{DATA:hostname} %%%{DATA:ddModuleName}/%{POSINT:severity}/%{DATA:brief}:%{GREEDYDATA:message}"}
            add_field => {"syslog_time" => "%{month} %{day} %{year} %{time}"}
            add_field => {"severity_code" => "%{severity}"}
            overwrite => ["message"]
        }

    }
    mutate {
        gsub => [
            "severity", "0", "Emergency",
            "severity", "1", "Alert",
            "severity", "2", "Critical",
            "severity", "3", "Error",
            "severity", "4", "Warning",
            "severity", "5", "Notice",
            "severity", "6", "Informational",
            "severity", "7", "Debug"
        ]
    }
}

output{
    elasticsearch {
        index => "switch-log-new-%{+YYYY.MM.dd}"
        hosts => ["10.172.49.24:9200","10.172.49.32:9200","10.172.49.33:9200"]
    }
}
```
## 效果图
![](https://raw.githubusercontent.com/samucc/mypicbed/master/images/20191118112626.png)

# 交换机配置
## 华为交换机配置
```
[~SwitchA] info-center enable
[*SwitchA] commit
[*SwitchA] info-center source default channel loghost log level debugging trap state off debug state off
[*SwitchA]info-center loghost source Vlanif100
[*SwitchA]info-center loghost 10.172.49.33
[*SwitchA]commit
```
## 华三交换机
```
info-center enable
info-center source default loghost level debugging trap state off debug state off
// 必要，不然日志会出现 不符合级别的 alert 日志
info-center loghost 10.172.49.33 port 5003
```

## 华三防火墙
```
info-center enable
info-center source default loghost log level debugging trap state off debug state off
// 必要，不然日志会出现 不符合级别的 alert 日志
info-center loghost 10.172.49.33 port 5004
```

# kibana测试logstash grok match 表达式
## 日志
```
<190>Nov 13 14:52:55 2019 SNRY-1#IDC-B003-A14&B15-HXQ-FW01&02-H3CM9010 %%10SSHS/6/SSHS_CONNECT: -DevIP=10.4.114.6; SSH user ruanyy (IP: 10.172.49.30) connected to the server successfully.
```
## 表达式
```
<%{BASE10NUM:syslog_pri}>%{DATA:month} %{DATA:day} %{DATA:time} %{DATA:year} %{DATA:hostname} %%%{DATA:ddModuleName}/%{POSINT:severity}/%{DATA:brief}: %{GREEDYDATA:message}
```
## kibana测试
![](https://raw.githubusercontent.com/samucc/mypicbed/master/images/20191118112359.png)

