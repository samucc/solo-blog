title: nagios安装监控bmc
date: '2019-08-27 09:14:35'
updated: '2019-08-27 09:14:35'
tags: [nagios, bmc]
permalink: /articles/2019/08/27/1566868475767.html
---
# nagios安装测试

## [](#安装前简介)安装前简介

现在需要将之前脚本过滤出的bmc不通的ip监控起来，方便自己查看进度，所以需要实时监控主机的bmcip状态，尽量不更改被监控主机的情况下，选择使用了nagios（基本服务探测不需要安装agent）

---

### [](#安装环境debian9云开发机8g内存)安装环境：debian9（云开发机）8G内存

---

## [](#nagios是什么)nagios是什么

* 关于nagios：[https://www.ibm.com/developerworks/cn/linux/1309_luojun_nagios/index.html](https://www.ibm.com/developerworks/cn/linux/1309_luojun_nagios/index.html)
* nagios结构说明： Nagios 结构上来说， 可分为核心和插件两个部分。Nagios 的核心部分只提供了很少的监控功能，因此要搭建一个完善的 IT 监控管理系统，用户还需要在 Nagios 服务器 安装相应的插件，插件可以从 Nagios 官方网站下载 [http://www.nagios.org/，也可以根据实际要求自己编写所需的插件。](http://www.nagios.org/%EF%BC%8C%E4%B9%9F%E5%8F%AF%E4%BB%A5%E6%A0%B9%E6%8D%AE%E5%AE%9E%E9%99%85%E8%A6%81%E6%B1%82%E8%87%AA%E5%B7%B1%E7%BC%96%E5%86%99%E6%89%80%E9%9C%80%E7%9A%84%E6%8F%92%E4%BB%B6%E3%80%82)
* nagios功能：

1. 监控网络服务（SMTP、POP3、HTTP、FTP、PING 等）；
2. 监控本机及远程主机资源（CPU 负荷、磁盘利用率、进程 等）；
3. 允许用户编写自己的插件来监控特定的服务，方便地扩展自己服务的检测方法，支持多种开发语言（Shell、Perl、Python、PHP 等）
4. 具备定义网络分层结构的能力，用"parent"主机定义来表达网络主机间的关系，这种关系可被用来发现和明晰主机宕机或不可达状态；
5. 当服务或主机问题产生与解决时将告警发送给联系人（通过 EMail、短信、用户定义方式）；
6. 可以支持并实现对主机的冗余监控；
7. 可用 WEB 界面用于查看当前的网络状态、通知和故障历史、日志文件等；

## [](#安装nagios)安装nagios

这里我的系统是debian，如果是别的系统，请参考官网，上面很详细：

1. [https://support.nagios.com/kb/article/nagios-core-installing-nagios-core-from-source-96.html#Debian](https://support.nagios.com/kb/article/nagios-core-installing-nagios-core-from-source-96.html#Debian)
2. [http://nagios-cn.sourceforge.net/nagios-cn/beginning.html#quickstart](http://nagios-cn.sourceforge.net/nagios-cn/beginning.html#quickstart)

本次测试使用nagios版本为4.4.5 以下操作都使用root来执行：

* 安装基础包

```
- 解压编译nagios
> tar xzf /data00/nagios/nagios-4.4.5/
cd /data00/nagios/nagios-4.4.5/ 
./configure --with-httpd-conf=/etc/apache2/sites-enabled 
make all
- 创建用户和组
make install-groups-users 
usermod -a -G nagios www-data
- 安装二进制文件
make install
make install-daemoninit
make install-commandmode
make install-config
make install-webconf 
a2enmod rewrite
a2enmod cgi

#为nagios页面设置访问密码
htpasswd -c /usr/local/nagios/etc/htpasswd.users nagiosadmin

- 运行并访问
systemctl restart apache2.service
systemctl start nagios.service
 
http://10.224.17.213/nagios/
nagiosadmin/1996120

```

* 安装插件，不然nagios core是无法正常使用的

```
apt-get install -y autoconf gcc libc6 libmcrypt-dev make libssl-dev wget bc gawk dc build-essential snmp libnet-snmp-perl gettext
wget --no-check-certificate -O nagios-plugins.tar.gz https://github.com/nagios-plugins/nagios-plugins/archive/release-2.2.1.tar.gz
tar xzf nagios-plugins-2.2.1.tar.gz && cd nagios-plugins-2.2.1/
./tools/setup 
./configure 
make 
make install

```

安装步骤比较简单，参照官网一步一步复制粘贴即可

## [](#模版部分)模版部分

这里大致说下这些参数和nagios文件结构

```
目录名称                          作用
bin                         Nagios 可执行程序所在目录
etc                            Nagios 配置文件目录
sbin                  Nagios cgi 文件所在目录， 也就是执行外部 命令所需要文件所在的目录
share                         Nagios 网页存放路径
libexec                      Nagios 外部插件存放目录
var                            Nagios 日志文件、Lock 等文件所在的目录
var/archives              Nagios 日志自动归档目录
var/rw                        用来存放外部命令文件的目录

```

配置文件说明

```
cgi.cfg	控制 CGI 访问的配置文件
nagios.cfg	Nagios 主配置文件
resource.cfg	变量定义文件，又称为资源文件，在此文件中定义变量，以便由其他配置文件引用，如$USER1$
objects	objects 是一个目录，在此目录下有很多配置文件模板，用于定义 Nagios 对象
objects/commands.cfg	命令定义配置文件，其中定义的命令可以被其他配置文件引用
objects/contacts.cfg	定义联系人和联系人组的配置文件
objects/localhost.cfg	定义监控本地主机的配置文件
objects/printer.cfg	定义监控打印机的一个配置文件模板，默认没有启用此文件
objects/switch.cfg	监控路由器的一个配置文件模板，默认没有启用此文件
objects/templates.cfg	定义主机和服务的一个模板配置文件，可以在其他配置文件中引用
objects/timeperiods.cfg	定义 Nagios 监控时间段的配置文件
objects/windows.cfg	监控 Windows 主机的一个配置文件模板，默认没有启用此文件


```

模版参数说明

```
 define contact{  
        name                            generic-contact        #联系人名称，  
        service_notification_period     24x7                   #当服务出现异常时，发送通知的时间段，这个时间段“7x24"在timeperiods.cfg文件中定义  
        host_notification_period        24x7                   #当主机出现异常时，发送通知的时间段，这个时间段“7x24"在timeperiods.cfg文件中定义  
        service_notification_options    w,u,c,r         #这个定义的是“通知可以被发出的情况”。w即warn，表示警告状态，u即unknown，表示不明状态，c即criticle，表示紧急状态，r即recover，表示恢复状态。也就是在服务出现警告状态、未知状态、紧急状态和重新恢复状态时都发送通知给使用者。  
        host_notification_options       d,u,r         #定义主机在什么状态下需要发送通知给使用者，d即down，表示宕机状态，u即unreachable，表示不可到达状态，r即recovery，表示重新恢复状态。  
        service_notification_commands   notify-service-by-email  #服务故障时，发送通知的方式，可以是邮件和短信，这里发送的方式是邮件，其中“notify-service-by-email”在commands.cfg文件中定义。  
        host_notification_commands      notify-host-by-email     #主机故障时，发送通知的方式，可以是邮件和短信，这里发送的方式是邮件，其中“notify-host-by-email”在commands.cfg文件中定义。  
        register                        0  
        }  
 define host{   
        name                            generic-host    #主机名称，这里的主机名，并不是直接对应到真正机器的主机名，乃是对应到在主机配置文件里所设定的主机名。  
        notifications_enabled           1              
        event_handler_enabled           1               
        flap_detection_enabled          1               
        failure_prediction_enabled      1             
        process_perf_data               1              
        retain_status_information       1             
        retain_nonstatus_information    1                
        notification_period             24x7           #指定“发送通知”的时间段，也就是可以在什么时候发送通知给使用者。  
        register                        0                
        }  
 
define host{  
        name                            linux-server    #主机名称  
        use                             generic-host    #use表示引用，也就是将主机generic-host的所有属性引用到linux-server中来，在nagios配置中，很多情况下会用到引用。  
        check_period                    24x7            #这里的check_period告诉nagios检查主机的时间段  
        check_interval                  5                #nagios对主机的检查时间间隔，这里是5分钟。  
        retry_interval                  1               #重试检查时间间隔，单位是分钟。  
        max_check_attempts              10               #nagios对主机的最大检查次数，也就是nagios在检查发现某主机异常时，并不马上判断为异常状况，而是多试几次，因为有可能只是一时网络太拥挤，或是一些其他原因，让主机受到了一点影响，这里的10就是最多试10次的意思。  
        check_command                   check-host-alive  #指定检查主机状态的命令，其中“check-host-alive”在commands.cfg文件中定义。  
        notification_period             workhours      #主机故障时，发送通知的时间范围，其中“workhours”在timeperiods.cfg中进行了定义，下面会陆续讲到。  
                                                         
        notification_interval           120            #在主机出现异常后，故障一直没有解决，nagios再次对使用者发出通知的时间。单位是分钟。如果你觉得，所有的事件只需要一次通知就够了，可以把这里的选项设为0  
        notification_options            d,u,r          #定义主机在什么状态下可以发送通知给使用者，d即down，表示宕机状态，u即unreachable，表示不可到达状态，r即recovery，表示重新恢复状态。  
        contact_groups                  admins         #指定联系人组，这个“admins”在contacts.cfg文件中定义。  
        register                        0  
        }  
 
define service{  
        name                            generic-service   #定义一个服务名称  
        active_checks_enabled           1     
        passive_checks_enabled          1      
        parallelize_check                1      
        obsess_over_service             1      
        check_freshness                0  
        notifications_enabled            1                 
        event_handler_enabled           1                   
        flap_detection_enabled           1                    
        failure_prediction_enabled        1                   
        process_perf_data               1                   
        retain_status_information       1                     
        retain_nonstatus_information    1                        
        is_volatile                     0   
        check_period                    24x7      #这里的check_period告诉nagios检查服务的时间段。              
        max_check_attempts              3         #nagios对服务的最大检查次数。           
        normal_check_interval           10       #此选项是用来设置服务检查时间间隔，也就是说，nagios这一次检查和下一次检查之间所隔的时间，这里是10分钟。   
        retry_check_interval            2        #重试检查时间间隔，单位是分钟。            
        contact_groups                  admins   #指定联系人组，同上。              
        notification_options            w,u,c,r  #这个定义的是“通知可以被发出的情况”。w即warn，表示警告状态，u即unknown，表示不明状态，c即criticle，表示紧急状态，r即recover，表示恢复状态。也就是在服务出现警告状态、未知状态、紧急状态和重新恢复后都发送通知给使用者。  
        notification_interval           60       #在服务出现异常后，故障一直没有解决，nagios再次对使用者发出通知的时间。单位是分钟。如果你认为，所有的事件只需要一次通知就够了，可以把这里的选项设为0。  
        notification_period             24x7     #指定“发送通知”的时间段，也就是可以在什么时候发送通知给使用者。               
         register                        0                       
        }  

```

```
cd /data00/usr/local/nagios/etc/objects #这里存放了配置文件

vi templates.cfg #修改主模版
找个空的地方添加不要破环原来的结构体
    define host{
            name                            linux_host  
            notifications_enabled           1
            event_handler_enabled           1
            flap_detection_enabled          0
            process_perf_data               1
            retain_status_information       1
            retain_nonstatus_information    1
            notification_period             24x7
            check_period                    24x7            ; By default, Linux hosts are checked round the clock
            retry_interval                  1               ; Schedule host check retries at 1 minute intervals
            check_interval			5
    	max_check_attempts              3             ; Check each Linux host 10 times (max)
            check_command                   check_http ; Default command to check Linux hosts
            notification_interval           120             ; Resend notifications every 2 hours
            notification_options            d,u,r           ; Only send notifications for specific host states
            contact_groups                  admins
            register                        0
            }
            
vi commands.cfg  #修改命令模版
找到check_http修改如下：
define command {

    command_name    check_http
    command_line    $USER1$/check_http -S -I $HOSTADDRESS$ -t 1
}

最后修改nagios主配置文件
vi /opt/usr/local/nagios/etc/nagio.cfg
    #添加这个
    cfg_file=/data00/usr/local/nagios/etc/objects/hosts.cfg

```

最后就需要生成我们的hosts模板文件了 这里贴下我的python代码，sysip调用接口到bmcip

```
# -*- coding: utf-8 -*-
import os
import requests

host = """
define host{
        use                     linux_host
        host_name               %s
        address                 %s
        }
"""
escalation = """
define hostescalation{
        host_name %s
        first_notification 3
        last_notification 0
        notification_interval 360
        contact_groups system
}
"""

# fwes = open("/data01/nagios-scripts/escalations.cfg", "w")
def ip_to_bmcip(sysip):
    """通过sysip获取bmcip"""
    headers = {'User-Agent': 'idata-bmc-script'}
    params = {'inip': sysip}
    r = requests.get('http://10.3.40.15/idc/bmcip/', headers=headers, params=params).json()
    bmcip = r['bmcip']
    print(sysip)
    return sysip, bmcip

fw = open("hosts.cfg", "w")

with open('ip', 'r') as fp:
    iplist = fp.read().split()
    for sysip in iplist:
        res = ip_to_bmcip(sysip)
        print(res[1])
        if len(res[1]) == 0:
            continue
        if "#" in res[1]:
            continue
        if "NULL" in res[1]:
            continue
        sysip2 = sysip.split('.')[1]
        sysip3 = sysip.split('.')[2]
        sysip4 = sysip.split('.')[3]
        hostname = 'n%s-%03d-%03d.byted.org' % (sysip2, int(sysip3), int(sysip4))
        fw.write(host % (hostname, res[1]))
        print("带外hosts已经完成")

```

将生成的hosts.cfg放到objects目录下 这样就完成了，目前不考虑阈值告警推送等等情况

```
验证配置文件的正确性
/data00/usr/local/nagios/bin/nagios -v /data00/usr/local/nagios/etc/nagios.cfg
评估启动时间
/data00/usr/local/nagios/bin/nagios -s /data00/usr/local/nagios/etc/nagios.cfg

```

## [](#性能调优)性能调优

```
external_command_buffer_slots
    #nagios的命令都是通过这个接收的，处理不过来的命令都会在这排队，如果你管理的service较多，建议将这个值调大。
use_large_installation_tweaks=1
    #http://nagios-cn.sourceforge.net/nagios-cn/profession.html#largeinstalltweaks这个设置缺省是关闭的，在监控的service较多的情况下，建议打开这个设置。
max_concurrent_checks=15
#该选项可指定在任意给定时间里可被同时运行的服务检测命令的最大数量。如果指定这个值为1，则说明不允许任何并行服务检测，如果指定为0(默认值)则是对并行服务检测。你须按照可运行Nagios的机器上的机器资源情况修改这个值，因为它会直接影响系统最大负荷，它施加于系统(处理器利用率、内存使用率等)之上。更多的关于如何评估需要设置多少并行检测值的信息可以查阅这篇文档.如果有部分service的监控状态一直不更新，建议将这个配置适度调大。参考值15
check_result_reaper_frequency=10
#这个配置决定了处理检查结果的频率，如果这个值太大，会导致监控service的状态更新延时变大。
max_check_result_reaper_time=30
#这个配置决定了每次处理检查结果最多可以花费的时间。这个值太大或太小都会导致监控service的状态更新延时变大。参考值5
use_retained_scheduling_info=0 
#该选项决定Nagios在重启时是否要使用主机和服务的保持计划表信息(下次检测时间)。如果增加了很多数量(或很大百分比)的主机和服务，建议你在首次重启动Nagios时关闭选项，因为这个选项将会使初始检测误入歧途。其他情况下你可以要使能这个选项

```

修改后你可以评估一下启动时间看看，我的是这样

```
Nagios Core 4.4.3
Copyright (c) 2009-present Nagios Core Development Team and Community Contributors
Copyright (c) 1999-2009 Ethan Galstad
Last Modified: 2019-01-15
License: GPL

Website: https://www.nagios.org
Timing information on object configuration processing is listed
below.  You can use this information to see if precaching your
object configuration would be useful.

Object Config Source: Config files (uncached)

OBJECT CONFIG PROCESSING TIMES      (* = Potential for precache savings with -u option)
----------------------------------
Read:                 0.907458 sec
Resolve:              0.056827 sec  *
Recomb Contactgroups: 0.016189 sec  *
Recomb Hostgroups:    0.010557 sec  *
Dup Services:         0.000016 sec  *
Recomb Servicegroups: 0.000000 sec  *
Duplicate:            0.263904 sec  *
Inherit:              0.135125 sec  *
Register:             0.281152 sec
Free:                 0.028468 sec
                      ============
TOTAL:                1.699696 sec  * = 0.120655 sec (7.10%) estimated savings


Timing information on configuration verification is listed below.

CONFIG VERIFICATION TIMES
----------------------------------
Object Relationships: 0.073221 sec
Circular Paths:       0.015593 sec
Misc:                 0.001492 sec
                      ============
TOTAL:                0.090306 sec


RETENTION DATA TIMES
----------------------------------
Read and Process:     7.613392 sec
                      ============
TOTAL:                7.613392 sec


EVENT SCHEDULING TIMES
-------------------------------------
Get service info:        0.000013 sec
Get host info info:      0.539133 sec
Get service params:      0.000004 sec
Schedule service times:  0.000012 sec
Schedule service events: 0.000006 sec
Get host params:         0.000000 sec
Schedule host times:     1.070535 sec
Schedule host events:    0.189131 sec
                         ============
TOTAL:                   1.798834 sec


Projected scheduling information for host and service checks
is listed below.  This information assumes that you are going
to start running Nagios with your current config files.

HOST SCHEDULING INFORMATION
---------------------------
Total hosts:                     167316
Total scheduled hosts:           167316
Host inter-check delay method:   SMART
Average host check interval:     300.00 sec
Host inter-check delay:          0.00 sec
Max host check spread:           30 min
First scheduled check:           Mon Aug 26 15:43:06 2019
Last scheduled check:            Mon Aug 26 15:48:05 2019


SERVICE SCHEDULING INFORMATION
-------------------------------
Total services:                     1
Total scheduled services:           1
Service inter-check delay method:   SMART
Average service check interval:     60.00 sec
Inter-check delay:                  60.00 sec
Interleave factor method:           SMART
Average services per host:          0.00
Service interleave factor:          1
Max service check spread:           30 min
First scheduled check:              Mon Aug 26 15:44:06 2019
Last scheduled check:               Mon Aug 26 15:44:06 2019


CHECK PROCESSING INFORMATION
----------------------------
Average check execution time:    0.01s
Estimated concurrent checks:     4 (0.08 per cpu core)
Max concurrent service checks:   15


PERFORMANCE SUGGESTIONS
-----------------------
I have no suggestions - things look okay.

```

## [](#nagiosgrafanainfluxdbnagfluxhistou部署)nagios+grafana+influxdb+nagflux+histou部署

这里直接放出官方的链接，问题不大 [https://support.nagios.com/kb/article/nagios-core-performance-graphs-using-influxdb-nagflux-grafana-histou-802.html#Debian](https://support.nagios.com/kb/article/nagios-core-performance-graphs-using-influxdb-nagflux-grafana-histou-802.html#Debian) [https://assets.nagios.com/downloads/nagioscore/docs/nagioscore/3/en/macrolist.html#hoststate](https://assets.nagios.com/downloads/nagioscore/docs/nagioscore/3/en/macrolist.html#hoststate)